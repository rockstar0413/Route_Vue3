import { createRouter, createWebHistory } from 'vue-router'
import LandingPage from '@/views/LandingPage.vue'
import SignInPage from '@/views/SingInPage.vue'
import SingUpPage from '@/views/SingUpPage.vue'
import ForgotPassword from '@/views/ForgotPassword.vue'
import ResetPassword from '@/views/ResetPassword.vue'
import OptimizationProviderPage from '@/views/OptimizationProviderPage.vue'
import OptimizationOptionPage from '@/views/OptimizationOptionPage.vue'
import OptimizationAddressesPage from '@/views/OptimizationAddressesPage.vue'
import OptimizationPreferencesPage from '@/views/OptimizationPreferencesPage.vue'
import OptimizationRoutesPage from '@/views/OptimizationRoutesPage.vue'
import ProfilePage from '@/views/ProfilePage.vue'
import ProfileAccountPage from '@/views/ProfileAccountPage.vue'
import ProfileSubscriptionPage from '@/views/ProfileSubscriptionPage.vue'
import ProfileCardPage from '@/views/ProfileCardPage.vue'
import ProfileChangePasswordPage from '@/views/ProfileChangePasswordPage.vue'
import OptimizationPage from '@/views/OptimizationPage.vue'
import OptimizationRouteDetailPage from '@/views/OptimizationRouteDetailPage.vue'
import OptimizationRoutePlanPage from '@/views/OptimizationRoutePlanPage.vue'
import OptimizationRoutePlanDetailPage from '@/views/OptimizationRoutePlanDetailPage.vue'
import ProfileOrdersPage from '@/views/ProfileOrdersPage.vue'
const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/',
      name: 'landing',
      component: LandingPage,
      meta:{
        layout:'DefaultLayout'
      }
    },
    {
      path: '/auth/signin',
      name: 'signin',
      component: SignInPage,
      meta:{
        layout:'DefaultLayout'
      }
    },
    {
      path: '/auth/signup',
      name: 'signup',
      component: SingUpPage,
      meta:{
        layout:'DefaultLayout'
      }
    },
    {
      path: '/auth/forgotpassword',
      name: 'forgotpassword',
      component: ForgotPassword,
      meta:{
        layout:'DefaultLayout'
      }
    },
    {
      path: '/auth/resetpassword/:id',
      name: 'resetpassword',
      component: ResetPassword,
      meta:{
        layout:'DefaultLayout'
      }
    },
    {
      path: '/optimization',
      name: 'optimization',
      redirect:'/optimization/provider',
      component: OptimizationPage,
      meta:{
        layout:'DefaultLayout'
      },
      children: [
        {
          path: 'provider',
          name: 'provider',
          component: OptimizationProviderPage,
        },
        {
          path: 'option',
          name: 'option',
          component: OptimizationOptionPage,
        },
        {
          path: 'addresses',
          name: 'addresses',
          component: OptimizationAddressesPage,
        },
        {
          path: 'preferences',
          name: 'preferences',
          component: OptimizationPreferencesPage,
        },
        {
          path: 'routes',
          name: 'routes',
          component: OptimizationRoutesPage,
        },
        {
          path: 'routes/:id',
          name: 'route-detail',
          component: OptimizationRouteDetailPage,
        },
        {
          path: 'plan',
          name: 'plan',
          component: OptimizationRoutePlanPage,
        },
        {
          path: 'plan/:id',
          name: 'plan-detail',
          component: OptimizationRoutePlanDetailPage,
        },
      ],
    },
    {
      path: '/profile',
      name: 'profile',
      redirect:'/profile/account',
      component: ProfilePage,
      meta:{
        layout:'DefaultLayout'
      },
      children: [
        {
          path: 'account',
          name: 'account',
          component: ProfileAccountPage,
        },
        {
          path: 'subscription',
          name: 'subscription',
          component: ProfileSubscriptionPage,
        },
        {
          path: 'orders',
          name: 'orders',
          component: ProfileOrdersPage,
        },
        {
          path: 'card',
          name: 'card',
          component: ProfileCardPage,
        },
        {
          path: 'change-password',
          name: 'change-password',
          component: ProfileChangePasswordPage,
        },
      ],
    },
  ],
  scrollBehavior(to, from, savedPosition) {
    if (to.hash) {
      // This ensures that if hash is provided to router.push it works as expected.
      //  & since we have used "behavior: 'smooth'" the browser will slowly come to this hash position.
      return {
        el: to.hash,
        behavior: 'smooth',
      }
    }
  }
})

export default router
