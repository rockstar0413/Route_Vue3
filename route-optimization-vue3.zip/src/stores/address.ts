import { defineStore } from 'pinia'
import axios from 'axios'
import config from '@/shared/config'
import router from '@/router'
import type {
  IPoint,
  IRoute,
  Position,
  Center,
  IOptimizeRoutes,
} from '@/shared/interfaces'

export const useAddressStore = defineStore({
  id: 'address',
  state: () => ({
    addresses: [] as Array<IRoute>,
    point: {
      status: 0,
      message: '',
      optimize_point_id: 0,
      optimize_point_address: '',
      optimize_point_latitude: '',
      optimize_point_longitude: '',
      apartment_no: '',
    } as IPoint,
    deliveryType: 1 as Number,
    optimization_token: '' as String,
    isLoading: false as boolean,
    markers: [] as Array<Position>,
    center: { lat: 0, lng: 0 } as Center,
    start_marker: {
      optimize_route_id: 0,
      address: '',
      position: {
        lat: 0,
        lng: 0,
      },
    } as Position,
    deliveryMethod: 1 as Number,
    deliver: 1 as Number,
    algorithm: 1 as number,
    search_text: '' as string,
    route_search_text: '' as string,
    access_token: '' as string,
    beforeRoute: '' as string,
    user: null as any,
    boundCenter: { lat: 0, lng: 0 } as Center,
    numberOfDrivers:2,
    minDrivers:2,
    maxDrivers:4,
    effective_radius: 0,
    load_upload_time: 30,

    store: {
      new_store_address: '',
      new_store_latitude: '',
      new_store_longitude: '',
    },
    optimized_routes: {} as IOptimizeRoutes,
    charged_routes_count: 0 as number,
    credit_charged: 0 as number,
    uncharged_routes_count: 0 as number,
    detailRoutes: [] as Array<any>
  }),
  getters: {
    getOptimizedRoutes: (state) => state.optimized_routes,
    getAddresses: (state) => state.addresses,
    getRadius: (state) => state.effective_radius,
    getSearchText: (state) => state.search_text,
    getBeforeRoute: (state) => state.beforeRoute,
    getNumberOfDrivers: (state) => state.numberOfDrivers,
    getMinDrivers: (state) => state.minDrivers,
    getMaxDrivers: (state) => state.maxDrivers,
    getEffectiveRadius: (state) => state.effective_radius,
    getLoadUploadTime: (state) => state.load_upload_time,
    getFilteredAddresses: (state) =>
      state.addresses.filter(
        (item: IRoute) =>
          item.address?.toUpperCase().indexOf(state.search_text.toUpperCase()) > -1
      ),
    getRouteFilteredAddresses: (state) => {
      return (plan_no: string) => state.addresses.filter(
        (item: IRoute) => {
          if (item.address?.toUpperCase().indexOf(state.route_search_text.toUpperCase()) > -1 && item.plan_no.toString() === plan_no.toString()) return item;
        }
      )
    },
    getRouteAddresses: (state) => {
      return (plan_no: string) => state.addresses.filter(
        (item: IRoute) => {
          if (item.plan_no.toString() === plan_no.toString()) return item;
        }
      )
    },
    getFilteredMarkers: (state) => state.markers,
    //state.markers.filter((item:Position)=>item.address.indexOf(state.search_text)>-1),
    getAlgorithm: (state) => state.algorithm,
    getToken: (state) => state.optimization_token,
    getPoint: (state) => state.point,
    getDeliveryType: (state) => state.deliveryType,
    getIsLoading: (state) => state.isLoading,
    getMarkers: (state) => state.markers,
    getCenter: (state) => state.center,
    getBoundCenter: (state) => state.boundCenter,
    getUser: (state) => state.user,
    // {
    //   let tempMarkers:Array<Position> = state.markers.filter((item:Position)=>item.address.indexOf(state.search_text)>-1);
    //   if(tempMarkers.length>0) return tempMarkers[tempMarkers.length-1];
    //   else return {
    //     lat: Number(state.point.optimize_point_latitude),
    //     lng: Number(state.point.optimize_point_longitude)
    //   }
    // },
    getFilteredEyeMaker: (state) => state.addresses.filter((item: IRoute) => item.eye),
    getStartMaker: (state) => state.start_marker,
    getDeliveryMethod: (state) => state.deliveryMethod,
    getDeliver: (state) => state.deliver,
    getCheckedAddresses: (state) => {
      return state.addresses.filter(
        (address: IRoute) => address.checked === true,
      )
    },
    getRouteCheckedAddresses: (state) => {
      return (plan_no: string) => state.addresses.filter(
        (item: IRoute) => {
          if (item.address?.toUpperCase().indexOf(state.route_search_text.toUpperCase()) > -1 && item.plan_no.toString() === plan_no.toString() && item.checked === true) return item;
        }
      )
    },
    getAccessToken: (state) => state.access_token,
    getDetailRoutes:(state) => state.detailRoutes,
    getRouteEye:(state) =>{
      return (plan_no:string) =>{
        for(let i=0;i<state.addresses.length;i++){
          if(state.addresses[i].plan_no === plan_no){
            return state.addresses[i].eye;
          }
        }
      }
    }
  },
  actions: {
    setDeliveryMethod(method: number) {
      this.deliveryMethod = method
    },
    clear() {
      this.addresses = []
      this.point = {
        status: 0,
        message: '',
        optimize_point_id: 0,
        optimize_point_address: '',
        optimize_point_latitude: '',
        optimize_point_longitude: '',
        apartment_no: '',
      } as IPoint
      this.deliveryType = 1
      this.optimization_token = ''
      this.isLoading = false
      this.markers = []
      this.center = { lat: 0, lng: 0 } as Center
      this.boundCenter = { lat: 0, lng: 0 } as Center
      this.start_marker = {
        optimize_route_id: 0,
        address: '',
        position: {
          lat: 0,
          lng: 0,
        },
      } as Position
      this.deliveryMethod = 1
      this.deliver = 1
      this.algorithm = 1
      this.search_text = ''
      this.route_search_text = ''
      this.access_token = ''
      this.beforeRoute = ''
      this.user = null
      this.numberOfDrivers = 2
      this.maxDrivers = 4
      this.minDrivers = 2
      this.load_upload_time = 30
      this.effective_radius = 0
      this.optimized_routes = {} as IOptimizeRoutes
      this.charged_routes_count = 0
      this.credit_charged = 0
      this.uncharged_routes_count = 0
      this.detailRoutes = [] as Array<any>
    },
    clearAddresses() {
      this.addresses = []
      this.point = {
        status: 0,
        message: '',
        optimize_point_id: 0,
        optimize_point_address: '',
        optimize_point_latitude: '',
        optimize_point_longitude: '',
        apartment_no: '',
      } as IPoint
      this.markers = []
      this.center = { lat: 0, lng: 0 } as Center
      this.boundCenter = { lat: 0, lng: 0 } as Center
      this.start_marker = {
        optimize_route_id: 0,
        address: '',
        position: {
          lat: 0,
          lng: 0,
        },
      } as Position
      this.deliveryMethod = 1
      this.deliver = 1
      this.algorithm = 1
      this.search_text = ''
      this.route_search_text = ''
      this.effective_radius = 0
      this.optimized_routes = {} as IOptimizeRoutes
      this.charged_routes_count = 0
      this.credit_charged = 0
      this.uncharged_routes_count = 0
      this.detailRoutes = [] as Array<any>
    },
    clearOptimizeRoutes() {
      this.optimized_routes = {} as IOptimizeRoutes;
      this.detailRoutes = [] as Array<any>
    },
    setAccessToken(token: string) {
      this.access_token = token;
    },
    setNumberOfDrivers(drivers: number) {
      this.numberOfDrivers = drivers
    },
    setMinDrivers(min: number) {
      this.minDrivers = min
    },
    setMaxDrivers(max: number) {
      this.maxDrivers = max
    },
    setRadius(radius: number) {
      this.effective_radius = radius
    },
    setLoadUploadTime(time: number) {
      this.load_upload_time = time
    },
    setBeforeRoute(route: string) {
      this.beforeRoute = route
    },
    setUser(user: any) {
      this.user = user
    },
    setCenter(lat: number, lng: number) {
      this.center = {
        lat: lat,
        lng: lng,
      } as Center
    },
    setBoundCenter(lat: number, lng: number) {
      this.boundCenter = {
        lat: lat,
        lng: lng,
      } as Center
    },
    setSearchAddress(text: string) {
      this.search_text = text
    },
    setRouteSearchAddress(text: string) {
      this.route_search_text = text
    },
    setDeliveryType(type: number) {
      this.deliveryType = type
    },
    setAlgorithm(type: number) {
      this.algorithm = type
    },
    setDeliver(type: number) {
      this.deliver = type
    },
    setPlan0(){
      this.addresses.map((address:IRoute)=>{
        address.plan_no = '0';
        address.eye = true;
        return address
      })
    },
    changeCheckState(check: boolean) {
      for (let i = 0; i < this.addresses.length; i++) {
        this.addresses[i].checked = check
      }
    },
    changeRouteCheckState(check: boolean, plan_no: string) {
      for (let i = 0; i < this.getRouteFilteredAddresses(plan_no).length; i++) {
        this.getRouteFilteredAddresses(plan_no)[i].checked = check
      }
    },
    calculateBoundCenter() {
      let maxLat = Number(this.start_marker.position.lat)
      let minLat = Number(this.start_marker.position.lat)
      let maxLng = Number(this.start_marker.position.lng)
      let minLng = Number(this.start_marker.position.lng)
      let centerLat = 0
      let centerLng = 0
      this.markers.map((item: Position) => {
        if (item.position.lat > maxLat) maxLat = Number(item.position.lat)
        if (item.position.lat < minLat) minLat = Number(item.position.lat)
        if (item.position.lng > maxLng) maxLng = Number(item.position.lng)
        if (item.position.lng < minLng) minLng = Number(item.position.lng)
        return item
      })
      centerLat = (maxLat - minLat) / 2 + minLat
      centerLng = (maxLng - minLng) / 2 + minLng
      this.setBoundCenter(centerLat, centerLng)
    },
    changeRouteVisible(num: number) {
      this.addresses.map((address: IRoute) => {
        if (address.plan_no === num.toString()) address.eye = !address.eye;
        return address;
      })
    },
    changeAllRouteVisible() {
      this.addresses.map((address: IRoute) => {
        address.eye = true
        return address;
      })
    },
    async sendMailWithData(
      name: string,
      email: string,
      phone: string,
      company: string,
      description: string,
    ) {
      try {
        this.isLoading = true
        let response = (
          await axios.post(config.api.visitor.SEND_MAIL, {
            name: name,
            email: email,
            phone: phone,
            company: company,
            description: description,
          })
        ).data
        this.isLoading = false
      } catch (e) {
        this.isLoading = false
        if (
          (e as any).response.data.message &&
          (e as any).response.data.message === 'Unauthenticated.'
        ) {
          alert('Session is expired')
          this.clear()
          router.push({ name: 'signin' })
        }
      }
    },
    async fetchTokenByDeliveryType() {
      try {
        this.clearAddresses()
        this.isLoading = true
        let data = {
          delivery_type: this.deliveryType,
        }
        let url = ''
        if (this.getAccessToken === '') {
          url = config.api.visitor.CHOOSE_DELIVERY
        } else {
          url = config.api.customer.CHOOSE_DELIVERY_METHOD
          axios.defaults.headers.common['Authorization'] =
            'Bearer ' + this.access_token
        }
        let response = (await axios.post(url, data)).data
        console.log(response)
        this.optimization_token =
          response.optimization_token || response.OptimizationToken
        this.isLoading = false
        return this.optimization_token
      } catch (e) {
        this.isLoading = false
        if (
          (e as any).response.data.message &&
          (e as any).response.data.message === 'Unauthenticated.'
        ) {
          alert('Session is expired')
          this.clear()
          router.push({ name: 'signin' })
        }
      }
    },
    async fetchPickUpAddress(
      point: string,
      latitude: string,
      longitude: string,
    ) {
      try {
        this.isLoading = true
        let data = {
          optimize_point_address: point,
          optimize_point_latitude: latitude,
          optimize_point_longitude: longitude,
          optimization_token: this.optimization_token,
        }
        let url = ''
        if (this.getAccessToken === '') {
          url = config.api.visitor.ADD_POINT
        } else {
          url = config.api.optimize_point.ADD_OPTIMIZE_POINT
          axios.defaults.headers.common['Authorization'] =
            'Bearer ' + this.access_token
        }
        let response1 = (await axios.post(url, data)).data
        let response = response1.data
        console.log(response1)
        this.isLoading = false
        this.point = {
          status: response.status,
          message: '',
          optimize_point_id: response.optimize_point_id,
          optimize_point_address: response.pickup_contact_address,
          optimize_point_latitude: response.pickup_latitude,
          optimize_point_longitude: response.pickup_longitude,
          apartment_no: '',
          driver_count: response.driver_count,
          min_count: response.min_count,
          max_count: response.max_count,
          algorithm_id: response.algorithm_id,
          effective_radius: response.effective_radius,
          load_upload_time: response.load_upload_time,
          created_at: response.created_at || '',
          customer_id: response.customer_id || '',
          optimization_id: response.optimization_id || '',
        }
        this.start_marker = {
          optimize_route_id: this.point.optimize_point_id,
          address: this.point.optimize_point_address,
          position: {
            lat: Number(this.point.optimize_point_latitude),
            lng: Number(this.point.optimize_point_longitude),
          },
        }

        this.center = {
          lat: Number(this.point.optimize_point_latitude),
          lng: Number(this.point.optimize_point_longitude),
        }
        this.calculateBoundCenter()
      } catch (e) {
        this.isLoading = false
      }
    },
    async updatePickUpAddress(
      point: string,
      latitude: string,
      longitude: string,
    ) {
      try {
        this.isLoading = true
        let data = {
          optimize_point_address: point,
          optimize_point_latitude: latitude,
          optimize_point_longitude: longitude,
          optimization_token: this.optimization_token,
          driver_count: '2',
          min_count: '2',
          max_count: '4',
          algorithm_id: '1',
          effective_radius: '5',
          load_upload_time: '30',
        }
        let url = ''
        if (this.getAccessToken === '') {
          url = config.api.visitor.UPDATE_POINT
        } else {
          url = config.api.optimize_point.UPDATE_OPTIMIZE_POINT
          axios.defaults.headers.common['Authorization'] =
            'Bearer ' + this.access_token
        }
        let response = (await axios.post(url, data)).data.data
        this.point = {
          status: response.status,
          message: '',
          optimize_point_id: response.optimize_point_id,
          optimize_point_address: response.pickup_contact_address,
          optimize_point_latitude: response.pickup_latitude,
          optimize_point_longitude: response.pickup_longitude,
          apartment_no: '',
          driver_count: response.driver_count,
          min_count: response.min_count,
          max_count: response.max_count,
          algorithm_id: response.algorithm_id,
          effective_radius: response.effective_radius,
          load_upload_time: response.load_upload_time,
          created_at: response.created_at || '',
          customer_id: response.customer_id || '',
          optimization_id: response.optimization_id || '',
        }
        this.isLoading = false
        this.start_marker = {
          optimize_route_id: this.point.optimize_point_id,
          address: this.point.optimize_point_address,
          position: {
            lat: this.point.optimize_point_latitude,
            lng: this.point.optimize_point_longitude,
          },
        }

        this.center = {
          lat: Number(this.point.optimize_point_latitude),
          lng: Number(this.point.optimize_point_longitude),
        }
        this.calculateBoundCenter()
        return response
      } catch (e) {
        this.isLoading = false
        if (
          (e as any).response.data.message &&
          (e as any).response.data.message === 'Unauthenticated.'
        ) {
          alert('Session is expired')
          this.clear()
          router.push({ name: 'signin' })
        }
      }
    },
    async fetchDropOffAddress(
      point: string,
      latitude: string,
      longitude: string,
      apt: string,
    ) {
      try {
        this.isLoading = true
        let data = {
          address: point,
          latitude: latitude,
          longitude: longitude,
          optimization_token: this.optimization_token,
          apartment_no: apt,
        }
        let url = ''
        if (this.getAccessToken === '') {
          url = config.api.visitor.ADD_ROUTE
        } else {
          url = config.api.optimize_routes.ADD_OPTIMIZE_ROUTE
          axios.defaults.headers.common['Authorization'] =
            'Bearer ' + this.access_token
        }
        let responseData = (await axios.post(url, data)).data
        console.log(responseData)
        let response: IRoute = {
          ...responseData,
          checked: false,
          eye: true,
          plan_no: '0',
          start_point: false,
          end_point: false,
          order: "0",
          position: {
            lat: responseData.latitude,
            lng: responseData.longitude,
          },
        }
        this.isLoading = false
        this.addresses.push(response)
        this.markers.push({
          optimize_route_id: response.optimize_route_id,
          address: response.address,
          position: {
            lat: response.latitude,
            lng: response.longitude,
          },
        })
        this.center = {
          lat: Number(response.latitude),
          lng: Number(response.longitude),
        }
        this.calculateBoundCenter()
      } catch (e) {
        this.isLoading = false
        if (
          (e as any).response.data.message &&
          (e as any).response.data.message === 'Unauthenticated.'
        ) {
          alert('Session is expired')
          this.clear()
          router.push({ name: 'signin' })
        }
      }
    },
    async addLocalStop(
      point: string,
      latitude: string,
      longitude: string,
      apt: string,
      driver_index: string
    ) {
      try {
        this.isLoading = true
        let data = {
          address: point,
          latitude: latitude,
          longitude: longitude,
          optimization_token: this.optimization_token,
          apartment_no: apt,
          driver_index: driver_index
        }
        let url = ''

        url = config.api.optimization.ADD_STOP
        axios.defaults.headers.common['Authorization'] =
          'Bearer ' + this.access_token
        let responseData = (await axios.post(url, data)).data
        console.log(responseData)
        for (let i = 0; i < responseData.data.route.length; i++) {
          let temp = true;
          for (let j = 0; j < this.addresses.length; j++) {
            if (responseData.data.route[i].optimize_route_id === this.addresses[j].optimize_route_id) {
              this.addresses[j].plan_no = responseData.data.plan_no.toString();
              this.addresses[j].order = i.toString();
              if (i === 0) {
                this.addresses[j].start_point = true;
                this.addresses[j].end_point = false;
              }
              if (i === responseData.data.route.length - 1) {
                this.addresses[j].start_point = false;
                this.addresses[j].end_point = true;
              }
              temp = false;
              break
            }
          }
          if (temp) {
            this.addresses.push({
              address: responseData.data.route[i].address,
              latitude: Number(responseData.data.route[i].latitude),
              longitude: Number(responseData.data.route[i].longitude),
              message: '',
              optimize_route_id: responseData.data.route[i].optimize_route_id,
              status: 1,
              apartment_no: responseData.data.route[i].apartment,
              checked: false,
              description: '',
              contact_person: '',
              phone_prefix: '',
              phone: '',
              country_code: '',
              is_enabled: '',
              plan_no: responseData.data.plan_no.toString(),
              start_point: i === 0 ? true : false,
              end_point: i === responseData.data.route.length - 1 ? true : false,
              order: i.toString(),
              eye: true,
              position: {
                lat: Number(responseData.data.route[i].latitude),
                lng: Number(responseData.data.route[i].longitude)
              }
            })
          }
        }
        this.center = {
          lat: Number(latitude),
          lng: Number(longitude),
        }
        this.optimized_routes.data[responseData.data.plan_no - 1] = responseData.data.route
        this.detailRoutes[responseData.data.plan_no - 1] = responseData.data
        console.log(this.detailRoutes)
        this.isLoading = false;
        // console.log(this.optimized_routes)
        // this.markers.push({
        //   optimize_route_id: response.optimize_route_id,
        //   address: response.address,
        //   position: {
        //     lat: response.latitude,
        //     lng: response.longitude,
        //   },
        // })
        // this.calculateBoundCenter()
      } catch (e) {
        this.isLoading = false
        if (
          (e as any).response.data.message &&
          (e as any).response.data.message === 'Unauthenticated.'
        ) {
          alert('Session is expired')
          this.clear()
          router.push({ name: 'signin' })
        }
      }
    },
    async updateSingleRoute(
      address: string,
      contact_person: string,
      phone_prefix: string,
      phoneNumber: string,
      description: string,
      apartment_no: string,
      id: string,
      latitude: string,
      longitude: string,
      countryCode: string,
    ) {
      try {
        this.isLoading = true
        let response: IRoute = {
          ...(
            await axios.put(config.api.visitor.UPDATE_ROUTE + '/' + id, {
              address: address,
              latitude: latitude,
              longitude: longitude,
              optimization_token: this.optimization_token,
              apartment_no: apartment_no,
              is_enabled: '0',
              contact_person: contact_person,
              phone_prefix: phone_prefix,
              phone: phoneNumber,
              description: description,
            })
          ).data,
          checked: false,
          country_code: countryCode,
        }
        this.isLoading = false
        for (let i = 0; i < this.addresses.length; i++) {
          if (
            this.addresses[i].optimize_route_id === response.optimize_route_id
          ) {
            this.addresses[i] = response
            this.addresses[i].position.lat = Number(response.latitude)
            this.addresses[i].position.lng = Number(response.longitude)
          }
        }
        for (let i = 0; i < this.markers.length; i++) {
          if (
            this.markers[i].optimize_route_id === response.optimize_route_id
          ) {
            this.markers[i].position.lat = Number(response.latitude)
            this.markers[i].position.lng = Number(response.longitude)
          }
        }
        this.center = {
          lat: Number(response.latitude),
          lng: Number(response.longitude),
        }
        this.calculateBoundCenter()
      } catch (e) {
        this.isLoading = false
        if (
          (e as any).response.data.message &&
          (e as any).response.data.message === 'Unauthenticated.'
        ) {
          alert('Session is expired')
          this.clear()
          router.push({ name: 'signin' })
        }
      }
    },
    async updateStop(optimize_route_id: string, driver_index: string, address: string, latitude: string, longitude: string) {
      try {
        console.log(optimize_route_id, driver_index, address, latitude, longitude);

        this.isLoading = true
        let data = {
          optimization_token: this.optimization_token,
          optimize_route_id: optimize_route_id.toString(),
          driver_index: driver_index,
          address: address,
          latitude: latitude.toString(),
          longtitude: longitude.toString()
        }
        let url = ''

        url = config.api.optimization.UPDATE_STOP
        axios.defaults.headers.common['Authorization'] =
          'Bearer ' + this.access_token

        let response = (await axios.put(
          url, data
        )).data
        console.log("delete response", response)
        this.isLoading = false

        // this.optimized_routes.data[response.data.plan_no - 1] = response.data.route
        // console.log("updated routes status", this.optimized_routes.data)

        // let temp = 0
        // for (let i = 0; i < this.addresses.length; i++) {
        //   if (
        //     this.addresses[i].optimize_route_id.toString() === optimize_route_id.toString()
        //   ) {
        //     temp = i
        //   }
        // }
        // this.addresses.splice(temp, 1)
        // if (this.addresses.length > 0) {
        //   this.center = {
        //     lat: Number(this.addresses[this.addresses.length - 1].latitude),
        //     lng: Number(this.addresses[this.addresses.length - 1].longitude),
        //   }
        // } else {
        //   this.center = {
        //     lat: Number(this.point.optimize_point_latitude),
        //     lng: Number(this.point.optimize_point_longitude),
        //   }
        // }
        // for(let i=0;i<response.data.route.length;i++){
        //   let temp = true;
        //   for(let j=0;j<this.addresses.length;j++){
        //     if(response.data.route[i].optimize_route_id === this.addresses[j].optimize_route_id){
        //       this.addresses[j].plan_no = response.data.plan_no.toString();
        //       this.addresses[j].order = i.toString();
        //       if(i===0){
        //         this.addresses[j].start_point = true;
        //         this.addresses[j].end_point = false;
        //       }
        //       if(i===response.data.route.length-1){
        //         this.addresses[j].start_point = false;
        //         this.addresses[j].end_point = true;
        //       }
        //       temp = false;
        //       break
        //     }
        //   }
        // }
        // console.log("addresses after delete", this.addresses)

        // for (let i = 0; i < this.markers.length; i++) {
        //   if (this.markers[i].optimize_route_id.toString() === optimize_route_id.toString()) {
        //     temp = i
        //   }
        // }
        // this.markers.splice(temp, 1)
        // this.calculateBoundCenter()
      } catch (e) {
        this.isLoading = false
        if (
          (e as any).response.data.message &&
          (e as any).response.data.message === 'Unauthenticated.'
        ) {
          alert('Session is expired')
          this.clear()
          router.push({ name: 'signin' })
        }
      }
    },
    async moveToRoute(optimize_route_id: string, driver_index: string) {
      try {
        console.log(optimize_route_id, driver_index);
        this.isLoading = true
        let data = {
          optimization_token: this.optimization_token,
          optimize_route_id: optimize_route_id.toString(),
          driver_index: driver_index,
        }
        let url = ''
        url = config.api.optimization.MOVE_TO
        axios.defaults.headers.common['Authorization'] =
          'Bearer ' + this.access_token
        let response = (await axios.put(
          url, data
        )).data
        console.log(response)
        this.isLoading = false
        if(response.status === 1){
          for(let i=0;i<response.data.length;i++){
            this.optimized_routes.data[response.data[i].plan_no - 1] = response.data[i]
            this.detailRoutes[response.data[i].plan_no - 1] = response.data[i]
          }
          for (let i = 0; i < this.addresses.length; i++) {
            if (this.addresses[i].optimize_route_id.toString() === optimize_route_id.toString()) {
              this.addresses[i].plan_no = driver_index
            }
          }
        }
      } catch (e) {
        this.isLoading = false
        if (
          (e as any).response.data.message &&
          (e as any).response.data.message === 'Unauthenticated.'
        ) {
          alert('Session is expired')
          this.clear()
          router.push({ name: 'signin' })
        }
      }
    },
    async multiMoveToRoute(routes: Array<number>, driver_index: string) {
      try {
        console.log(driver_index)
        this.isLoading = true
        let data = {
          optimization_token: this.optimization_token,
          driver_index: driver_index,
          optimize_route_id: routes
        }
        let url = ''
        url = config.api.optimization.MULTI_MOVE_TO
        axios.defaults.headers.common['Authorization'] =
          'Bearer ' + this.access_token
        let response = (await axios.put( url, data)).data
        console.log(response)
        this.isLoading = false
        if(response.status === 1){
          for(let i=0;i<response.data.length;i++){
            this.optimized_routes.data[response.data[i].plan_no - 1] = response.data[i]
            this.detailRoutes[response.data[i].plan_no - 1] = response.data[i]
          }
          for (let i = 0; i < this.addresses.length; i++) {
            for(let j=0; j< routes.length;j++){
              if (this.addresses[i].optimize_route_id.toString() === routes[j].toString()) {
                this.addresses[i].plan_no = driver_index
              }
            }
          }
        }    
      } catch (e) {
        this.isLoading = false
        if (
          (e as any).response.data.message &&
          (e as any).response.data.message === 'Unauthenticated.'
        ) {
          alert('Session is expired')
          this.clear()
          router.push({ name: 'signin' })
        }
      }
    },
    async deleteLocalStop(optimize_route_id: string, driver_index: string) {
      try {
        this.isLoading = true
        let data = {
          optimization_token: this.optimization_token,
          driver_index: driver_index,
          optimize_route_id: optimize_route_id
        }
        console.log("previous routes status", this.optimized_routes.data)
        console.log("addresses before delete", this.addresses)
        console.log("delete request", data)
        let url = ''

        url = config.api.optimization.DELETE_STOP
        axios.defaults.headers.common['Authorization'] =
          'Bearer ' + this.access_token

        let response = (await axios.delete(
          url,
          {
            data: data,
          },
        )).data
        console.log("delete response", response)
        this.isLoading = false

        this.optimized_routes.data[response.data.plan_no - 1] = response.data.route
        this.detailRoutes[response.data.plan_no - 1] = response.data
        console.log("updated routes status", this.optimized_routes.data)

        let temp = 0
        for (let i = 0; i < this.addresses.length; i++) {
          if (
            this.addresses[i].optimize_route_id.toString() === optimize_route_id.toString()
          ) {
            temp = i
          }
        }
        this.addresses.splice(temp, 1)
        if (this.addresses.length > 0) {
          this.center = {
            lat: Number(this.addresses[this.addresses.length - 1].latitude),
            lng: Number(this.addresses[this.addresses.length - 1].longitude),
          }
        } else {
          this.center = {
            lat: Number(this.point.optimize_point_latitude),
            lng: Number(this.point.optimize_point_longitude),
          }
        }
        for (let i = 0; i < response.data.route.length; i++) {
          for (let j = 0; j < this.addresses.length; j++) {
            if (response.data.route[i].optimize_route_id === this.addresses[j].optimize_route_id) {
              this.addresses[j].plan_no = response.data.plan_no.toString();
              this.addresses[j].order = i.toString();
              if (i === 0) {
                this.addresses[j].start_point = true;
                this.addresses[j].end_point = false;
              }
              if (i === response.data.route.length - 1) {
                this.addresses[j].start_point = false;
                this.addresses[j].end_point = true;
              }
              break
            }
          }
        }
        console.log("addresses after delete", this.addresses)
      } catch (e) {
        this.isLoading = false
        if (
          (e as any).response.data.message &&
          (e as any).response.data.message === 'Unauthenticated.'
        ) {
          alert('Session is expired')
          this.clear()
          router.push({ name: 'signin' })
        }
      }
    },
    async deleteSingleRoute(id: string) {
      try {
        this.isLoading = true
        let response = await axios.delete(
          config.api.visitor.DELETE_SINGLE_ROUTE + '/' + id,
          {
            data: {
              optimization_token: this.optimization_token,
            },
          },
        )
        console.log(id, response)
        this.isLoading = false
        let temp = 0
        for (let i = 0; i < this.addresses.length; i++) {
          if (
            this.addresses[i].optimize_route_id.toString() === id.toString()
          ) {
            temp = i
          }
        }
        this.addresses.splice(temp, 1)
        if (this.addresses.length > 0) {
          this.center = {
            lat: Number(this.addresses[this.addresses.length - 1].latitude),
            lng: Number(this.addresses[this.addresses.length - 1].longitude),
          }
        } else {
          this.center = {
            lat: Number(this.point.optimize_point_latitude),
            lng: Number(this.point.optimize_point_longitude),
          }
        }
        temp = 0
        console.log('stops single delete')
        for (let i = 0; i < this.markers.length; i++) {
          if (this.markers[i].optimize_route_id.toString() === id.toString()) {
            temp = i
          }
        }
        this.markers.splice(temp, 1)
        this.calculateBoundCenter()
      } catch (e) {
        this.isLoading = false
        if (
          (e as any).response.data.message &&
          (e as any).response.data.message === 'Unauthenticated.'
        ) {
          alert('Session is expired')
          this.clear()
          router.push({ name: 'signin' })
        }
      }
    },
    async deleteMultipleRoute(routes: Array<number>) {
      try {
        this.isLoading = true
        let response = await axios.delete(
          config.api.visitor.DELETE_MULTIPLE_ROUTE,
          {
            data: {
              optimization_token: this.optimization_token,
              optimize_route_id: routes,
            },
          },
        )
        console.log(response)
        this.isLoading = false
        this.isLoading = false
        for (let i = 0; i < this.addresses.length; i++) {
          for (let j = 0; j < routes.length; j++) {
            if (
              this.addresses[i].optimize_route_id.toString() ===
              routes[j].toString()
            ) {
              this.addresses.splice(i, 1)
            }
          }
        }
        if (this.addresses.length > 0) {
          this.center = {
            lat: Number(this.addresses[this.addresses.length - 1].latitude),
            lng: Number(this.addresses[this.addresses.length - 1].longitude),
          }
        } else {
          this.center = {
            lat: Number(this.point.optimize_point_latitude),
            lng: Number(this.point.optimize_point_longitude),
          }
        }
        for (let i = 0; i < this.markers.length; i++) {
          for (let j = 0; j < routes.length; j++) {
            if (
              this.markers[i].optimize_route_id.toString() ===
              routes[j].toString()
            ) {
              this.markers.splice(i, 1)
            }
          }
        }
        this.calculateBoundCenter()
      } catch (e) {
        this.isLoading = false
        if (
          (e as any).response.data.message &&
          (e as any).response.data.message === 'Unauthenticated.'
        ) {
          alert('Session is expired')
          this.clear()
          router.push({ name: 'signin' })
        }
      }
    },
    async deleteMultipleRouteDetail(routes: Array<number>, driver_index: string) {
      try {
        console.log(routes)
        this.isLoading = true
        let data = {
          optimization_token: this.optimization_token,
          driver_index: driver_index,
          optimize_route_id: routes
        }
        let url = ''

        url = config.api.optimization.DELETE_MULTIPLE_ROUTES
        axios.defaults.headers.common['Authorization'] =
          'Bearer ' + this.access_token
        let response = (await axios.delete(
          url,
          {
            data: data,
          },
        )).data
        console.log(response)
        this.isLoading = false
        this.optimized_routes.data[response.data.plan_no - 1] = response.data.route
        this.detailRoutes[response.data.plan_no - 1] = response.data
        console.log(this.detailRoutes)
        let removeIndexs=[] as Array<number>
        for (let i = 0; i < this.addresses.length; i++) {
          for (let j = 0; j < routes.length; j++) {
            if (
              this.addresses[i].optimize_route_id.toString() ===
              routes[j].toString()
            ) {
              removeIndexs.push(i)
            }
          }
        }
        console.log(removeIndexs)
        this.addresses = this.addresses.filter((value, index) =>{
          return removeIndexs.indexOf(index) === -1;
        })
        console.log(this.addresses)

        if (this.addresses.length > 0) {
          this.center = {
            lat: Number(this.addresses[this.addresses.length - 1].latitude),
            lng: Number(this.addresses[this.addresses.length - 1].longitude),
          }
        } else {
          this.center = {
            lat: Number(this.point.optimize_point_latitude),
            lng: Number(this.point.optimize_point_longitude),
          }
        }
        // for (let i = 0; i < response.data.route.length; i++) {
        //   for (let j = 0; j < this.addresses.length; j++) {
        //     if (response.data.route[i].optimize_route_id === this.addresses[j].optimize_route_id) {
        //       this.addresses[j].plan_no = response.data.plan_no.toString();
        //       this.addresses[j].order = i.toString();
        //       if (i === 0) {
        //         this.addresses[j].start_point = true;
        //         this.addresses[j].end_point = false;
        //       }
        //       if (i === response.data.route.length - 1) {
        //         this.addresses[j].start_point = false;
        //         this.addresses[j].end_point = true;
        //       }
        //       break
        //     }
        //   }
        // }
      } catch (e) {
        this.isLoading = false
        if (
          (e as any).response.data.message &&
          (e as any).response.data.message === 'Unauthenticated.'
        ) {
          alert('Session is expired')
          this.clear()
          router.push({ name: 'signin' })
        }
      }
    },
    async changeStartPoint(optimize_route_id:string, driver_index:string){
      try {
        console.log(optimize_route_id, driver_index);
        this.isLoading = true
        let data = {
          optimization_token: this.optimization_token,
          optimize_route_id: optimize_route_id.toString(),
          driver_index: driver_index,
        }
        let url = ''
        url = config.api.optimization.UPDATE_FIRST_POINT
        axios.defaults.headers.common['Authorization'] =
          'Bearer ' + this.access_token
        let response = (await axios.put(
          url, data
        )).data
        console.log(response)
        this.isLoading = false
      }catch(e){
        this.isLoading = false
        if (
          (e as any).response.data.message &&
          (e as any).response.data.message === 'Unauthenticated.'
        ) {
          alert('Session is expired')
          this.clear()
          router.push({ name: 'signin' })
        }
      }
    },
    async changeFinishPoint(optimize_route_id:string, driver_index:string){
      try {
        console.log(optimize_route_id, driver_index);
        this.isLoading = true
        let data = {
          optimization_token: this.optimization_token,
          optimize_route_id: optimize_route_id.toString(),
          driver_index: driver_index,
        }
        let url = ''
        url = config.api.optimization.UPDATE_FIRST_POINT
        axios.defaults.headers.common['Authorization'] =
          'Bearer ' + this.access_token
        let response = (await axios.put(
          url, data
        )).data
        console.log(response)
        this.isLoading = false
      }catch(e){
        this.isLoading = false
        if (
          (e as any).response.data.message &&
          (e as any).response.data.message === 'Unauthenticated.'
        ) {
          alert('Session is expired')
          this.clear()
          router.push({ name: 'signin' })
        }
      }
    },
    async updateOptimizePoint() {
      try {
        this.isLoading = true
        let response = await axios.post(config.api.visitor.UPDATE_POINT, {
          optimize_point_address: this.point.optimize_point_address,
          optimize_point_latitude: this.point.optimize_point_latitude,
          optimization_token: this.optimization_token,
          optimize_point_longitude: this.point.optimize_point_longitude,
          driver_count: this.numberOfDrivers,
          min_count: this.minDrivers,
          max_count: this.maxDrivers,
          algorithm_id: this.algorithm,
          effective_radius: this.effective_radius,
          load_upload_time: this.load_upload_time,
        })
        this.isLoading = false
        return response
      } catch (e) {
        this.isLoading = false
        if (
          (e as any).response.data.message &&
          (e as any).response.data.message === 'Unauthenticated.'
        ) {
          alert('Session is expired')
          this.clear()
          router.push({ name: 'signin' })
        }
      }
    },
    async sendAddressFile(fileData: any) {
      try {
        this.isLoading = true
        let url = ''
        if (this.getAccessToken === '') {
          url = config.api.visitor.ADDRESS_LIST_FILE
        } else {
          url = config.api.visitor.ADDRESS_LIST_FILE
          axios.defaults.headers.common['Authorization'] =
            'Bearer ' + this.access_token
        }


        let response = await (
          await axios.post(url, fileData)
        ).data
        console.log(response)
        this.isLoading = false
        this.markers = []
        this.addresses = []
        response.data.map((item: any) => {
          this.addresses.push({
            address: item.address,
            latitude: Number(item.latitude),
            longitude: Number(item.longitude),
            message: '',
            optimize_route_id: item.optimize_route_id,
            status: item.status,
            apartment_no: item.apartment,
            checked: false,
            description: item.description,
            contact_person: item.contact_person,
            phone_prefix: item.phone_prefix,
            phone: item.phone,
            country_code: '',
            is_enabled: item.is_enabled,
            plan_no: '0',
            start_point: false,
            end_point: false,
            order: '0',
            eye: true,
            position: {
              lat: Number(item.latitude),
              lng: Number(item.longitude),
            },
          })
          this.markers.push({
            optimize_route_id: item.optimize_route_id,
            address: item.address,
            position: {
              lat: Number(item.latitude),
              lng: Number(item.longitude),
            },
          })
          this.center = {
            lat: Number(item.latitude),
            lng: Number(item.longitude),
          }
          this.calculateBoundCenter()
        })
      } catch (e) {
        this.isLoading = false
        if (
          (e as any).response.data.message &&
          (e as any).response.data.message === 'Unauthenticated.'
        ) {
          alert('Session is expired')
          this.clear()
          router.push({ name: 'signin' })
        }
      }
    },
    async returnStore(apt: string) {
      try {
        this.isLoading = true
        axios.defaults.headers.common['Authorization'] =
          'Bearer ' + this.access_token
        let response = await axios.post(config.api.optimization.RETURN_STORE, {
          optimization_token: this.optimization_token,
          new_store_address: this.store.new_store_address,
          new_store_latitude: this.store.new_store_latitude,
          new_store_longitude: this.store.new_store_longitude,
        })
        this.isLoading = false
        return response
      } catch (e) {
        this.isLoading = false
        if (
          (e as any).response.data.message &&
          (e as any).response.data.message === 'Unauthenticated.'
        ) {
          alert('Session is expired')
          this.clear()
          router.push({ name: 'signin' })
        }
      }
    },
    async updateAlgorithm(driver_index: string) {
      try {
        this.isLoading = true
        let data = {
          optimization_token: this.optimization_token,
          driver_index: driver_index,
          algorithm_id: this.algorithm
        }
        let url = ''
        url = config.api.optimization.UPDATE_ALGORITHM
        axios.defaults.headers.common['Authorization'] =
          'Bearer ' + this.access_token

        let response = (await axios.put(
          url, data
        )).data
        console.log(response)
        this.isLoading = false
      } catch (e) {
        this.isLoading = false
        if (
          (e as any).response.data.message &&
          (e as any).response.data.message === 'Unauthenticated.'
        ) {
          alert('Session is expired')
          this.clear()
          router.push({ name: 'signin' })
        }
      }
    },
    async divideAndOptimize() {
      try {
        this.clearOptimizeRoutes()
        this.isLoading = true
        axios.defaults.headers.common['Authorization'] =
          'Bearer ' + this.access_token
        let response = await axios.post(config.api.optimization.DIVIDE_AND_OPTIMIZE, {
          optimization_token: this.optimization_token,
        })
        let resString = JSON.stringify(response.data.data);
        let jsonRes =  JSON.parse(resString)
        this.detailRoutes = jsonRes

        this.isLoading = false
        if (response.data.status !== 0) {
          this.optimized_routes = response.data as IOptimizeRoutes
          this.optimized_routes.data = this.optimized_routes.data.map(
            (item: any) => {
              let temp = item.route.filter((route: any) => route !== null)
              return temp
            },
          )
          this.charged_routes_count = this.optimized_routes.charged_routes_count
          this.credit_charged = this.optimized_routes.credit_charged
          this.uncharged_routes_count = this.optimized_routes.uncharged_routes_count
          for (let k = 0; k < this.optimized_routes.data.length; k++) {
            for (let j = 0; j < this.optimized_routes.data[k].length; j++) {
              for (let i = 0; i < this.addresses.length; i++) {
                if (
                  this.addresses[i].optimize_route_id ===
                  this.optimized_routes.data[k][j].optimize_route_id
                ) {
                  this.addresses[i].plan_no = (k + 1).toString()
                  this.addresses[i].start_point = j === 0 ? true : false
                  this.addresses[i].end_point =
                    j === this.optimized_routes.data[k].length - 1
                      ? true
                      : false
                  this.addresses[i].order = j.toString()
                }
              }
            }
          }
        }
        return response.data
      } catch (e) {
        this.isLoading = false
        if (
          (e as any).response.data.message &&
          (e as any).response.data.message === 'Unauthenticated.'
        ) {
          alert('Session is expired')
          this.clear()
          router.push({ name: 'signin' })
        }
        if ((e as any).response.status === 422) {
          return (e as any).response.data
        }
      }
    },
    async signupUser(
      fullname: string,
      email: string,
      password: string,
      confirm: string,
    ) {
      try {
        this.isLoading = true
        let response = await axios.post(config.api.customer.REGISTER, {
          customer_name: fullname,
          customer_email: email,
          customer_password: password,
          customer_password_confirmation: confirm,
          optimization_token: this.optimization_token,
        })
        console.log(response.data)
        this.user = response.data.data
        if (response.data.access_token) {
          this.access_token = response.data.access_token
        }
        this.isLoading = false
      } catch (e) {
        this.isLoading = false
        if (
          (e as any).response.data.message &&
          (e as any).response.data.message === 'Unauthenticated.'
        ) {
          alert('Session is expired')
          this.clear()
          router.push({ name: 'signin' })
        }
      }
    },
    async loginUser(email: string, password: string) {
      try {
        this.isLoading = true
        let response = await axios.post(config.api.customer.LOGIN, {
          customer_email: email,
          customer_password: password,
          optimization_token: this.optimization_token,
        })
        console.log("login")
        console.log(response.data)
        this.user = response.data.data
        if (response.data.access_token) {
          this.access_token = response.data.access_token
        }
        this.isLoading = false
        return response
      } catch (e) {
        this.isLoading = false
        return {
          data: (e as any).response.data
        }
      }
    },
    async fogotPassword(email: string) {
      try {
        this.isLoading = true
        let response = await axios.post(config.api.customer.FORGOT_PASSWORD, {
          customer_email: email,
        })
        alert(response.data.message)
        this.isLoading = false
        return response
      } catch (e) {
        this.isLoading = false
        if (
          (e as any).response.data.message &&
          (e as any).response.data.message === 'Unauthenticated.'
        ) {
          alert('Session is expired')
          this.clear()
          router.push({ name: 'signin' })
        }
      }
    },
    async resetPassword(
      id: string,
      verification: string,
      password: string,
      confirm: string,
    ) {
      try {
        this.isLoading = true
        let response = await axios.get(
          config.api.customer.RESET_PASSWORD + '/' + id,
          {
            data: {
              verification_code: verification,
              new_customer_password: password,
              new_customer_password_confirmation: confirm,
            },
          },
        )
        console.log(response.data)
        alert(response.data.message)
        this.isLoading = false
      } catch (e) {
        this.isLoading = false
        if (
          (e as any).response.data.message &&
          (e as any).response.data.message === 'Unauthenticated.'
        ) {
          alert('Session is expired')
          this.clear()
          router.push({ name: 'signin' })
        }
      }
    },
    async logOutFromSystem() {
      try {
        axios.defaults.headers.common['Authorization'] =
          'Bearer ' + this.access_token
        this.isLoading = true
        let response = await axios.get(config.api.customer.LOGOUT)
        console.log(response.data)
        this.setAccessToken('')
        this.clear()
        this.isLoading = false
        return response.data
      } catch (e) {
        this.isLoading = false
        if (
          (e as any).response.data.message &&
          (e as any).response.data.message === 'Unauthenticated.'
        ) {
          this.setAccessToken('')
          this.clear()
          router.push({ name: 'signin' })
          alert((e as any).response.data.message)
        }
      }
    },
    async viewActiveOptimizePoint() {
      try {
        axios.defaults.headers.common['Authorization'] =
          'Bearer ' + this.access_token
        this.isLoading = true
        let response = await axios.get(
          config.api.optimize_point.VIEW_ACTIVE_OPTIMIZE_POINT,
          {
            data: {
              optimization_token: this.optimization_token,
            },
          },
        )
        this.isLoading = false
        return response
      } catch (e) {
        this.isLoading = false
        if (
          (e as any).response.data.message &&
          (e as any).response.data.message === 'Unauthenticated.'
        ) {
          alert('Session is expired')
          this.clear()
          router.push({ name: 'signin' })
        }
      }
    },
    async updatePassword(current: string, password: string, confirm: string) {
      try {
        axios.defaults.headers.common['Authorization'] =
          'Bearer ' + this.access_token
        this.isLoading = true
        let response = await axios.post(config.api.customer.PASSWORD_UPDATE, {
          current_password: current,
          new_customer_password: password,
          new_customer_password_confirmation: confirm,
        })
        this.isLoading = false
        return response.data
      } catch (e) {
        this.isLoading = false
        console.log(e)
        if (
          (e as any).response.data.message &&
          (e as any).response.data.message === 'Unauthenticated.'
        ) {
          alert('Session is expired')
          this.clear()
          router.push({ name: 'signin' })
        }
        if (!(e as any).response.data.success) {
          return (e as any).response.data
        }
      }
    },
    async updateInformation(
      name: string,
      company: string,
      phone: string,
      address: string,
      city: string,
      code: string,
      country: string,
    ) {
      try {
        axios.defaults.headers.common['Authorization'] =
          'Bearer ' + this.access_token
        this.isLoading = true
        console.log(city)
        let response = await axios.put(config.api.customer.PROFILE_UPDATE + this.user.customer_id, {
          customer_name: name,
          customer_address: address,
          customer_phone_prefix: '1',
          customer_phone: phone,
          company_name: company,
          company_city: city,
          company_country: country,
          company_postal_code: code,
        })
        console.log(response.data)
        this.user = response.data.data
        this.isLoading = false
        return response.data
      } catch (e) {
        this.isLoading = false
        if (
          (e as any).response.data.message &&
          (e as any).response.data.message === 'Unauthenticated.'
        ) {
          alert('Session is expired')
          this.clear()
          router.push({ name: 'signin' })
        }
      }
    },
  },
  persist: {
    enabled: true,
  },
})
