<script setup lang="ts">
import { RouterView } from "vue-router";
import Loading from 'vue-loading-overlay';
import { storeToRefs } from 'pinia'
import { useAddressStore } from '@/stores/address'
import LayoutWrapper from "./components/layouts/LayoutWrapper.vue";

const { isLoading } = storeToRefs(useAddressStore())

</script>

<template>
  <main class="relative" id="app">
    <div class="w-full bg-[rgba(0,0,0,0.5)] fixed flex justify-center items-center h-full z-40" v-if="isLoading">
      <loading v-model:active="isLoading" :is-full-page="true" />
    </div>
    <LayoutWrapper>
      <RouterView />
    </LayoutWrapper>
  </main>
</template>

<style scoped>
</style>
