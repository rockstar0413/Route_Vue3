import { createApp } from 'vue'
import { createPinia } from 'pinia'
import piniaPersist from 'pinia-plugin-persist'
import App from './App.vue'
import router from './router'
import 'maz-ui/css/main.css'
import { library } from '@fortawesome/fontawesome-svg-core'
import { FontAwesomeIcon } from '@fortawesome/vue-fontawesome'
import {
  faAngleDown,
  faAngleUp,
  faEye,
  faHome,
  faCheck,
  faArrowRight,
  faUser,
  faPlus,
  faGear,
  faCommentsDollar,
  faDollarSign,
  faArrowsUpDown,
  faArrowLeft,
  faXmark,
  faFileInvoice,
  faEyeSlash,
  faLocationPin,
  faLocationDot
} from '@fortawesome/free-solid-svg-icons'
import {
  faCreditCard
} from '@fortawesome/free-regular-svg-icons'
import './assets/scss/main.scss'
import 'tw-elements';

library.add(
  faAngleDown,
  faAngleUp,
  faHome,
  faEye,
  faCheck,
  faArrowRight,
  faUser,
  faCreditCard,
  faPlus,
  faGear,
  faCommentsDollar,
  faDollarSign,
  faArrowsUpDown,
  faArrowLeft,
  faXmark,
  faFileInvoice,
  faEyeSlash,
  faLocationPin,
  faLocationDot
)

const app = createApp(App).component('font-awesome-icon', FontAwesomeIcon)
const pinia = createPinia()
pinia.use(piniaPersist)
app.use(pinia)

app.use(router)

app.mount('#app')
