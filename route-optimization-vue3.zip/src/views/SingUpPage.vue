<script setup lang="ts">
  import { computed, ref } from 'vue'
  import { useAddressStore } from '@/stores/address'
  import { storeToRefs } from 'pinia'
  import router from '@/router'
  const isVisible = ref(false)
  const isVisible1 = ref(false)
  const fullname = ref('')
  const email = ref('')
  const password = ref('')
  const confirm = ref('')
  const password_min =ref(8)
  const password_max =ref(30)

  const errorPassword = ref(false)
  const errorEmail = ref(false)
  const errorFullname = ref(false)
  const errorConfirm = ref(false)
  const strongPassword = ref(5)
  const strongMessage = ref("")
  const errorMessage = ref("Please fill out fields")
  const { getAccessToken, getBeforeRoute } = storeToRefs(useAddressStore())
  const type = computed(()=>{
    let type = isVisible.value?'text':'password';
    return type;
  })
  const type1 = computed(()=>{
    let type1 = isVisible1.value?'text':'password';
    return type1;
  })
  const showPassword = () =>{
    isVisible.value = true;
  }
  const hidePassword = () =>{
    isVisible.value = false;
  }
  const showPassword1 = () =>{
    isVisible1.value = true;
  }
  const hidePassword1 = () =>{
    isVisible1.value = false;
  }
  const changeEmail = (value:string) =>{
    email.value = value;
    if(/\S+@\S+\.\S+/.test(email.value)){
      errorEmail.value = false;
    }else{
      errorEmail.value = true;
      errorMessage.value ="Invalid Email."
    }
    return /\S+@\S+\.\S+/.test(email.value);
  }
  const changeFullname = (value:string) =>{
    fullname.value = value;
    if(fullname.value.length>0){
      errorFullname.value = false;
    }else{
      errorFullname.value = true;
      errorMessage.value = 'Please fill out Full name';
    }
    return /\S+@\S+\.\S+/.test(email.value);
  }
  const changeConfirm = (value:string) =>{
    confirm.value = value;
    if(confirm.value===password.value){
      errorConfirm.value = false;
    }else{
      errorConfirm.value = true;
      errorMessage.value = 'Must be matched.';
    }
    return /\S+@\S+\.\S+/.test(email.value);
  }
  //password validation
  const containsUppercase= computed(()=>{
    return /[A-Z]/.test(password.value)
  })
  const containsLowercase=computed(()=>{
    return /[a-z]/.test(password.value)
  })
  const containsNumber=computed(()=>{
    return /[0-9]/.test(password.value)
  })
  const containsSpecial=computed(()=>{
    return /[ !@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(password.value)
  })
  const minLength=computed(()=>{
    return password.value.length>=password_min.value?true:false;
  })
  const maxLength=computed(()=>{
    return password.value.length<=password_max.value?true:false;
  })
  const changePassword = (value:string)=>{
    password.value = value;
    let temp = 0;
    if(minLength.value)temp++;
    if(containsSpecial.value)temp++;
    if(containsNumber.value)temp++;
    if(containsLowercase.value)temp++;
    if(containsUppercase.value)temp++;
    strongPassword.value=temp;
    if(strongPassword.value ===0)strongMessage.value="This field is requried";
    if(strongPassword.value ===1)strongMessage.value="The password is very weak";
    if(strongPassword.value ===2)strongMessage.value="The password is weak";
    if(strongPassword.value ===3)strongMessage.value="The password is normal";
    if(strongPassword.value ===4)strongMessage.value="The password is medium";
    if(strongPassword.value ===5)strongMessage.value="The password is strong";
    if(temp>2){
      errorPassword.value =  false;
    }else{
      errorPassword.value =  true;
      errorMessage.value = "Password is weak."
    }
  }
  const register = async () =>{
    changeConfirm(confirm.value)
    changePassword(password.value)
    changeEmail(email.value)
    changeFullname(fullname.value)
    if(!errorFullname.value&&!errorEmail.value&&!errorPassword.value&&!errorConfirm.value){
      const { signupUser } = useAddressStore();
      await signupUser(fullname.value, email.value, password.value, confirm.value)
      if(getAccessToken.value!=="") {
        router.push({name:getBeforeRoute.value.toString() ||'provider'})
      }else{
        alert("Use another email")
      }
    }else{
      alert(errorMessage.value)
    }
  }
</script>
<template>
  <div class="flex justify-center items-center h-[calc(100vh)] pt-[72px] px-10 lg:px-0">
    <div class="!bg-white text-left p-7 rounded-2xl w-full lg:w-1/3">
      <div class="flex items-center justify-center space-x-3 mb-5">
        <h2
          class="font-bold text-2xl leading-6 text-gray-800 dark:text-white cursor-pointer select-none"
        >
          <span>Routes</span>
          <span class="text-sky-700">now</span>
        </h2>
      </div>
      <div class="font-bold text-xl text-center mb-4">Try flanroute free for 7 days</div>
      <div class="mb-4 ">
        <div class="mb-1">Full name</div>
        <div class="relative">
          <input type="text" id="fullname"
          :class="['bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg  block w-full p-2 h-[48px]', !errorFullname?'border-gray-300 focus-visible:outline-blue-300':'border-red-500 focus-visible:outline-red-500']"
            placeholder="Full name" :value="fullname" @input="(e)=>changeFullname((e.target as any).value)"/>
        </div>
        <div class="text-red-500 text-xs" v-if="errorFullname" > The field is requried.</div>
      </div>
      <div class="mb-4 ">
        <div class="mb-1">Work email</div>
        <div class="relative">
          <input type="text" id="email"
            :class="['bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg  block w-full p-2 h-[48px]', !errorEmail?'border-gray-300 focus-visible:outline-blue-300':'border-red-500 focus-visible:outline-red-500']"
            placeholder="Your email" :value="email" @input="(e)=>changeEmail((e.target as any).value)"/>
        </div>
        <div class="text-red-500 text-xs" v-if="errorEmail" > The email is invalid.</div>
      </div>
      <div class="mb-2">
        <div class="mb-1">Password</div>
        <div class="relative">
          <input :type="type" id="password"
          :class="['bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg  block w-full p-2 h-[48px]', strongPassword>2?'border-gray-300 focus-visible:outline-blue-300':'border-red-500 focus-visible:outline-red-500']"
            placeholder="Your password" :value="password" @input="(e)=>changePassword((e.target as any).value)" />
            <font-awesome-icon icon="fa-solid fa-eye" class="text-gray-400 absolute top-[17px] right-4 cursor-pointer hover:text-blue-500" @mousedown="showPassword" @mouseup="hidePassword"   />  
        </div>
        <div :class="['text-xs', strongPassword===0?'text-red-500':strongPassword<3?'text-pink-500':strongPassword<5?'text-sky-500':'text-green-500']" v-if="errorPassword"> {{strongMessage}}</div>
      </div>
      <div class="mb-2">
        <div class="mb-1">Confirm password</div>
        <div class="relative">
          <input :type="type1" id="confirm"
          :class="['bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg  block w-full p-2 h-[48px]', !errorConfirm?'border-gray-300 focus-visible:outline-blue-300':'border-red-500 focus-visible:outline-red-500']"
            placeholder="Confirm password" :value="confirm" @input="(e)=>changeConfirm((e.target as any).value)"/>
            <font-awesome-icon icon="fa-solid fa-eye" class="text-gray-400 absolute top-[17px] right-4 cursor-pointer hover:text-blue-500" @mousedown="showPassword1" @mouseup="hidePassword1"   />  
        </div>
        <div class="text-red-500 text-xs" v-if="errorConfirm" > Must be matched.</div>
      </div>
      <div class="flex justify-center mt-3">
        <div class="text-sm">
          By signing up, you agree to our <span class="cursor-pointer  font-medium">Terms & Privacy Policy</span>.
        </div>
      </div>
      <div class="mt-8">
        <button class="bg-[#0083FC] hover:bg-[#0083CC] h-[40px] rounded-lg text-white text-base font-medium w-full mr-5" @click="register()">Sign up for flanroute</button>
      </div>
      <div class="flex justify-center mt-5">
        <div class="">
          Already have an account?   <span class="text-blue-500 hover:text-blue-700 font-medium cursor-pointer"><RouterLink to="/auth/signin">Log in</RouterLink></span>
        </div>
      </div>
    </div>
  </div>
</template>

<style></style>