<script setup lang="ts">
import { ref, onMounted } from 'vue';
import { storeToRefs } from 'pinia'
import { useAddressStore } from '@/stores/address'
import router from '@/router';
import RouteTypeVue from '@/components/RouteType.vue';
import { useRoute } from 'vue-router'

const { getOptimizedRoutes } = storeToRefs(useAddressStore())
const isCheck = ref(false)

const { setBeforeRoute, changeAllRouteVisible } = useAddressStore()
const route = useRoute()
const backPage = () => {
  changeAllRouteVisible()
  router.push({ name: "preferences" });
}
const nextPage = () => {
  changeAllRouteVisible()
  router.push({ name: "plan" });
}
onMounted(() => {
  setBeforeRoute(route.name as any)
});
const changeChecked = () => {
  isCheck.value = !isCheck.value;
}

</script>

<template>
  <div class="">

    <div class="w-full">
      <div class="font-bold text-lg text-black px-7 py-3">
        Manage Routes
      </div>
      <div class="bg-white py-3  h-[calc(100vh-72px-52px)] relative">
        <div class="px-7" v-for="(route, index) in getOptimizedRoutes.data">
          <route-type-vue :num="index + 1" :stop="route.length" time=169 mile=100 :assign="true" v-if="true" />
        </div>
        <div class="flex justify-between items-center px-7 mt-7 mb-3">
          <div class="text-[#202027] text-md font-bold flex items-center">
            <span>Unassigned routes</span>
            <img src="@/assets/images/info.svg" alt="info" class="ml-2 w-[20px] h-[20px]">
          </div>
          <div class=" flex items-center">
            <input type="checkbox" class="w-[20px] h-[20px] rounded border border-gray-100 bg-gray-300" check="isCheck"
              @change="changeChecked()" />
            <div class="ml-3">Optimize unassigned routes</div>
          </div>
        </div>
        <!-- <div class="px-7" v-for="(route, index) in getOptimizedRoutes.data">
          <route-type-vue :num="route.plan_no" :stop="route.routes_total" time=169 mile=100 :assign="false"
            v-if="getOptimizedRoutes.uncharged_routes_count === 0 " />
        </div> -->
        <div class="mt-10 w-full flex items-center">
          <div class="grid grid-cols-2 gap-3 px-7  w-full">
            <div class="col-span-2 lg:col-span-1 flex items-center justify-center lg:justify-start ">
              <button
                class="border border-[#CCD2E2] hover:border-[#CCD2E2] rounded-lg text-[#64748B] hover:[#CCD2E2] font-medium px-5 mr-5 h-[40px] flex items-center"
                @click="backPage()">
                <img src="@/assets/images/returnH.svg" alt="returnH" class="mr-2">
                Re-Optimization Algorythm
              </button>
            </div>
            <div class="col-span-2 lg:col-span-1 w-full">
              <div class="flex items-center justify-center lg:justify-end">
                <div>
                  <button
                    class="border border-sky-500 hover:border-sky-700 rounded-lg text-sky-500 hover:text-sky-700 font-medium px-5 mr-5 h-[40px]"
                    @click="backPage()">Back</button>
                  <button class="bg-sky-500 hover:bg-sky-700 rounded-lg text-white font-medium px-5 h-[40px]"
                    @click="nextPage()">Dispatch to Drivers</button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>

</style>
