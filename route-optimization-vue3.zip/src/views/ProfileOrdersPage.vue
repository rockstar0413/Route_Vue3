<script setup lang="ts">
import { computed, ref, onMounted, onBeforeMount } from 'vue'
import { useAddressStore } from '@/stores/address'
import { storeToRefs } from 'pinia'
import router from '@/router'
import RouteOrder from '@/components/RouteOrder.vue'

const isVisible = ref(false)
const current = ref('')
const password = ref('')
const confirm = ref('')
const { getAccessToken, getBeforeRoute, getUser } = storeToRefs(
  useAddressStore(),
)
const type = computed(() => {
  let type = isVisible.value ? 'text' : 'password'
  return type
})
onBeforeMount(() => {
  const { getAccessToken } = useAddressStore()

  if (getAccessToken && getAccessToken !== '') {

  } else {
    router.push({ name: 'signin' })
  }
})

const updatePasswordFunc = async () => {
  if (current.value !== '' && password.value !== '' && confirm.value !== '') {
    const { updatePassword } = useAddressStore()
    await updatePassword(current.value, password.value, confirm.value)
    alert('password changed!')
  } else {
    alert('Please fill out all fields.')
  }
}
const logout = async () => {
  const { logOutFromSystem } = useAddressStore()
  await logOutFromSystem()
  router.push({ name: 'landing' })
}
const mockData = [
  {
    ID: "01",
    name: "Route 1",
    numberRoute: 3,
    date: "2020-05-06",
    status: "Completed",
    drivers: [
      {
        name: "Driver 1",
        numberStop: 23,
        miliage: 255,
        time: "3h"
      },
      {
        name: "Driver 1",
        numberStop: 23,
        miliage: 255,
        time: "3h"
      },
    ]
  },
  {
    ID: "02",
    name: "Route 2",
    numberRoute: 3,
    date: "2020-05-06",
    status: "Unused",
    drivers: [
      {
        name: "Driver 1",
        numberStop: 23,
        miliage: 255,
        time: "3h"
      },
      {
        name: "Driver 1",
        numberStop: 23,
        miliage: 255,
        time: "3h"
      },
    ]
  },
  {
    ID: "03",
    name: "Route 3",
    numberRoute: 3,
    date: "2020-05-06",
    status: "In-process",
    drivers: [
      {
        name: "Driver 1",
        numberStop: 23,
        miliage: 255,
        time: "3h"
      },
      {
        name: "Driver 1",
        numberStop: 23,
        miliage: 255,
        time: "3h"
      },
    ]
  }
]
</script>
<template>
  <div class="text-base">
    <div class="text-lg font-bold px-7 py-3">My orders</div>
    <div class="h-[1px] w-full bg-[#ECECEC]"></div>
    <div class="w-full px-7 pt-4">
      <div class="flex py-1 bg-white">
        <div
          class="w-full bg-white rounded flex items-center p-1  h-[40px] text-[#64748B] text-[12px] font-[500]">
          <div class="basis-[5%]">
            ID
          </div>
          <div class="basis-[35%]">
            Order name
          </div>
          <div class="basis-[20%]">
            Number of routes
          </div>
          <div class="basis-[15%]">
            Date
          </div>
          <div class="basis-[25%]">
            Status
          </div>
        </div>
      </div>
      <div class="h-[1px] w-full bg-[#ECECEC]"></div>
      <div
        class="w-full flex rounded-lg border border-transparent"
        v-for="(order, index) in mockData">
        <route-order :order="order" />
      </div>
    </div>
  </div>
</template>

<style>

</style>
