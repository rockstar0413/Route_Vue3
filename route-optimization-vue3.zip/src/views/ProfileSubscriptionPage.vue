<script setup lang="ts">
import { computed, ref, onMounted, onBeforeMount } from 'vue'
import { useAddressStore } from '@/stores/address'
import { storeToRefs } from 'pinia'
import router from '@/router'
import { RouterView } from 'vue-router'

const isVisible = ref(false)
const email = ref('')
const password = ref('')
const { getAccessToken, getBeforeRoute, getUser } = storeToRefs(
  useAddressStore(),
)
const type = computed(() => {
  let type = isVisible.value ? 'text' : 'password'
  return type
})
onBeforeMount(() => {
  const { getAccessToken} = useAddressStore()
  if (getAccessToken && getAccessToken !== '') {

  } else {
    router.push({ name: 'signin' })
  }
})

</script>
<template>
  <div class="text-base">
    <div class="text-lg font-bold px-7 py-3">Subscription</div>
    <div class="h-[1px] w-full bg-[#ECECEC]"></div>
      <div
        class="flex justify-between items-center mt-10 grid grid-cols-2 gap-10 px-7 pb-7"
      >
        <div
          class="col-span-2 lg:col-span-1  border border-gray-300 rounded-2xl py-10"
        >
          <div class="text-2xl font-bold mb-2 px-10">
            Essentials
          </div>
          <div class="text-xs text-[#64748B] mb-4 px-10">
            Everything you need to plan and dispatch optimized routes
          </div>
          <div class="flex items-center px-10">
            <div class="text-4xl font-bold text-[#202124] mr-3">$29</div>
            <div class="text-xs text-[#64748B]">/dirver/month</div>
          </div>
          <div class="px-10">
            <button
              class="bg-[#0083FC] hover:bg-[#0083CC] h-[48px] w-full rounded-lg text-white text-base font-medium px-10 mr-5 my-7"
            >
              Try free for 7 days
            </button>
          </div>
          <div class="h-[1px] bg-gray-300 mb-5"></div>
          <div class="text-[#202124] text-lg px-10">
            <div class="font-medium">KEY FEATURES</div>
            <div>
              <font-awesome-icon
                icon="fa-solid fa-check"
                class="text-green-500 ml-2 mt-4"
              />
              <span class="ml-4">Plan 100 stops at once</span>
            </div>
            <div>
              <font-awesome-icon
                icon="fa-solid fa-check"
                class="text-green-500 ml-2 mt-4"
              />
              <span class="ml-4">Dispatch routes to driver app</span>
            </div>
            <div>
              <font-awesome-icon
                icon="fa-solid fa-check"
                class="text-green-500 ml-2 mt-4"
              />
              <span class="ml-4">Plan optimized routes in minutes</span>
            </div>
            <div>
              <font-awesome-icon
                icon="fa-solid fa-check"
                class="text-green-500 ml-2 mt-4"
              />
              <span class="ml-4">Web Integration</span>
            </div>
          </div>
        </div>
        <div
          class="col-span-2 lg:col-span-1 border border-gray-300 rounded-2xl py-10"
        >
        <div class="flex items-center justify-between px-10">
            <div class="text-2xl font-bold mb-2">
              Professional
            </div>
            <div class="bg-sky-100 text-sky-500 p-2 px-5 rounded-xl">Popular</div>
          </div>
          <div class="text-xs text-[#64748B] mb-4 px-10">
            Everything you need to plan and dispatch optimized routes
          </div>
          <div class="flex items-center px-10">
            <div class="text-4xl font-bold text-[#202124] mr-3">$49</div>
            <div class="text-xs text-[#64748B]">/dirver/month</div>
          </div>
          <div class="px-10">
            <button
              class="bg-[#0083FC] hover:bg-[#0083CC] h-[48px] w-full rounded-lg text-white text-base font-medium px-10 mr-5 my-7"
            >
              Try free for 7 days
            </button>
          </div>
          <div class="h-[1px] bg-gray-300 mb-5"></div>
          <div class="text-[#202124] text-lg px-10">
            <div class="font-medium">KEY FEATURES</div>
            <div>
              <font-awesome-icon
                icon="fa-solid fa-check"
                class="text-green-500 ml-2 mt-4"
              />
              <span class="ml-4">Plan 100 stops at once</span>
            </div>
            <div>
              <font-awesome-icon
                icon="fa-solid fa-check"
                class="text-green-500 ml-2 mt-4"
              />
              <span class="ml-4">Dispatch routes to driver app</span>
            </div>
            <div>
              <font-awesome-icon
                icon="fa-solid fa-check"
                class="text-green-500 ml-2 mt-4"
              />
              <span class="ml-4">Plan optimized routes in minutes</span>
            </div>
            <div>
              <font-awesome-icon
                icon="fa-solid fa-check"
                class="text-green-500 ml-2 mt-4"
              />
              <span class="ml-4">Web Integration</span>
            </div>
          </div>
        </div>
        <div
          class="col-span-2 lg:col-span-1 border border-gray-300 rounded-2xl py-10"
        >
          <div class="flex items-center justify-between px-10">
            <div class="text-2xl font-bold mb-2">
              Premium
            </div>
          </div>
          <div class="text-xs text-[#64748B] mb-4 px-10">
            Scale your delivery operations with driver management tools
          </div>
          <div class="flex items-center px-10">
            <div class="text-4xl font-bold text-[#202124] mr-3">$49</div>
            <div class="text-xs text-[#64748B]">/dirver/month</div>
          </div>
          <div class="px-10">
            <button
              class="bg-transparent border-[3px] border-sky-500 h-[48px] text-sky-500 rounded-lg w-full px-10 mr-5 my-7 font-medium flex items-center justify-center"
            >
              Contact sales
            </button>
          </div>
          <div class="h-[1px] bg-gray-300 mb-5"></div>
          <div class="text-[#202124] text-lg px-10">
            <div class="font-medium">KEY FEATURES</div>
            <div>
              <font-awesome-icon
                icon="fa-solid fa-check"
                class="text-green-500 ml-2 mt-4"
              />
              <span class="ml-4">Everything in Recipient</span>
            </div>
            <div>
              <font-awesome-icon
                icon="fa-solid fa-check"
                class="text-green-500 ml-2 mt-4"
              />
              <span class="ml-4">Export data to other services</span>
            </div>
            <div class="h-[78px]">

            </div>
          </div>
        </div>
      </div>
  </div>
</template>

<style>

</style>
