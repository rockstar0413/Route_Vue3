<script setup lang="ts">
import { computed, ref, onBeforeMount } from 'vue'
import { useAddressStore } from '@/stores/address'
import { storeToRefs } from 'pinia'
import router from '@/router'
import { RouterView, useRoute } from 'vue-router'

const isVisible = ref(false)
const route = useRoute()

const { getUser } = storeToRefs(
  useAddressStore(),
)
const type = computed(() => {
  let type = isVisible.value ? 'text' : 'password'
  return type
})
onBeforeMount(() => {
  const { getAccessToken } = useAddressStore()
  if (getAccessToken && getAccessToken !== '') {

  } else {
    router.push({ name: 'signin' })
  }
})


const logout = async ()=>{
  const { logOutFromSystem } = useAddressStore()
  await logOutFromSystem()
  router.push({ name: 'landing' })
}
</script>
<template>
  <div class="h-[calc(100vh-72px)] pt-[72px] lg:px-0">
    <div class="bg-[#1C1E3108] px-10 py-5 h-[80px] w-full">
      <div class="text-2xl font-bold">My account</div>
    </div>
    <div class="px-10 py-7">
      <div class="grid grid-cols-3 gap-5">
        <div class="col-span-3 lg:col-span-1 bg-white rounded-xl p-4">
          <div class="flex items-center mb-3">
            <div class="h-[48px] w-[48px] bg-[#F2C94C] flex items-center justify-center rounded-full uppercase font-bold">
              {{getUser?.customer_name && getUser?.customer_name.split(' ').length>1 ? getUser.customer_name.split(' ')[0][0] + getUser.customer_name.split(' ')[1][0]:getUser.customer_name.split(' ')[0][0] }}
            </div>
            <div class="ml-3 text-lg font-medium">
              {{ getUser?.customer_name ? getUser.customer_name : '' }}
            </div>
          </div>
          <div class="p-3 flex justify-between bg-[#0083FC33] rounded-xl text-sm mb-2">
            <div class="">
              Available credit:
              <span class="font-bold">200</span>
            </div>
            <div class="text-[#FF7E00] hover:text-[#EF6E20] cursor-pointer">Upgrade</div>
          </div>
          <RouterLink to="/profile/account">
          <div :class="['p-3 flex items-center bg-white cursor-pointer rounded-xl text-sm font-medium mb-2', route.name==='account'?'bg-[#0083FC] text-white':'bg-white hover:bg-[#0083FC33] tex-black']">
            <div class="flex items-center">
              <font-awesome-icon icon="fa-solid fa-user" class="text-lg" />
              <div class=" ml-3">
                Account information
              </div>
            </div>
          </div>
        </RouterLink>
        <RouterLink to="/profile/subscription">
          <div :class="['p-3 flex items-center bg-white cursor-pointer rounded-xl text-sm font-medium mb-2', route.name==='subscription'?'bg-[#0083FC] text-white':'bg-white hover:bg-[#0083FC33] tex-black']">
            <div class="flex items-center">
              <font-awesome-icon icon="fa-solid fa-dollar-sign" class="text-lg" />
              <div class=" ml-3">
                Subscription
              </div>
            </div>
          </div>
        </RouterLink>
        <RouterLink to="/profile/orders">
          <div :class="['p-3 flex items-center bg-white cursor-pointer rounded-xl text-sm font-medium mb-2', route.name==='orders'?'bg-[#0083FC] text-white':'bg-white hover:bg-[#0083FC33] tex-black']">
            <div class="flex items-center">
              <font-awesome-icon icon="fa-solid fa-file-invoice" class="text-lg" />
              <div class=" ml-3">
                My orders
              </div>
            </div>
          </div>
        </RouterLink>
        <RouterLink to="/profile/card">
          <div :class="['p-3 flex items-center bg-white cursor-pointer rounded-xl text-sm font-medium mb-2', route.name==='card'?'bg-[#0083FC] text-white':'bg-white hover:bg-[#0083FC33] tex-black']">
            <div class="flex items-center">
              <font-awesome-icon icon="fa-regular fa-credit-card" class="text-lg"/>
              <div class=" ml-3 whitespace-nowrap">
                My cards
              </div>
            </div>
          </div>
        </RouterLink>
        <RouterLink to="/profile/change-password">
          <div :class="['p-3 flex items-center bg-white cursor-pointer rounded-xl text-sm font-medium mb-2', route.name==='change-password'?'bg-[#0083FC] text-white':'bg-white hover:bg-[#0083FC33] tex-black']">
            <div class="flex items-center">
              <font-awesome-icon icon="fa-solid fa-gear" class="text-lg" />
              <div class=" ml-3">
                Change password
              </div>
            </div>
          </div>
        </RouterLink>
          <div class="p-3 flex items-center bg-white hover:bg-[#0083FC33] cursor-pointer text-[#EB5757] rounded-xl text-sm font-medium mb-2" @click="logout()">
            <div class="">
              Log out
            </div>
          </div>
        </div>
        <div class="col-span-3 lg:col-span-2 bg-white rounded-xl">
          <RouterView />
        </div>
      </div>
    </div>
  </div>
</template>

<style>

</style>
