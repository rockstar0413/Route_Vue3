<script setup lang="ts">
import { ref, onMounted } from 'vue';
import { storeToRefs } from 'pinia'
import { useAddressStore } from '@/stores/address'
import router from '@/router';
import SendLinkRoute from '@/components/SendLinkRoute.vue';
import { useRoute } from 'vue-router'

const { getOptimizedRoutes } = storeToRefs(useAddressStore())
const isCheck = ref(false)

const { setBeforeRoute } = useAddressStore()
const route = useRoute()
const backPage = () => {
  router.push({ name: "routes" });
}
const nextPage = () => {
  router.push({ name: "routes" });
}
onMounted(() => {
  setBeforeRoute(route.name as any)
});
const changeChecked = () => {
  isCheck.value = !isCheck.value;
}

</script>

<template>
  <div class="">

    <div class="w-full">
      <div class="font-bold text-lg text-black px-7 py-3">
        Optimize Route Plan
      </div>
      <div class="bg-white py-3  h-[calc(100vh-72px-52px)] relative">
        <div class="px-7 flex justify-between items-center my-5">
          <div class="px-3 flex items-center">
            <input type="checkbox" class="w-[20px] h-[20px] rounded border border-gray-100 bg-gray-300" check="isCheck"/>
            <span class="text-sm text-[#64748B] ml-3">Select all</span>
          </div>
          <div class="flex">
            <div class="flex items-center mr-4 cursor-pointer">
              <img src="@/assets/images/DownloadIcon.svg" alt="returnH" class="mr-2">
              <span class="text-sm text-[#64748B] hover:text-sky-500">Generate excel</span>
            </div>
            <div class="flex items-center cursor-pointer">
              <img src="@/assets/images/PrintIcon.svg" alt="returnH" class="mr-2">
              <span class="text-sm text-[#64748B] hover:text-sky-500">Print</span>
            </div>
          </div>
        </div>
        <div class="px-7" v-for="(route, index) in getOptimizedRoutes.data">
          <send-link-route :num="index + 1" :stop="route.length" time=169 mile=100 :assign="true" v-if="true" />
        </div>
        <div class="mt-10 w-full flex items-center justify-end px-7">
          <button class="border border-sky-500 hover:border-sky-700 rounded-lg text-sky-500 hover:text-sky-700 font-medium px-5 h-[40px]" @click="backPage()">Back</button>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>

</style>
