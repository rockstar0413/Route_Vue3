<script setup lang="ts">
import { ref, onMounted } from 'vue';
import { storeToRefs } from 'pinia'
import { useAddressStore } from '@/stores/address'
import DeliveryMethodVue from '@/components/DeliveryMethod.vue';
import DeliverTypeVue from '@/components/DeliverType.vue';
import Discovery from '@/assets/images/Discovery.svg';
import Return from '@/assets/images/Return.svg'
import Senpex from '@/assets/images/Senpex.svg'
import Bag from '@/assets/images/Bag.svg'
import router from "@/router";
import { useRoute } from 'vue-router'
const { setDeliveryMethod, setDeliver, setBeforeRoute} = useAddressStore();
const { getDeliveryMethod, getDeliver } = storeToRefs(useAddressStore())

const route = useRoute()
const isContactPage = ref(false);
const send_name = ref('');
const send_email = ref('');
const send_company = ref('');
const send_phone = ref('');
const send_description = ref('');
onMounted(() => {
  setBeforeRoute((route.name as any).toString())
});
const nextPage = () => {
  router.push({ name: 'option' })
}
const hideContactPage = () => {
  isContactPage.value = false;
}
const showContactPage = () => {
  isContactPage.value = true;
}
const sendMail = () => {
  const { sendMailWithData } = useAddressStore();
  sendMailWithData(send_name.value, send_email.value, send_phone.value, send_company.value, send_description.value)
  hideContactPage();
}
</script>

<template>
  <div class="">
    <div
      class="w-full bg-[rgba(0,0,0,0.5)] fixed flex justify-center items-center h-[calc(100vh+72px)] z-40 pb-10 px-3 lg:px-10 pt-28 -top-[72px]"
      v-if="isContactPage">
      <div
        class="w-full bg-[rgba(0,0,0,0.5)] fixed flex justify-center items-center h-[calc(100vh+72px)] z-10 pb-10 px-3 lg:px-10 pt-28 -top-[72px]"
        @click="hideContactPage"></div>
      <div class="py-10 pb-7 pt-0 bg-white w-full lg:w-[380px] rounded-lg bg-white px-2 lg:px-5 z-20">
        <div class="text-lg font-bold flex justify-center w-full py-5">
          Get special quote for business
        </div>
        <div class="text-sm w-full mb-3">
          <div class="mb-1">Full name</div>
          <input type="text" id="first_name" v-model="send_name"
            class="bg-white border border-gray-300 text-gray-900 text-sm rounded-lg focus-visible:outline-blue-300 block w-full p-2"
            placeholder="Full name" required />
        </div>
        <div class="text-sm w-full mb-3">
          <div class="mb-1">Email</div>
          <input type="text" id="first_name" v-model="send_email"
            class="bg-white border border-gray-300 text-gray-900 text-sm rounded-lg focus-visible:outline-blue-300 block w-full p-2"
            placeholder="Email" required />
        </div>
        <div class="text-sm w-full mb-3">
          <div class="mb-1">Company</div>
          <input type="text" id="first_name" v-model="send_company"
            class="bg-white border border-gray-300 text-gray-900 text-sm rounded-lg focus-visible:outline-blue-300 block w-full p-2"
            placeholder="Company" required />
        </div>
        <div class="text-sm w-full mb-3">
          <div class="mb-1">Phone number</div>
          <input type="text" id="first_name" v-model="send_phone"
            class="bg-white border border-gray-300 text-gray-900 text-sm rounded-lg focus-visible:outline-blue-300 block w-full p-2"
            placeholder="Phone number" required />
        </div>
        <div class="text-sm w-full mb-5">
          <div class="mb-1">Description</div>
          <textarea type="text" id="first_name" v-model="send_description"
            class="bg-white border border-gray-300 text-gray-900 text-sm rounded-lg focus-visible:outline-blue-300 block w-full p-2 h-[100px]"
            placeholder="Company" required />
        </div>
        <div class="text-sm w-full">
          <button class="bg-[#0083FC] hover:bg-[#0083CC] h-[48px] rounded-lg text-white font-medium w-full"
            @click="sendMail">Get a special quote</button>
        </div>
      </div>
    </div>
    <div class="w-full relative ">
      <div class="h-[calc(100vh-72px)] relative">
        <div class="font-bold text-lg text-black py-3 pt-7 px-3 lg:px-7">
          Choose a delivery method
        </div>
        <div class="px-3 lg:px-7">
          <delivery-method-vue :icon="Discovery" title="Optimize my routes"
            content="Lorem Ipsum is simply dummy text of the printing" :current="getDeliveryMethod===1"
            @click="setDeliveryMethod(1)" />
          <delivery-method-vue :icon="Return" title="Optimize & Delivery"
            content="Lorem Ipsum is simply dummy text of the printing" :current="getDeliveryMethod===2"
            @click="setDeliveryMethod(2)" />
        </div>
        <div class="grid grid-cols-2 gap-3 px-3 lg:px-7" v-if="getDeliveryMethod===2">
          <deliver-type-vue :icon="Senpex" content="COMING SOON" :current="getDeliver===1" @click="setDeliver(1)" />
        </div>
        <div class="mt-10 w-full px-3 lg:px-7">
          <button class="bg-[#0083FC] hover:bg-[#0083CC] h-[48px] rounded-lg text-white font-medium w-full"
            @click="nextPage()">Continue</button>
        </div>
        <div class="mt-10 w-full bottom-5 mt-[1000px] absolute px-3 lg:px-7">
          <button
            class="bg-transparent border-2 h-[48px] rounded-lg text-[#64748B] font-medium w-full flex items-center justify-center"
            @click="showContactPage()">
            <img :src="Bag" alt="bag" class="mr-3">
            If you want to join us click here
          </button>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>

</style>
