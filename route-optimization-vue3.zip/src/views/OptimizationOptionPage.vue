<script setup lang="ts">
import { storeToRefs } from 'pinia'
import { useAddressStore } from '@/stores/address'
import DeliveryMethodVue from '@/components/DeliveryMethod.vue'
import OneToMany from '@/assets/images/OneToMany.svg'
import ManyToOne from '@/assets/images/ManyToOne.svg'
import router from '@/router'
import { onMounted } from 'vue'
import { useRoute } from 'vue-router'
const { setDeliveryType, fetchTokenByDeliveryType, setBeforeRoute } = useAddressStore()
const { getDeliveryType, getAccessToken } = storeToRefs(useAddressStore())
const route = useRoute()
onMounted(() => {
  setBeforeRoute((route.name as any).toString())
});
const backPage = () => {
  router.push({ name: 'provider' })
}
const setTypeOfDelivery = (type: number) => {
  setDeliveryType(type)
}
const nextPage = async () => {
  await fetchTokenByDeliveryType();
  router.push({ name: 'addresses' })
}
</script>

<template>
  <div class="">
    <div class="w-full relative">
      <div class="h-[calc(100vh-72px)] ">
        <div class="font-bold text-lg text-black px-3 lg:px-7 py-3 pt-7">
          Choose a delivery method
        </div>
        <div class="px-3 lg:px-7">
          <delivery-method-vue :icon="OneToMany" title="One to Many delivery"
            content="Lorem Ipsum is simply dummy text of the printing and typesetting industry."
            :current="getDeliveryType === 1" @click="setTypeOfDelivery(1)" />
          <delivery-method-vue :icon="ManyToOne" title="Many to One delivery"
            content="Lorem Ipsum is simply dummy text of the  printing and typesetting industry."
            :current="getDeliveryType === 2" @click="setTypeOfDelivery(2)" />
        </div>
        <div class="mt-10 w-full px-3 lg:px-7">
          <button class="bg-[#0083FC] hover:bg-[#0083CC] h-[48px] rounded-lg text-white font-medium w-full"
            @click="nextPage()">Continue</button>
        </div>
        <div class="mt-10 w-full bottom-5 absolute px-3 lg:px-7">
          <button
            class="bg-transparent border-2 border-[#0083FC] lg:border-[#0083CC] h-[48px] rounded-lg text-[#0083FC] hover:text-[#0083CC] font-medium w-full"
            @click="backPage()">
            Back to page
          </button>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
.scrollbar::-webkit-scrollbar {
  width: 6px;
  height: 20px;
}

.scrollbar::-webkit-scrollbar-track {
  border-radius: 100vh;
  background: white;
}

.scrollbar::-webkit-scrollbar-thumb {
  background: rgba(100, 116, 139, 0.8);
  border-radius: 100vh;
}

.scrollbar::-webkit-scrollbar-thumb:hover {
  background: rgba(100, 116, 139, 1);
}
</style>
