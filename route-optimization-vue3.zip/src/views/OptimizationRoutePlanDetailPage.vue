<script setup lang="ts">
import { ref } from 'vue';
import { storeToRefs } from 'pinia'
import { useAddressStore } from '@/stores/address'
import DriverView from '@/components/DriverView.vue';
import router from '@/router';
import { useRoute } from 'vue-router'
const route = useRoute()
const routeID = ref(route.params.id as any)

const { getFilteredAddresses, getOptimizedRoutes } = storeToRefs(useAddressStore())


const backPage = async () => {
  router.push({ name: "plan" });
}
</script>

<template>
  <div class="">
    <div class="w-full relative">
      <div class="font-bold text-lg text-black px-7 py-3">
        Driver View
      </div>
      <div class="bg-white pt-3  h-[calc(100vh-72px-52px)]">
        <div class="flex items-center w-full mb-4 px-7">
          <div class="border border-[#CCD2E2] rounded-xl w-full h-[80px] flex items-center justify-between px-5">
            <div class="flex items-center">
              <div class="mr-4" v-if="true">
                <img src="@/assets/images/bluePoint.svg" alt="Dots" v-if="routeID%3===1" />
                <img src="@/assets/images/redPoint.svg" alt="Dots" v-if="routeID%3===2" />
                <img src="@/assets/images/greenPoint.svg" alt="Dots" v-if="routeID%3===0" />
              </div>
              <div class="mr-4" v-if="false">
                <img src="@/assets/images/grayPoint.svg" alt="Dots" />
              </div>
              <div class="text-sm text-[#64748B]">
                <div class="text-base text-[#202027] font-bold">Plan {{route.params.id}}</div>
                <div class="flex">
                  <span>{{getOptimizedRoutes.data[Number(route.params.id)-1].routes_total}} Stops </span>
                  <img src="@/assets/images/dot.svg" alt="dot" class="px-2">
                  <span>{{Math.floor(251/60)}}h {{251%60}}m </span>
                  <img src="@/assets/images/dot.svg" alt="dot" class="px-2">
                  <span>23 mil </span>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="text-black text-lg font-bold my-3 px-7">Drop-off addresses</div>
        <div
          :class="['overflow-auto scrollbar h-[calc(100vh-72px-52px-325px)] px-7', getFilteredAddresses.length===0?'flex items-center justify-center':'']">
          <div class="flex py-2 rounded-lg border border-transparent hover:bg-sky-100 hover:border hover:border-sky-300"
            v-for="(route, index) in getOptimizedRoutes.data[parseInt(routeID)-1]">
            <driver-view :route="route" :total="getOptimizedRoutes.data[parseInt(routeID)-1].length" :index="index" />
          </div>

          <div class="text-center" v-if="getFilteredAddresses.length===0">
            <div class="flex justify-center"><img src="@/assets/images/doublePoints.svg" alt="doublePoints" /></div>
            <div class="text-lg text-[#64748B] mt-3">Lorem Ipsum is simply dummy text of the printing<br />
              and typesetting industry.</div>
          </div>
        </div>
        <div class="mt-10 w-full flex items-center justify-end pb-5 px-7">
          <button class="border border-sky-500 hover:border-sky-700 rounded-lg text-sky-500 hover:text-sky-700 font-medium px-5 h-[40px]" @click="backPage()">Back</button>
        </div>
      </div>
    </div>

  </div>
</template>

<style scoped>
.scrollbar::-webkit-scrollbar {
  width: 6px;
  height: 20px;
}

.scrollbar::-webkit-scrollbar-track {
  border-radius: 100vh;
  background: white;
}

.scrollbar::-webkit-scrollbar-thumb {
  background: rgba(100, 116, 139, 0.8);
  border-radius: 100vh;
}

.scrollbar::-webkit-scrollbar-thumb:hover {
  background: rgba(100, 116, 139, 1);
}
</style>
