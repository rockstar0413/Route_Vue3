<script setup lang="ts">
import { ref, onMounted, watch } from 'vue';
import VueGoogleAutocomplete from "vue-google-autocomplete"
import { storeToRefs } from 'pinia'
import { useAddressStore } from '@/stores/address'
import SingleRoute from '@/components/SingleRoute.vue';
import router from '@/router';
import type { IRoute } from '@/shared/interfaces';
import MazPhoneNumberInput from 'maz-ui/components/MazPhoneNumberInput'
import type { CountryCode } from 'libphonenumber-js';
import { useRoute } from 'vue-router'
import draggable from 'vuedraggable'
import RoundTrip from '@/assets/images/RoundTrip.svg'
import NearestNeighbor from '@/assets/images/NearestNeighbor.svg'
import CustomizedTrip from '@/assets/images/CustomizedTrip.svg'
import OptimizationAlgorithm from '@/components/OptimizationAlgorithm.vue'
const route = useRoute()
const routeID = ref(route.params.id as any)
const dragOptions =ref({
        animation: 0,
        group: 'description',
        disabled: false,
        ghostClass: 'ghost',
      })
const { getRouteAddresses, getAlgorithm, getCheckedAddresses, getRouteCheckedAddresses, getFilteredAddresses, getDeliveryType, getToken, getPoint, getOptimizedRoutes, getRouteFilteredAddresses } = storeToRefs(useAddressStore())
const {
  fetchPickUpAddress,
  updatePickUpAddress,
  changeCheckState,
  changeRouteCheckState,
  deleteMultipleRouteDetail,
  setBeforeRoute,
  addLocalStop,
  setRouteSearchAddress,
  setAlgorithm,
  updateAlgorithm,
  updateStop,
  moveToRoute,
  changeStartPoint,
  changeFinishPoint,
  multiMoveToRoute,
  updateSingleRoute
} = useAddressStore()
const backPage = async () => {
  router.push({ name: "routes" });
}
const nextPage = () => {
    router.push({ name: "routes" });
}
const edit_local_address = ref(null);
const add_point = ref('')
const add_address = ref(null)
const update_address = ref(null)
const isEditable = ref(false)
const isDrop = ref(false)
const isAll = ref(false)
const edit_local_latitude = ref('')
const edit_local_longitude = ref('')
const pick_latitude = ref('')
const pick_longitude = ref('')
const pick_selected_address = ref('')
const drop_latitude = ref('')
const drop_longitude = ref('')
const drop_selected_address = ref('')
const apt = ref('')
const isAllChecked = ref(false)
const isViewAllChecked = ref(false)
const isConfirmDelete = ref(false)
const isConfirmMultiDelete = ref(false)
const isMenuDialog = ref(false)
const search_address = ref('')
const results = ref('')
const edit_address = ref('')
const edit_latitude = ref('')
const edit_longitude = ref('')
const edit_receiver = ref('')
const edit_description = ref('')
const edit_apt = ref('')
const phoneNumber = ref('')
const selected_address_id = ref('')
const defaultPhoneNumber = ref('')
const isStartPoint = ref(false)
const isEndPoint = ref(false)
const editAddressName = ref("")
const selected_index = ref(0)
const selected_total = ref(0)
const isOptimizeDone = ref(false)
const isMoveToMenu = ref(false)
const isMultiMoveToMenu = ref(false)
const selected_plan = ref("0")
const edit_country_code = ref("US" as CountryCode)
onMounted(() => {
  setBeforeRoute((route.name as any).toString())
  pick_selected_address.value = getPoint.value.optimize_point_address;
  pick_latitude.value = getPoint.value.optimize_point_latitude;
  pick_longitude.value = getPoint.value.optimize_point_longitude;
  add_point.value =getPoint.value.optimize_point_address
})
const setPlace = (address: any, data: any) => {
  drop_latitude.value = data.geometry.location.lat();
  drop_longitude.value = data.geometry.location.lng();
  drop_selected_address.value = data.formatted_address;
}
const addPoint = (address: any, data: any) => {
  pick_latitude.value = data.geometry.location.lat();
  pick_longitude.value = data.geometry.location.lng();
  pick_selected_address.value = data.formatted_address;
  if (getToken.value === "") {
    alert("You lost token. Please go back to previous page")
    return
  }
  if (getPoint.value.optimize_point_address === "") {
    fetchPickUpAddress(pick_selected_address.value, pick_latitude.value, pick_longitude.value);
  } else {
    updatePickUpAddress(pick_selected_address.value, pick_latitude.value, pick_longitude.value);
  }
}
const editLocalAddress = (address: any, data: any) => {
  edit_local_latitude.value = data.geometry.location.lat();
  edit_local_longitude.value = data.geometry.location.lng();
  editAddressName.value = data.formatted_address;
}
const saveAddress = () => {
  if (pick_latitude.value !== "" && pick_longitude.value !== "" && pick_selected_address.value !== "") {
    if (drop_latitude.value !== "" && drop_longitude.value !== "" && drop_selected_address.value !== "") {
      if (getToken.value === "") {
        alert("You lost token. Please go back to previous page")
        return
      }
      addLocalStop(drop_selected_address.value, drop_latitude.value, drop_longitude.value, apt.value, route.params.id[0]);
    }
    else alert("Please enter a location!")
  } else {
    alert("Please pick up address!")
  }
  clearDropAddress();
}
const clearDropAddress = () => {
  drop_latitude.value = "";
  drop_longitude.value = "";
  drop_selected_address.value = "";
  apt.value = "";
  (add_address.value as any).clear();
}
const changeEditable = (id: string) => {
  isEditable.value = true;
  selected_address_id.value = id;
  let temp: IRoute = (getFilteredAddresses.value.filter((item: IRoute) => item.optimize_route_id.toString() === selected_address_id.value.toString()))[0];
  getFilteredAddresses.value.map((item: IRoute) => {
    return item;
  })
  edit_address.value = temp.address;
  edit_apt.value = temp.apartment_no;
  edit_description.value = temp.description;
  edit_latitude.value = temp.latitude.toString();
  edit_longitude.value = temp.longitude.toString();
  edit_receiver.value = temp.contact_person;
  defaultPhoneNumber.value = temp.phone || "";
  edit_country_code.value = (temp.country_code || "US") as CountryCode;
  (update_address.value as any).update(temp.address)
}
const chooseDeleteItem = (id: string) => {
  showConfirmDelete();
  selected_address_id.value = id;
}
const hideEditPanel = () => {
  isEditable.value = false;
}
const showConfirmDelete = () => {
  isConfirmDelete.value = true;
  hideEditPanel();
}
const hideConfirmDelete = () => {
  isConfirmDelete.value = false;
}
const setEditPlace = (address: any, data: any) => {
  edit_latitude.value = data.geometry.location.lat().toString();
  edit_longitude.value = data.geometry.location.lng().toString();
  edit_address.value = data.formatted_address;
}
const updateRouteDetail = () => {
  try {
    if (edit_address.value !== "") {
      updateSingleRoute(edit_address.value, edit_receiver.value, (results as any)?.countryCallingCode ? (results as any)?.countryCallingCode : "", (results as any)?.nationalNumber ? (results as any)?.nationalNumber : "", edit_description.value, edit_apt.value, selected_address_id.value, edit_latitude.value, edit_longitude.value, (results as any)?.countryCode ? (results as any)?.countryCode : "");
      hideMenuDialog();
    } else { alert("Please select address") }
  } catch (e) {
  }
}
const showConfirmMultiDelete = () => {
  isConfirmMultiDelete.value = true;
  hideEditPanel();
}
const hideConfirmMultiDelete = () => {
  isConfirmMultiDelete.value = false;
}
const changeIsAllChecked = () => {
  isAllChecked.value = !isAllChecked.value;
  changeRouteCheckState(isAllChecked.value, routeID.value);
}
const deleteItem = () => {
  console.log(getRouteAddresses.value(routeID.value))
  let temp: Array<number> = [];
  temp.push(Number(selected_address_id.value))
  deleteMultipleRouteDetail(temp, routeID.value);
  hideConfirmDelete();
}
const changeMenuDialog =(id: string, address:string, index:number, total:number)=>{
  isMenuDialog.value= true;
  selected_address_id.value = id;
  editAddressName.value =  address;
  selected_index.value = index;
  selected_total.value = total;
  isStartPoint.value = index === 0? true: false;
  isEndPoint.value = index === total - 1?true:false;
  (edit_local_address.value as any).update(address)
}
const editPopup =(id: string, address:string, index:number, total:number)=>{
  isMenuDialog.value= true;
  selected_address_id.value = id;
  editAddressName.value =  address;
  selected_index.value = index;
  selected_total.value = total;
  isStartPoint.value = index === 0? true: false;
  isEndPoint.value = index === total - 1?true:false;
  (edit_local_address.value as any).update(address)
}
const moveToPopup =(id: string)=>{
  isMoveToMenu.value= true;
  selected_address_id.value = id;
  selected_plan.value = routeID.value
}
const changeChecked = (address: IRoute) => {
  if (!address.checked) {
    isAllChecked.value = false;
    isViewAllChecked.value = false
  }
  if (getRouteFilteredAddresses.value(routeID.value).length === getRouteCheckedAddresses.value(routeID.value).length) {
    isAllChecked.value = true;
    isViewAllChecked.value = true;
  }
}
const hideMenuDialog = () => {
  isMenuDialog.value= false;
}
const hideMoveToMenu = () => {
  isMoveToMenu.value= false;
}
const showMultiMoveToMenu = () => {
  isMultiMoveToMenu.value= true;
  selected_plan.value = routeID.value
}
const hideMultiMoveToMenu = () => {
  isMultiMoveToMenu.value= false;
}
const deleteMultiAddress = () => {
  let temp: Array<number> = [];
  getRouteCheckedAddresses.value(routeID.value).map((address: IRoute) => {
    temp.push(address.optimize_route_id)
    return address
  })
  deleteMultipleRouteDetail(temp, routeID.value);
  hideConfirmMultiDelete()
}
const changeSearchAddress = () => {
  isAllChecked.value = false;
  changeCheckState(isAllChecked.value);
  setRouteSearchAddress(search_address.value)
}
const clickStartPoint = () => {
  if(isStartPoint.value) isStartPoint.value = false;
  else {
    isStartPoint.value = true;
    isEndPoint.value = false
  }
}
const clickEndPoint = () => {
  if(isEndPoint.value) isEndPoint.value = false;
  else {
    isEndPoint.value = true;
    isStartPoint.value = false
  }
}
const showOptimizeDone = () => {
  isOptimizeDone.value = true;
}
const hideOptimizeDone = () => {
  isOptimizeDone.value = false;
}
const saveDetailMenu = () =>{
  hideMenuDialog()
  updateStop(selected_address_id.value, routeID.value, editAddressName.value, edit_local_latitude.value, edit_local_longitude.value)
}
const saveMoveToMenu = () =>{
  hideMoveToMenu()
  moveToRoute(selected_address_id.value, selected_plan.value)
}
const saveMultiMoveToMenu = () =>{
  let temp: Array<number> = [];
  getRouteCheckedAddresses.value(routeID.value).map((address: IRoute) => {
    temp.push(address.optimize_route_id)
    return address
  })
  multiMoveToRoute(temp, selected_plan.value);
  hideMultiMoveToMenu()
}
const setStartPoint = (id:string,driver_index:string) =>{
  selected_address_id.value = id
  selected_plan.value = driver_index
  changeStartPoint(selected_address_id.value, selected_plan.value)
}
const setFinishPoint = (id:string,driver_index:string) =>{
  selected_address_id.value = id
  selected_plan.value = driver_index
  changeFinishPoint(selected_address_id.value, selected_plan.value)
}
const saveDetailAlgorithm = ()=>{
  hideOptimizeDone();
  updateAlgorithm(routeID.value);
}
const changeSelectedplan = (event:any)=>{
  selected_plan.value = event.target.value;
  console.log(selected_plan.value)
}
watch(search_address, (value) => {
  changeSearchAddress()
})

</script>

<template>
  <div class="">
    <div class="w-full relative">
      <div
        class="w-full bg-[rgba(0,0,0,0.5)] fixed flex justify-center items-center h-[calc(100vh+72px)] z-40 p-10 pt-28 -top-[72px]"
        v-if="isConfirmDelete">
        <div class="p-5 flex justify-center bg-white rounded-xl w-[300px]">
          <div>
            <div class="text-xl font-medium text-center">Are you sure you want to <br /> delete this order?</div>
            <div class="flex justify-center mt-4">
              <button
                class="border border-sky-500 hover:border-sky-700 rounded-xl text-sky-500 hover:text-sky-700 font-medium px-5 mr-5 h-[40px]"
                @click="hideConfirmDelete">Cancel</button>
              <button class="bg-[#EB5757] hover:bg-[#E05050] rounded-xl text-white font-medium px-5 h-[40px]"
                @click="deleteItem">Delete</button>
            </div>
          </div>
        </div>
      </div>
      <div
        class="w-full bg-[rgba(0,0,0,0.5)] fixed flex justify-center items-center h-[calc(100vh+72px)] z-40 p-10 pt-28 -top-[72px]"
        v-if="isConfirmMultiDelete">
        <div class="p-5 flex justify-center bg-white rounded-xl w-[300px]">
          <div>
            <div class="text-xl font-medium text-center">Are you sure you want to <br /> delete
              {{getCheckedAddresses.length}} order?</div>
            <div class="flex justify-center mt-4">
              <button
                class="border border-sky-500 hover:border-sky-700 rounded-xl text-sky-500 hover:text-sky-700 font-medium px-5 mr-5 h-[40px]"
                @click="hideConfirmMultiDelete">Cancel</button>
              <button class="bg-[#EB5757] hover:bg-[#E05050] rounded-xl text-white font-medium px-5 h-[40px]"
                @click="deleteMultiAddress">Delete</button>
            </div>
          </div>
        </div>
      </div>
      <!-- <div
        class="w-full bg-[rgba(0,0,0,0.5)] fixed flex justify-center items-center h-[calc(100vh+72px)] z-40 p-10 px-5 pt-28 -top-[72px]"
        v-show="isMenuDialog">
        <div class="p-5 flex justify-center bg-white rounded-xl w-[360px]">
          <div class="w-full">
            <div class="flex items-center justify-between mb-2">
              <div class="basis-[10%] flex items-center">
                <span v-if="Number(selected_index)===0"
                  class="rounded-full bg-green-500 text-white text-xs font-bold w-[24px] h-[24px] flex justify-center items-center mr-1">
                  <img src="@/assets/images/Flag.svg" alt="Flag">
                </span>
                <span v-if="Number(selected_index)!==0 && Number(selected_index)===(Number(selected_total)-1)"
                  class="rounded-full bg-red-500 text-white text-xs font-bold w-[24px] h-[24px] flex justify-center items-center mr-1">
                  <img src="@/assets/images/Flag.svg" alt="Flag">
                </span>
                <span v-if="Number(selected_index)!==0 && Number(selected_index)!==(Number(selected_total)-1)"
                  class="rounded-full bg-blue-500 text-white text-xs font-bold w-[24px] h-[24px] flex justify-center items-center mr-1">
                  {{ selected_index}}
                </span>
              </div>
              <VueGoogleAutocomplete id="autocomplete-4" ref="edit_local_address"
                class=" text-gray-900 text-sm rounded-lg focus-visible:outline-none block w-full p-2 h-[48px]"
                placeholder="Address" v-on:placechanged="editLocalAddress">
              </VueGoogleAutocomplete>
              <div><img src="@/assets/images/Edit.svg" alt="ThreeDots" class="mr-2" /></div>
            </div>
            <div class="flex justify-between mt-5">
            <button
                class="border border-sky-500 hover:border-sky-700 rounded-xl text-sky-500 hover:text-sky-700 font-medium px-5 mr-5 h-[40px]"
                @click="hideMenuDialog">Cancel</button>
              <button class="bg-[#0083FC] hover:bg-[#103FC] rounded-xl text-white font-medium px-5 h-[40px]"
                @click="saveDetailMenu">Save details</button>
            </div>
          </div>
        </div>
      </div> -->
      <div
        class="w-full bg-[rgba(0,0,0,0.5)] fixed flex justify-center items-center h-[calc(100vh+72px)] z-40 p-10 px-5 pt-28 -top-[72px]"
        v-show="isMoveToMenu">
        <div class="p-5 flex justify-center bg-white rounded-xl w-[360px]">
          <div class="w-full">
            <!-- <div class="flex items-center justify-between mb-2">
              <div class="basis-[10%] flex items-center">
                <span v-if="Number(selected_index)===0"
                  class="rounded-full bg-green-500 text-white text-xs font-bold w-[24px] h-[24px] flex justify-center items-center mr-1">
                  <img src="@/assets/images/Flag.svg" alt="Flag">
                </span>
                <span v-if="Number(selected_index)!==0 && Number(selected_index)===(Number(selected_total)-1)"
                  class="rounded-full bg-red-500 text-white text-xs font-bold w-[24px] h-[24px] flex justify-center items-center mr-1">
                  <img src="@/assets/images/Flag.svg" alt="Flag">
                </span>
                <span v-if="Number(selected_index)!==0 && Number(selected_index)!==(Number(selected_total)-1)"
                  class="rounded-full bg-blue-500 text-white text-xs font-bold w-[24px] h-[24px] flex justify-center items-center mr-1">
                  {{ selected_index}}
                </span>
              </div>
              <VueGoogleAutocomplete id="autocomplete-4" ref="edit_local_address"
                class=" text-gray-900 text-sm rounded-lg focus-visible:outline-none block w-full p-2 h-[48px]"
                placeholder="Address" v-on:placechanged="editLocalAddress">
              </VueGoogleAutocomplete>
              <div><img src="@/assets/images/Edit.svg" alt="ThreeDots" class="mr-2" /></div>
            </div> -->
            <!-- <div class="w-full h-[1px] bg-gray-300 mb-4"></div>
            <div class="text-black mb-2 mt-2">Select optimization point</div>
            <div class="w-full flex">
              <div :class="['w-full border rounded-tl-lg rounded-bl-lg flex items-center p-3 cursor-pointer', isStartPoint?'bg-sky-500 text-white':'']" @click="clickStartPoint()">
                <span 
                  class="rounded-full bg-green-500 text-white text-xs font-bold w-[24px] h-[24px] flex justify-center items-center mr-1">
                  <img src="@/assets/images/Flag.svg" alt="Flag">
                </span>
                <span class="ml-3">Start point</span>
              </div>
              <div  :class="['w-full border rounded-tr-lg rounded-br-lg flex items-center p-3 cursor-pointer', isEndPoint?'bg-sky-500 text-white':'']"  @click="clickEndPoint()">
                <span 
                  class="rounded-full bg-red-500 text-white text-xs font-bold w-[24px] h-[24px] flex justify-center items-center mr-1">
                  <img src="@/assets/images/Flag.svg" alt="Flag">
                </span>
                <span class="ml-3">Finish point</span>
              </div>
            </div> -->
            <div class="text-black mb-2 mt-2">Move to</div>
            <select class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus-visible:outline-blue-300 block w-full p-2 h-[48px]" v-model="selected_plan" @change="changeSelectedplan($event)">
              <template v-for="(option, index) in getOptimizedRoutes.data" >
                  <option :value="index+1">
                    Plan {{ index + 1 }}
                  </option>
              </template>
              
            </select>
            <div class="flex justify-between mt-5">
            <button
                class="border border-sky-500 hover:border-sky-700 rounded-xl text-sky-500 hover:text-sky-700 font-medium px-5 mr-5 h-[40px]"
                @click="hideMoveToMenu">Cancel</button>
              <button class="bg-[#0083FC] hover:bg-[#103FC] rounded-xl text-white font-medium px-5 h-[40px]"
                @click="saveMoveToMenu">Save details</button>
            </div>
          </div>
        </div>
      </div>
      <div class="absolute border-l-2 bg-white px-5 pt-3 right-0 w-[415px] lg:right-[-415px] z-40 h-[calc(100vh-72px)]"
        v-show="isMenuDialog">
        <div class="text-md font-medium pb-3">Drop-off address edit</div>
        <div class="pb-4">
          <div class="pb-1">Address</div>
          <VueGoogleAutocomplete id="autocomplete-4" ref="edit_local_address"
            class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus-visible:outline-blue-300 block w-full p-2 h-[48px]"
            placeholder="Address" v-on:placechanged="setEditPlace">
          </VueGoogleAutocomplete>
        </div>
        <div class="pb-4">
          <div class="pb-1">Apt. #</div>
          <input type="text" id="first_name"
            class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus-visible:outline-blue-300 block w-full p-2"
            placeholder="Apt. #" v-model="edit_apt" required />
        </div>
        <div class="pb-4">
          <div class="pb-1">Receiver name</div>
          <div>
            <input type="text" id="first_name"
              class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus-visible:outline-blue-300 block w-full p-2"
              placeholder="Receiver name" v-model="edit_receiver" required />
          </div>
        </div>
        <div class="pb-4">
          <div class="pb-1">Phone number</div>
          <MazPhoneNumberInput v-model="phoneNumber" :default-phone-number="defaultPhoneNumber"
            :default-country-code="edit_country_code" show-code-on-list color="info" :preferred-countries="[]"
            :ignored-countries="[]" @update="results = $event" />
        </div>
        <div class="pb-4">
          <div class="pb-1">Description</div>
          <textarea id="first_name"
            class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus-visible:outline-blue-300 block w-full p-2 h-20"
            placeholder="Description" v-model="edit_description"></textarea>
        </div>
        <div class="flex  h-[40px]">
          <button
            class="border border-sky-500 hover:border-sky-700 rounded-xl text-sky-500 hover:text-sky-700 font-medium px-5 mr-5"
            @click="hideMenuDialog">Cancel</button>
          <button class="bg-sky-500 hover:bg-sky-700 rounded-xl text-white font-medium px-5" @click="hideMenuDialog">
            Save details</button>
        </div>
      </div>
      <div
        class="w-full bg-[rgba(0,0,0,0.5)] fixed flex justify-center items-center h-[calc(100vh+72px)] z-40 p-10 px-5 pt-28 -top-[72px]"
        v-show="isMultiMoveToMenu">
        <div class="p-5 flex justify-center bg-white rounded-xl w-[360px]">
          <div class="w-full">
            <div class="text-black mb-2 mt-2">Move to</div>
            <select class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus-visible:outline-blue-300 block w-full p-2 h-[48px]" v-model="selected_plan" @change="changeSelectedplan($event)">
              <template v-for="(option, index) in getOptimizedRoutes.data" >
                  <option :value="index+1">
                    Plan {{ index + 1 }}
                  </option>
              </template>
            </select>
            <div class="flex justify-between mt-5">
            <button
                class="border border-sky-500 hover:border-sky-700 rounded-xl text-sky-500 hover:text-sky-700 font-medium px-5 mr-5 h-[40px]"
                @click="hideMultiMoveToMenu">Cancel</button>
              <button class="bg-[#0083FC] hover:bg-[#103FC] rounded-xl text-white font-medium px-5 h-[40px]"
                @click="saveMultiMoveToMenu">Save details</button>
            </div>
          </div>
        </div>
      </div>
      <div
        class="w-full bg-[rgba(0,0,0,0.0)] fixed flex justify-start items-end h-[calc(100vh+72px)] z-40  -top-[72px]" v-if="isOptimizeDone">
        <div class="p-5 flex justify-center bg-white w-1/2 drop-shadow-lg">
          <div class="px-7 mt-4">
            <div class="flex justify-between">
              <div class="text-[#202027] text-lg font-bold mb-3">Optimization Algorythm</div>
            <img src="@/assets/images/CloseDialog.svg" alt="CloseDialog" class="cursor-pointer"
                @click="hideOptimizeDone">
            </div>
            <div class="grid grid-cols-3 gap-4">
              <OptimizationAlgorithm :icon="RoundTrip" title="Round Trip"
                content="Lorem Ipsum is simply dummy text of the printing" active="1" :current="getAlgorithm === 1"
                @click="setAlgorithm(1)" />
              <OptimizationAlgorithm :icon="NearestNeighbor" title="Nearest Neighbor"
                content="Lorem Ipsum is simply dummy text of the printing" active="1" :current="getAlgorithm === 2"
                @click="setAlgorithm(2)" />
              <OptimizationAlgorithm :icon="CustomizedTrip" title="Customized Trip"
                content="Lorem Ipsum is simply dummy text of the printing" active="0" :current="getAlgorithm === 3" />
            </div>
            <div class="flex items-center justify-center lg:justify-end mt-2">
                <div>
                  <button
                    class="border border-sky-500 hover:border-sky-700 rounded-lg text-sky-500 hover:text-sky-700 font-medium px-5 mr-5 h-[40px]"
                    @click="hideOptimizeDone">Back</button>
                  <button class="bg-sky-500 hover:bg-sky-700 rounded-lg text-white font-medium px-5 h-[40px] min-w-[100px]"
                    @click="saveDetailAlgorithm">Save Details</button>
                </div>
              </div>
          </div>
        </div>
      </div>
      <div class="font-bold text-lg text-black px-7 py-3">
        Manage Stops
      </div>    
      <div class="bg-white pt-3  h-[calc(100vh-72px-52px)]">
        <div class="flex items-center w-full mb-4 px-7">
          <div class="border border-[#CCD2E2] rounded-xl w-full h-[80px] flex items-center justify-between px-5">
            <div class="flex items-center">
              <div class="mr-4" v-if="true">
                <img src="@/assets/images/bluePoint.svg" alt="Dots" v-if="routeID%3===1" />
                <img src="@/assets/images/redPoint.svg" alt="Dots" v-if="routeID%3===2" />
                <img src="@/assets/images/greenPoint.svg" alt="Dots" v-if="routeID%3===0" />
              </div>
              <div class="mr-4" v-if="false">
                <img src="@/assets/images/grayPoint.svg" alt="Dots" />
              </div>
              <div class="text-sm text-[#64748B]">
                <div class="text-base text-[#202027] font-bold">Plan {{route.params.id}}</div>
                <div class="flex">
                  <span>{{getOptimizedRoutes.data[Number(route.params.id)-1].routes_total}} Stops </span>
                  <img src="@/assets/images/dot.svg" alt="dot" class="px-2">
                  <span>{{Math.floor(251/60)}}h {{251%60}}m </span>
                  <img src="@/assets/images/dot.svg" alt="dot" class="px-2">
                  <span>23 mil </span>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="text-md font-medium px-7 flex  items-center">
          <div class="text-md font-bold whitespace-nowrap mr-3">{{getDeliveryType===1?"Pick up address":"Drop-off address"}}</div>
          <div class="relative w-full">
              <input type="text" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus-visible:outline-blue-300 block w-full p-2 pl-10 h-[48px]" v-model="add_point" disabled >
              <span
                class="rounded-full bg-sky-600 text-white text-xs font-bold w-[24px] h-[24px] flex justify-center items-center mr-1 absolute top-[12px] left-[10px]">
                <font-awesome-icon icon="fa-solid fa-house" />
              </span>
            </div>
        </div>
        <div class="text-md font-medium pt-4 px-7 w-full lg:flex justify-between">
          <div class="flex items-center">
            {{getDeliveryType===1?"Drop-off address":"Pick up address"}}
            <span class="text-gray-400">(235)</span>
          </div>
          <div class="flex items-center">
            <div class="mr-2 cursor-pointer" v-if="getRouteCheckedAddresses(routeID).length>0" @click="showMultiMoveToMenu">
              <div class="flex items-center">
                <img src="@/assets/images/UpDown.svg" alt="UpDown">
                <span class="text-gray-500 hover:text-text-gray-700 text-xs ml-1">Move to</span>
              </div>
            </div>
            <div class="mr-2 cursor-pointer" v-if="getRouteCheckedAddresses(routeID).length>0" @click="showConfirmMultiDelete">
              <div class="flex items-center">
                <img src="@/assets/images/dustbin.svg" alt="Close" class="h-[15px] w-[15px]" />
                <span class="text-[#EB5757] hover:text-[#EF5F5F] text-xs ml-1">Delete selected</span>
              </div>
            </div>
            <div class="relative">
              <input type="text" id="first_name"
                class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus-visible:outline-blue-300 block w-full p-2 pl-10"
                placeholder="Search Address" required v-model="search_address" @change="changeSearchAddress()" />
              <span
                class="rounded-full text-white text-xs font-bold w-[24px] h-[24px] flex justify-center items-center mr-1 absolute top-[7px] left-[10px]">
                <img src="@/assets/images/search.svg" alt="search" />
              </span>
            </div>
          </div>
        </div>
        <div class="flex py-2 px-7">
          <div
            class="w-full bg-gray-200 rounded flex items-center p-2 px-4 h-[40px] text-[#64748B] text-[12px] font-[500]">
            <div class="basis-[8%] text-black">
              <img src="@/assets/images/UpDown.svg" alt="UpDown">
            </div>
            <div class="basis-[8%] flex items-center">
              <input type="checkbox" class="w-[20px] h-[20px] rounded border border-gray-100 bg-gray-300"
                v-model="isAllChecked" @click="changeIsAllChecked" />
            </div>
            <div class="basis-[10%]">
              STOP
            </div>
            <div class="basis-[52%]">
              ADDRESS
            </div>
            <div class="basis-[22%]">
              APT. #
            </div>
          </div>
        </div>
        <div class="flex px-7">
          <div class="w-full rounded flex h-[40px]">
            <div class="basis-6/12 px-2">
              <VueGoogleAutocomplete id="autocomplete-3" ref="add_address"
                class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus-visible:outline-blue-300 block w-full p-2  h-[40px]"
                placeholder="Enter a location" v-on:placechanged="setPlace">
              </VueGoogleAutocomplete>
            </div>
            <div class="basis-4/12 flex justify-center px-2">
              <input type="text" id="first_name"
                class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus-visible:outline-blue-300 block w-full p-2"
                placeholder="Apt. #" required v-model="apt" />
            </div>
            <div class="basis-2/12 flex justify-center px-2">
              <button class="bg-green-500 hover:bg-green-700 rounded-xl text-white font-medium w-full"
                @click="saveAddress()">Save</button>
            </div>
          </div>
        </div>
        <div
          :class="['overflow-auto scrollbar h-[calc(100vh-72px-52px-385px)] px-7', getRouteFilteredAddresses(routeID).length===0?'flex items-center justify-center':'']">
          <div class="flex py-2 rounded-lg border border-transparent hover:bg-sky-100 hover:border hover:border-sky-300"
            v-for="(route, index) in getRouteFilteredAddresses((parseInt(routeID)).toString()).sort((a, b) => Number(a.order) - Number(b.order))">
            <single-route :route="route" :total="getRouteAddresses((parseInt(routeID)).toString()).length" :index="index" :id="routeID" @changeEditable="changeEditable"
              @deleteItem="chooseDeleteItem" @changeChecked="changeChecked" @changeMenuDialog="changeMenuDialog" @editPopup="editPopup" @moveToPopup="moveToPopup" @changeStartPoint="setStartPoint" @changeFinishPoint="setFinishPoint" />
          </div>
          <!-- <draggable
            class="list-group"
            tag="ul"
            :list="mockData"
            v-bind="dragOptions"
            @start="true"
            @end="false"
          >
            <template #item="{ address }">
              <single-route :address="address" :total="mockData.length" :index="index" @changeEditable="changeEditable"
              @deleteItem="chooseDeleteItem" @changeChecked="changeChecked" />
            </template>
          </draggable> -->
          <div class="text-center" v-if="getRouteFilteredAddresses(routeID).length===0">
            <div class="flex justify-center"><img src="@/assets/images/doublePoints.svg" alt="doublePoints" /></div>
            <div class="text-lg text-[#64748B] mt-3">Lorem Ipsum is simply dummy text of the printing<br />
              and typesetting industry.</div>
          </div>
        </div>
        <div class="mt-5 w-full flex items-center pb-3">
          <div class="grid grid-cols-2 gap-3 px-7  w-full">
            <div class="col-span-2 lg:col-span-1 flex items-center justify-center lg:justify-start ">
              <button
                class="border border-[#CCD2E2] hover:border-[#CCD2E2] rounded-lg text-[#64748B] hover:[#CCD2E2] font-medium px-5 mr-5 h-[40px] flex items-center"
                @click="showOptimizeDone">
                <img src="@/assets/images/returnH.svg" alt="returnH" class="mr-2">
                Re-Optimization Algorythm
              </button>
            </div>
            <div class="col-span-2 lg:col-span-1 w-full">
              <div class="flex items-center justify-center lg:justify-end">
                <div>
                  <button
                    class="border border-sky-500 hover:border-sky-700 rounded-lg text-sky-500 hover:text-sky-700 font-medium px-5 mr-5 h-[40px]"
                    @click="backPage()">Back</button>
                  <button class="bg-sky-500 hover:bg-sky-700 rounded-lg text-white font-medium px-5 h-[40px] min-w-[100px]"
                    @click="nextPage()">Save</button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
.scrollbar::-webkit-scrollbar {
  width: 6px;
  height: 20px;
}

.scrollbar::-webkit-scrollbar-track {
  border-radius: 100vh;
  background: white;
}

.scrollbar::-webkit-scrollbar-thumb {
  background: rgba(100, 116, 139, 0.8);
  border-radius: 100vh;
}

.scrollbar::-webkit-scrollbar-thumb:hover {
  background: rgba(100, 116, 139, 1);
}
</style>
