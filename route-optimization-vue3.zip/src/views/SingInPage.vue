<script setup lang="ts">
  import { computed, ref } from 'vue'
  import { useAddressStore } from '@/stores/address'
  import { storeToRefs } from 'pinia'
  import router from '@/router'
  const isVisible = ref(false);
  const email = ref('')
  const password = ref('')
  const { getAccessToken, getBeforeRoute } = storeToRefs(useAddressStore())
  const type = computed(()=>{
    let type = isVisible.value?'text':'password';
    return type;
  })
  const showPassword = () =>{
    isVisible.value = true;
  }
  const hidePassword = () =>{
    isVisible.value = false;
  }
  const changePassword = (value:string)=>{
    password.value = value;
  }
  const login = async () =>{
    if(email.value!=="" && password.value!==""){
      const { loginUser } = useAddressStore();
      let response = await loginUser(email.value, password.value)
      if((response as any).data.status === 1){
        if(getAccessToken.value!=="") {
          router.push({name:getBeforeRoute.value.toString() ||'provider'})
        }
      }else{
        alert((response as any).data.message)
      }
    }else{
      alert('Please fill out all fields.')
    }
  }
</script>
<template>
  <div class="flex justify-center items-center h-[calc(100vh)] pt-[72px] px-10 lg:px-0">
    <div class="!bg-white text-left p-7 rounded-2xl w-full lg:w-1/3">
      <div class="flex items-center justify-center space-x-3 mb-5">
        <h2
          class="font-bold text-2xl leading-6 text-gray-800 dark:text-white cursor-pointer select-none"
        >
          <span>Routes</span>
          <span class="text-sky-700">now</span>
        </h2>
      </div>
      <div class="font-bold text-xl text-center mb-4">Login To Your Account</div>
      <div class="mb-4 ">
        <div class="mb-1">Email</div>
        <div class="relative">
          <input type="text" id="email"
            class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus-visible:outline-blue-300 block w-full p-2 h-[48px] "
            placeholder="Your email" :value="email" @change="email = ($event.target as any).value"/>
        </div>
      </div>
      <div class="mb-2">
        <div class="mb-1">Password</div>
        <div class="relative">
          <input :type="type" id="password"
            class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus-visible:outline-blue-300 block w-full p-2 h-[48px] "
            placeholder="Your password"  :value="password" @input="(e)=>changePassword((e.target as any).value)"/>
            <font-awesome-icon icon="fa-solid fa-eye" class="text-gray-400 absolute top-[17px] right-4 cursor-pointer hover:text-blue-500" @mousedown="showPassword" @mouseup="hidePassword" />  
        </div>
      </div>
      <div class="flex justify-between">
        <div class="flex items-center">
          <input type="checkbox" class="w-[20px] h-[20px] rounded border border-gray-100 bg-gray-300 mr-2 cursor-pointer"/>
          <span>Remember me</span>
        </div>
        <div class="cursor-pointer hover:text-blue-500">
          <RouterLink to="/auth/forgotpassword">Forgot password?</RouterLink>
        </div>
      </div>
      <div class="mt-8">
        <button class="bg-[#0083FC] hover:bg-[#0083CC] h-[40px] rounded-lg text-white text-base font-medium w-full mr-5" @click="login()">Login</button>
      </div>
      <div class="flex justify-center mt-5">
        <div class="">
          Don't have an account?  <span class="text-blue-500 hover:text-blue-700 font-medium cursor-pointer"><RouterLink to="/auth/signup">Sign Up</RouterLink></span>
        </div>
      </div>
    </div>
  </div>
</template>

<style></style>
