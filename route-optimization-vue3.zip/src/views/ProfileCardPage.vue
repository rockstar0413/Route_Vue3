<script setup lang="ts">
import { computed, ref, onMounted, onBeforeMount } from 'vue'
import { useAddressStore } from '@/stores/address'
import { storeToRefs } from 'pinia'
import router from '@/router'
import { RouterView } from 'vue-router'

const isVisible = ref(false)
const email = ref('')
const password = ref('')
const { getAccessToken, getBeforeRoute, getUser } = storeToRefs(
  useAddressStore(),
)
const type = computed(() => {
  let type = isVisible.value ? 'text' : 'password'
  return type
})
onBeforeMount(() => {
  const { getAccessToken } = useAddressStore()
  if (getAccessToken && getAccessToken !== '') {
  } else {
    router.push({ name: 'signin' })
  }
})
</script>
<template>
  <div class="text-base">
    <div class="text-lg font-bold px-7 py-3">My cards</div>
    <div class="h-[1px] w-full bg-[#ECECEC]"></div>
    <div class="flex justify-start px-7 gap-5 pt-4">
      <div><div class="border border-dashed border-[#CCD2E2] p-5 rounded-xl cursor-pointer hover:text-sky-500 hover:border-sky-500]">
        <div class="flex justify-center mb-3">
          <font-awesome-icon icon="fa-solid fa-plus" />
        </div>
        <div class="text-sm font-bold">Add</div>
      </div></div>
      <img src="@/assets/images/BlueCard.svg" alt="BlueCard" />
      <img src="@/assets/images/GreenCard.svg" alt="GreenCard"/>
    </div>
  </div>
</template>

<style>

</style>
