<script setup lang="ts">
import { computed, ref, onMounted, onBeforeMount } from 'vue'
import { useAddressStore } from '@/stores/address'
import { storeToRefs } from 'pinia'
import router from '@/router'
import { RouterView } from 'vue-router'

const isVisible = ref(false)
const isVisible1 = ref(false)
const isVisible2 = ref(false)
const current = ref('')
const password = ref('')
const confirm = ref('')
const errorConfirm = ref(false)
const errorMessage = ref("Please fill out fields")
const strongPassword = ref(5)
const strongMessage = ref("")
const errorPassword = ref(false)
const password_min = ref(8)
const password_max = ref(30)
const { getAccessToken, getBeforeRoute, getUser } = storeToRefs(
  useAddressStore(),
)
const type = computed(() => {
  let type = isVisible.value ? 'text' : 'password'
  return type
})
const showPassword = () => {
  isVisible.value = true;
}
const hidePassword = () => {
  isVisible.value = false;
}
const changePassword = (value: string) => {
  password.value = value;
  let temp = 0;
  if (minLength.value) temp++;
  if (containsSpecial.value) temp++;
  if (containsNumber.value) temp++;
  if (containsLowercase.value) temp++;
  if (containsUppercase.value) temp++;
  strongPassword.value = temp;
  if (strongPassword.value === 0) strongMessage.value = "This field is requried";
  if (strongPassword.value === 1) strongMessage.value = "The password is very weak";
  if (strongPassword.value === 2) strongMessage.value = "The password is weak";
  if (strongPassword.value === 3) strongMessage.value = "The password is normal";
  if (strongPassword.value === 4) strongMessage.value = "The password is medium";
  if (strongPassword.value === 5) strongMessage.value = "The password is strong";
  if (temp > 2) {
    errorPassword.value = false;
  } else {
    errorPassword.value = true;
    errorMessage.value = "Password is weak."
  }
}
const type1 = computed(() => {
  let type1 = isVisible1.value ? 'text' : 'password'
  return type1
})
const showPassword1 = () => {
  isVisible1.value = true;
}
const hidePassword1 = () => {
  isVisible1.value = false;
}
const changeConfirm = (value: string) => {
  confirm.value = value;
  if (confirm.value === password.value) {
    errorConfirm.value = false;
  } else {
    errorConfirm.value = true;
    errorMessage.value = 'Must be matched.';
  }
}
const type2 = computed(() => {
  let type2 = isVisible2.value ? 'text' : 'password'
  return type2
})
const showPassword2 = () => {
  isVisible2.value = true;
}
const hidePassword2 = () => {
  isVisible2.value = false;
}
const changeCurrentPassword = (value: string) => {
  current.value = value;
}
//password validation
const containsUppercase = computed(() => {
  return /[A-Z]/.test(password.value)
})
const containsLowercase = computed(() => {
  return /[a-z]/.test(password.value)
})
const containsNumber = computed(() => {
  return /[0-9]/.test(password.value)
})
const containsSpecial = computed(() => {
  return /[ !@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(password.value)
})
const minLength = computed(() => {
  return password.value.length >= password_min.value ? true : false;
})
const maxLength = computed(() => {
  return password.value.length <= password_max.value ? true : false;
})
onBeforeMount(() => {
  const { getAccessToken } = useAddressStore()
  if (getAccessToken && getAccessToken !== '') {
  } else {
    router.push({ name: 'signin' })
  }
})

const updatePasswordFunc = async () => {
  changeCurrentPassword(current.value)
  changeConfirm(confirm.value)
  changePassword(password.value)
  if (!errorPassword.value && !errorConfirm.value) {
    const { updatePassword } = useAddressStore()
    let response = await updatePassword(current.value, password.value, confirm.value)
    if(response.status === 1){
      current.value = ""
      password.value = ""
      confirm.value = ""
    }
    alert((response as any).message)
  } else {
    alert(errorMessage.value)
  }
}
const logout = async () => {
  const { logOutFromSystem } = useAddressStore()
  await logOutFromSystem()
  router.push({ name: 'landing' })
}
</script>
<template>
  <div class="text-base">
    <div class="text-lg font-bold px-7 py-3">Account information</div>
    <div class="h-[1px] w-full bg-[#ECECEC]"></div>
    <div class="grid grid-cols-2 px-7 gap-5 pt-4">
      <div class="col-span-2 lg:col-span-1">
        <div class="">
          <div class="mb-1">Current password</div>
          <div class="relative">
            <input :type="type2" id="current"
              class="bg-white border border-gray-300 text-gray-900 text-sm rounded-lg focus-visible:outline-blue-300 block w-full p-2 h-[48px] "
              placeholder="Current password" :value="current"
              @input="(e) => changeCurrentPassword((e.target as any).value)" />
            <font-awesome-icon icon="fa-solid fa-eye"
              class="text-gray-400 absolute top-[17px] right-4 cursor-pointer hover:text-blue-500"
              @mousedown="showPassword2" @mouseup="hidePassword2" />
          </div>
        </div>
        <div class="mt-3">
          <div class="mb-1">New password</div>
          <div class="relative">
            <input :type="type" id="new"
              class="bg-white border border-gray-300 text-gray-900 text-sm rounded-lg focus-visible:outline-blue-300 block w-full p-2 h-[48px] "
              placeholder="New password" :value="password" @input="(e) => changePassword((e.target as any).value)">
            <font-awesome-icon icon="fa-solid fa-eye"
              class="text-gray-400 absolute top-[17px] right-4 cursor-pointer hover:text-blue-500"
              @mousedown="showPassword" @mouseup="hidePassword" />
          </div>
          <div
            :class="['text-xs', strongPassword === 0 ? 'text-red-500' : strongPassword < 3 ? 'text-pink-500' : strongPassword < 5 ? 'text-sky-500' : 'text-green-500']"
            v-if="errorPassword"> {{ strongMessage }}</div>
        </div>
        <div class="mt-3">
          <div class="mb-1">Confirm new password</div>
          <div class="relative">
            <input :type="type1" id="confirm"
              class="bg-white border border-gray-300 text-gray-900 text-sm rounded-lg focus-visible:outline-blue-300 block w-full p-2 h-[48px] "
              placeholder="Confirm new password" :value="confirm"
              @input="(e) => changeConfirm((e.target as any).value)" />
            <font-awesome-icon icon="fa-solid fa-eye"
              class="text-gray-400 absolute top-[17px] right-4 cursor-pointer hover:text-blue-500"
              @mousedown="showPassword1" @mouseup="hidePassword1" />
          </div>
          <div class="text-red-500 text-xs" v-if="errorConfirm"> Must be matched.</div>
        </div>
        <button
          class="bg-[#0083FC] hover:bg-[#0083CC] h-[40px] rounded-lg text-white text-base font-medium w-full lg:w-[300px] my-7"
          @click="updatePasswordFunc()">Update
          informantions</button>
      </div>
    </div>
  </div>
</template>

<style>

</style>
