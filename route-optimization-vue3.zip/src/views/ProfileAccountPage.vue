<script setup lang="ts">
import { computed, ref, onMounted, onBeforeMount } from 'vue'
import { useAddressStore } from '@/stores/address'
import { storeToRefs } from 'pinia'
import router from '@/router'
import { RouterView } from 'vue-router'

const isVisible = ref(false)
const name = ref('')
const company = ref('')
const email = ref('')
const phone = ref('')
const address = ref('')
const city = ref('')
const code = ref('')
const country = ref('')
const { getUser, getAccessToken  } = storeToRefs(
  useAddressStore(),
)
const type = computed(() => {
  let type = isVisible.value ? 'text' : 'password'
  return type
})
onBeforeMount(() => {
  const { getUser, getAccessToken } = useAddressStore()
  if (getAccessToken && getAccessToken !== '') {
    name.value = getUser.customer_name;
    company.value = getUser.company_name;
    email.value = getUser.customer_email;
    phone.value = getUser.customer_phone;
    address.value = getUser.customer_address;
    city.value = getUser.company_city;
    code.value = getUser.company_postal_code;
    country.value = getUser.company_country;
  } else {
    router.push({ name: 'signin' })
  }
})
const showPassword = () => {
  isVisible.value = true
}
const hidePassword = () => {
  isVisible.value = false
}
const updateInformation = async () => {
  if (email.value !== '' && name.value !== '') {
    const { updateInformation } = useAddressStore()
    let response = await updateInformation(name.value, company.value, phone.value, address.value, city.value, code.value, country.value)
    alert((response as any).message)
  } else {
    alert('Please fill out all fields.')
  }
}
</script>
<template>
  <div class="text-base">
    <div class="text-lg font-bold px-7 py-3">Account information</div>
    <div class="h-[1px] w-full bg-[#ECECEC]"></div>
    <div class="grid grid-cols-2 px-7 gap-5 pt-4">
      <div class="col-span-2 lg:col-span-1">
        <div class="mb-1">Full name</div>
        <input type="text" id="email"
            class="bg-white border border-gray-300 text-gray-900 text-sm rounded-lg focus-visible:outline-blue-300 block w-full p-2 h-[48px] "
            placeholder="Full name" :value="name" @change="name = ($event.target as any).value" />
      </div>
      <div class="col-span-2 lg:col-span-1">
        <div class="mb-1">Company</div>
        <input type="text" id="email"
            class="bg-white border border-gray-300 text-gray-900 text-sm rounded-lg focus-visible:outline-blue-300 block w-full p-2 h-[48px] "
            placeholder="Company" :value="company" @change="company = ($event.target as any).value" />
      </div>
      <div class="col-span-2 lg:col-span-1">
        <div class="mb-1">Email</div>
        <input type="text" id="email"
            class="bg-white border border-gray-300 text-gray-900 text-sm rounded-lg focus-visible:outline-blue-300 block w-full p-2 h-[48px] "
            placeholder="Email" disabled :value="email" @change="email = ($event.target as any).value" />
      </div>
      <div class="col-span-2 lg:col-span-1">
        <div class="mb-1">Phone</div>
        <input type="text" id="email"
            class="bg-white border border-gray-300 text-gray-900 text-sm rounded-lg focus-visible:outline-blue-300 block w-full p-2 h-[48px] "
            placeholder="Phone" :value="phone" @change="phone = ($event.target as any).value" />
      </div>
      <div class="col-span-2 lg:col-span-1">
        <div class="mb-1">Address</div>
        <input type="text" id="email"
            class="bg-white border border-gray-300 text-gray-900 text-sm rounded-lg focus-visible:outline-blue-300 block w-full p-2 h-[48px] "
            placeholder="Address" :value="address" @change="address = ($event.target as any).value"/>
      </div>
      <div class="col-span-2 lg:col-span-1">
        <div class="mb-1">City</div>
        <input type="text" id="email"
            class="bg-white border border-gray-300 text-gray-900 text-sm rounded-lg focus-visible:outline-blue-300 block w-full p-2 h-[48px] "
            placeholder="City" :value="city" @change="city = ($event.target as any).value" />
      </div>
      <div class="col-span-2 lg:col-span-1">
        <div class="mb-1">Postal code</div>
        <input type="text" id="email"
            class="bg-white border border-gray-300 text-gray-900 text-sm rounded-lg focus-visible:outline-blue-300 block w-full p-2 h-[48px] "
            placeholder="Postal code" :value="code" @change="code = ($event.target as any).value" />
      </div>
      <div class="col-span-2 lg:col-span-1">
        <div class="mb-1">Country</div>
        <input type="text" id="email"
            class="bg-white border border-gray-300 text-gray-900 text-sm rounded-lg focus-visible:outline-blue-300 block w-full p-2 h-[48px] "
            placeholder="Country" :value="country" @change="country = ($event.target as any).value" />
      </div>
    </div>
    <div class="mt-10 flex justify-center px-7 mb-10">
      <button class="bg-[#0083FC] hover:bg-[#0083CC] h-[40px] rounded-lg text-white text-base font-medium w-full lg:w-[300px]" @click="updateInformation()" >Update informantions</button>
    </div>
  </div>
</template>

<style>

</style>
