<template>
  <div class="bg-white pt-20">
    <div class="grid grid-cols-11 pl-20">
      <div class="col-span-11 lg:col-span-5 flex items-center">
        <div class="">
          <div class="text-5xl text-[#202124] font-bold leading-25">
            Simple solutions
            <br />
            for every business
          </div>
          <ul class="list-disc list-inside mt-7">
            <li class="mb-2">
              Lorem Ipsum is simply dummy text of the printing
            </li>
            <li class="mb-2">
              Lorem Ipsum is simply dummy text of the printing
            </li>
            <li class="mb-2">
              Lorem Ipsum is simply dummy text of the printing
            </li>
          </ul>
          <div class="flex justify-between mt-7 pr-8">
            <button
              class="bg-[#0083FC] hover:bg-[#0083CC] h-[48px] rounded-lg text-white text-base font-medium px-10 mr-5"
            >
              Try free for 7 days
            </button>
            <button
              class="bg-transparent border-2 h-[48px] rounded-lg text-[#64748B] font-medium px-10 flex items-center justify-center"
            >
              Learn more
            </button>
          </div>
        </div>
      </div>
      <div class="col-span-11 lg:col-span-6 relative flex justify-end">
        <div>
          <img
            src="@/assets/images/LandingImage.png"
            alt="BigImage"
            class="h-[90vh]"
          />
        </div>
      </div>
    </div>
    <div class="px-20 w-full mt-20 py-20" id="features">
      <div
        class="text-base text-blue-600 font-medium mb-2 cursor-pointer text-center"
      >
      Features
      </div>
      <div class="text-5xl text-[#202124] font-bold leading-25 text-center">
        One product with 50+ powerful features
      </div>
      <div class="grid grid-cols-3 gap-20 mt-32 px-20">
        <div class="col-span-3 lg:col-span-1">
          <img src="@/assets/images/OneToMany.svg" alt="features">
          <div class="text-xl font-bold my-5">Pickup and Delivery</div>
          <div class="text-[#64748B]">Amet minim mollit non deserunt ullamco est sit aliqua dolor do amet sint. Velit officia consequat duis enim velit mollit. </div>
        </div>
        <div class="col-span-3 lg:col-span-1">
          <img src="@/assets/images/ManyToOne.svg" alt="features">
          <div class="text-xl font-bold my-5">Optimize & Delivery</div>
          <div class="text-[#64748B]">Amet minim mollit non deserunt ullamco est sit aliqua dolor do amet sint. Velit officia consequat duis enim velit mollit. </div>
        </div>
        <div class="col-span-3 lg:col-span-1">
          <img src="@/assets/images/TwoPoints.svg" alt="features">
          <div class="text-xl font-bold my-5">Automated Planning</div>
          <div class="text-[#64748B]">Amet minim mollit non deserunt ullamco est sit aliqua dolor do amet sint. Velit officia consequat duis enim velit mollit. </div>
        </div>
        <div class="col-span-3 lg:col-span-1">
          <img src="@/assets/images/OneToMany.svg" alt="features">
          <div class="text-xl font-bold my-5">Multi-Routes</div>
          <div class="text-[#64748B]">Amet minim mollit non deserunt ullamco est sit aliqua dolor do amet sint. Velit officia consequat duis enim velit mollit. </div>
        </div>
        <div class="col-span-3 lg:col-span-1">
          <img src="@/assets/images/ManyToOne.svg" alt="features">
          <div class="text-xl font-bold my-5">Driver and Vehicle</div>
          <div class="text-[#64748B]">Amet minim mollit non deserunt ullamco est sit aliqua dolor do amet sint. Velit officia consequat duis enim velit mollit. </div>
        </div>
        <div class="col-span-3 lg:col-span-1">
          <img src="@/assets/images/TwoPoints.svg" alt="features">
          <div class="text-xl font-bold my-5">Mobile App for Drivers</div>
          <div class="text-[#64748B]">Amet minim mollit non deserunt ullamco est sit aliqua dolor do amet sint. Velit officia consequat duis enim velit mollit. </div>
        </div>
      </div>
    </div>
    <div class="grid grid-cols-2 px-20 mt-10 gap-20">
      <div class="col-span-2 lg:col-span-1 flex items-center justify-center">
        <div>
          <div class="text-base text-blue-600 font-medium mb-2 cursor-pointer">
            Lorem ipsum
          </div>
          <div class="text-5xl text-[#202124] font-bold leading-25">
            Plan & optimize routes
          </div>
          <div class="text-lg text-[#64748B] mt-5">
            Amet minim mollit non deserunt ullamco est sit aliqua dolor do amet
            sint. Velit officia consequat duis enim velit mollit.
          </div>
          <div class="flex justify-between mt-7 pr-8">
            <button
              class="bg-[#0083FC] hover:bg-[#0083CC] h-[48px] rounded-lg text-white text-base font-medium px-10 mr-5"
            >
              Get Started
            </button>
          </div>
        </div>
      </div>
      <div class="col-span-2 lg:col-span-1 relative flex justify-end">
        <div class="bg-[rgba(237,245,252,1)]">
          <img
            src="@/assets/images/Landing2.png"
            alt="Landing1"
            class="h-[90vh]"
          />
        </div>
      </div>
    </div>
    <div class="grid grid-cols-2 px-20 mt-10 gap-20">
      <div class="col-span-2 lg:col-span-1 relative flex justify-end">
        <div class="bg-[rgba(237,245,252,1)]">
          <img
            src="@/assets/images/Landing2.png"
            alt="Landing1"
            class="h-[90vh]"
          />
        </div>
      </div>
      <div class="col-span-2 lg:col-span-1 flex items-center justify-center">
        <div>
          <div class="text-base text-blue-600 font-medium mb-2 cursor-pointer">
            Lorem ipsum
          </div>
          <div class="text-5xl text-[#202124] font-bold leading-25">
            Dispatch to drivers
          </div>
          <div class="text-lg text-[#64748B] mt-5">
            Amet minim mollit non deserunt ullamco est sit aliqua dolor do amet
            sint. Velit officia velit mollit.
          </div>
          <div class="flex justify-between mt-7 pr-8">
            <button
              class="bg-[#0083FC] hover:bg-[#0083CC] h-[48px] rounded-lg text-white text-base font-medium px-10 mr-5"
            >
              Get Started
            </button>
          </div>
        </div>
      </div>
    </div>
    <div class="grid grid-cols-2 px-20 mt-10 gap-20">
      <div class="col-span-2 lg:col-span-1 flex items-center justify-center">
        <div>
          <div class="text-base text-blue-600 font-medium mb-2 cursor-pointer">
            Lorem ipsum
          </div>
          <div class="text-5xl text-[#202124] font-bold leading-25">
            Plan & optimize routes
          </div>
          <div class="text-lg text-[#64748B] mt-5">
            Amet minim mollit non deserunt ullamco est sit aliqua dolor do amet
            sint. Velit officia consequat duis enim velit mollit.
          </div>
          <div class="flex justify-between mt-7 pr-8">
            <button
              class="bg-[#0083FC] hover:bg-[#0083CC] h-[48px] rounded-lg text-white text-base font-medium px-10 mr-5"
            >
              Get Started
            </button>
          </div>
        </div>
      </div>
      <div class="col-span-2 lg:col-span-1 relative flex justify-end">
        <div class="bg-[rgba(237,245,252,1)]">
          <img
            src="@/assets/images/Landing2.png"
            alt="Landing1"
            class="h-[90vh]"
          />
        </div>
      </div>
    </div>
    <div class="grid grid-cols-2 px-20 mt-10 gap-20">
      <div
        class="col-span-2 lg:col-span-1 relative flex justify-center h-[70vh] relative bg-[rgba(237,245,252,1)]"
      >
        <div class="flex justify-center absolute">
          <img
            src="@/assets/images/Landing3.png"
            alt="Landing1"
            class="mt-10"
          />
        </div>
      </div>
      <div class="col-span-2 lg:col-span-1 flex items-center justify-center">
        <div>
          <div class="text-base text-blue-600 font-medium mb-2 cursor-pointer">
            Lorem ipsum
          </div>
          <div class="text-5xl text-[#202124] font-bold leading-25">
            Connecting Mobile app
          </div>
          <div class="text-lg text-[#64748B] mt-5">
            Amet minim mollit non deserunt ullamco est sit aliqua dolor do amet
            sint. Velit officia velit mollit.
          </div>
          <div class="flex justify-start mt-7 pr-8">
            <img
              src="@/assets/images/GooglePay.svg"
              alt="GooglePay"
              class="mr-5"
            />
            <img src="@/assets/images/AppStore.svg" alt="GooglePay" />
          </div>
        </div>
      </div>
    </div>
    <div class="px-20 w-full mt-20 pt-20">
      <div
        class="text-base text-blue-600 font-medium mb-2 cursor-pointer text-center"
      >
        Our Partner
      </div>
      <div class="text-5xl text-[#202124] font-bold leading-25 text-center">
        Trusted by Companies
      </div>
      <div class="flex justify-between items-center mt-10">
        <img src="@/assets/images/Company1.svg" alt="GooglePay" />
        <img src="@/assets/images/Company2.svg" alt="GooglePay" />
        <img src="@/assets/images/Company3.svg" alt="GooglePay" />
        <img src="@/assets/images/Company4.svg" alt="GooglePay" />
        <img src="@/assets/images/Company5.svg" alt="GooglePay" />
      </div>
    </div>
    <div class="px-20 w-full mt-20 py-20" id="pricing">
      <div
        class="text-base text-blue-600 font-medium mb-2 cursor-pointer text-center"
      >
        Pricing
      </div>
      <div class="text-5xl text-[#202124] font-bold leading-25 text-center">
        Choose the right plan for your business
      </div>
      <div class="flex items-center justify-center my-10">
        <div class="flex justify-center font-medium text-xl">
          <div>Montly</div>
          <div class="mx-5">
            <img src="@/assets/images/LandingCheck.svg" alt="" />
          </div>
          <div>Annually</div>
        </div>
      </div>
      <div
        class="flex justify-between items-center mt-10 grid grid-cols-3 gap-10"
      >
        <div
          class="col-span-3 lg:col-span-1 border border-gray-300 rounded-2xl py-10"
        >
          <div class="text-2xl font-bold mb-2 px-10">
            Essentials
          </div>
          <div class="text-xs text-[#64748B] mb-4 px-10">
            Everything you need to plan and dispatch optimized routes
          </div>
          <div class="flex items-center px-10">
            <div class="text-4xl font-bold text-[#202124] mr-3">$29</div>
            <div class="text-xs text-[#64748B]">/dirver/month</div>
          </div>
          <div class="px-10">
            <button
              class="bg-[#0083FC] hover:bg-[#0083CC] h-[48px] w-full rounded-lg text-white text-base font-medium px-10 mr-5 my-7"
            >
              Try free for 7 days
            </button>
          </div>
          <div class="h-[1px] bg-gray-300 mb-5"></div>
          <div class="text-[#202124] text-lg px-10">
            <div class="font-medium">KEY FEATURES</div>
            <div>
              <font-awesome-icon
                icon="fa-solid fa-check"
                class="text-green-500 ml-2 mt-4"
              />
              <span class="ml-4">Plan 100 stops at once</span>
            </div>
            <div>
              <font-awesome-icon
                icon="fa-solid fa-check"
                class="text-green-500 ml-2 mt-4"
              />
              <span class="ml-4">Dispatch routes to driver app</span>
            </div>
            <div>
              <font-awesome-icon
                icon="fa-solid fa-check"
                class="text-green-500 ml-2 mt-4"
              />
              <span class="ml-4">Plan optimized routes in minutes</span>
            </div>
            <div>
              <font-awesome-icon
                icon="fa-solid fa-check"
                class="text-green-500 ml-2 mt-4"
              />
              <span class="ml-4">Web Integration</span>
            </div>
          </div>
        </div>
        <div
          class="col-span-3 lg:col-span-1 border border-gray-300 rounded-2xl py-10"
        >
        <div class="flex items-center justify-between px-10">
            <div class="text-2xl font-bold mb-2">
              Professional
            </div>
            <div class="bg-sky-100 text-sky-500 p-2 px-5 rounded-xl">Popular</div>
          </div>
          <div class="text-xs text-[#64748B] mb-4 px-10">
            Everything you need to plan and dispatch optimized routes
          </div>
          <div class="flex items-center px-10">
            <div class="text-4xl font-bold text-[#202124] mr-3">$49</div>
            <div class="text-xs text-[#64748B]">/dirver/month</div>
          </div>
          <div class="px-10">
            <button
              class="bg-[#0083FC] hover:bg-[#0083CC] h-[48px] w-full rounded-lg text-white text-base font-medium px-10 mr-5 my-7"
            >
              Try free for 7 days
            </button>
          </div>
          <div class="h-[1px] bg-gray-300 mb-5"></div>
          <div class="text-[#202124] text-lg px-10">
            <div class="font-medium">KEY FEATURES</div>
            <div>
              <font-awesome-icon
                icon="fa-solid fa-check"
                class="text-green-500 ml-2 mt-4"
              />
              <span class="ml-4">Plan 100 stops at once</span>
            </div>
            <div>
              <font-awesome-icon
                icon="fa-solid fa-check"
                class="text-green-500 ml-2 mt-4"
              />
              <span class="ml-4">Dispatch routes to driver app</span>
            </div>
            <div>
              <font-awesome-icon
                icon="fa-solid fa-check"
                class="text-green-500 ml-2 mt-4"
              />
              <span class="ml-4">Plan optimized routes in minutes</span>
            </div>
            <div>
              <font-awesome-icon
                icon="fa-solid fa-check"
                class="text-green-500 ml-2 mt-4"
              />
              <span class="ml-4">Web Integration</span>
            </div>
          </div>
        </div>
        <div
          class="col-span-3 lg:col-span-1 border border-gray-300 rounded-2xl py-10"
        >
          <div class="flex items-center justify-between px-10">
            <div class="text-2xl font-bold mb-2">
              Premium
            </div>
          </div>
          <div class="text-xs text-[#64748B] mb-4 px-10">
            Scale your delivery operations with driver management tools
          </div>
          <div class="flex items-center px-10">
            <div class="text-4xl font-bold text-[#202124] mr-3">$49</div>
            <div class="text-xs text-[#64748B]">/dirver/month</div>
          </div>
          <div class="px-10">
            <button
              class="bg-transparent border-[3px] border-sky-500 h-[48px] text-sky-500 rounded-lg w-full px-10 mr-5 my-7 font-medium flex items-center justify-center"
            >
              Contact sales
            </button>
          </div>
          <div class="h-[1px] bg-gray-300 mb-5"></div>
          <div class="text-[#202124] text-lg px-10">
            <div class="font-medium">KEY FEATURES</div>
            <div>
              <font-awesome-icon
                icon="fa-solid fa-check"
                class="text-green-500 ml-2 mt-4"
              />
              <span class="ml-4">Everything in Recipient</span>
            </div>
            <div>
              <font-awesome-icon
                icon="fa-solid fa-check"
                class="text-green-500 ml-2 mt-4"
              />
              <span class="ml-4">Export data to other services</span>
            </div>
            <div class="h-[78px]">

            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="px-20 w-full mt-20 py-20">
      <div
        class="text-base text-blue-600 font-medium mb-2 cursor-pointer text-center"
      >
        Our Blog
      </div>
      <div class="text-5xl text-[#202124] font-bold leading-25 text-center">
        Help to make delivery easy
      </div>
      <div
        class="flex justify-between items-center mt-15 grid grid-cols-3 mt-20 gap-10"
      >
        <div class="col-span-3 lg:col-span-1">
          <img
            src="@/assets/images/Landing4.png"
            alt="landing4"
            class="w-full"
          />
          <div class="text-xl font-bold text-[#202124] my-3">
            Benefits of using Routesnow for your delivery business.
          </div>
          <div class="text-xs text-[#64748B] mb-5">
            In this article, we’re going to help you find what works best for
            you by looking at the best free route planners available — along
            with some paid options.
          </div>
          <div class="flex items-center text-blue-500">
            <span class="mr-3 font-medium">Read blog post</span>
            <div><font-awesome-icon icon="fa-solid fa-arrow-right " /></div>
          </div>
        </div>
        <div class="col-span-3 lg:col-span-1">
          <img
            src="@/assets/images/Landing5.png"
            alt="landing4"
            class="w-full"
          />
          <div class="text-xl font-bold text-[#202124] my-3">
            5 ways in which you can improve last-mile delivery.
          </div>
          <div class="text-xs text-[#64748B] mb-5">
            Last-mile delivery is a crucial step of the supply chain,
            responsible for transporting your product to its final
            destination...
          </div>
          <div class="flex items-center text-blue-500">
            <span class="mr-3 font-medium">Read blog post</span>
            <div><font-awesome-icon icon="fa-solid fa-arrow-right " /></div>
          </div>
        </div>
        <div class="col-span-3 lg:col-span-1">
          <img
            src="@/assets/images/Landing6.png"
            alt="landing4"
            class="w-full"
          />
          <div class="text-xl font-bold text-[#202124] my-3">
            How to deliver packages efficiently using Routesnow.
          </div>
          <div class="text-xs text-[#64748B] mb-5">
            We explore five different delivery route planning solutions to see
            what they offer drivers and dispatchers, and how you can save time
            and money.
          </div>
          <div class="flex items-center text-blue-500">
            <span class="mr-3 font-medium">Read blog post</span>
            <div><font-awesome-icon icon="fa-solid fa-arrow-right " /></div>
          </div>
        </div>
      </div>
    </div>
    <div class="bg-[#F5F8FE] p-20 flex justify-between items-center">
      <div>
        <div class="text-5xl text-[#202124] font-bold leading-25 mb-3">
          Start your
          <span class="text-blue-500">free trial</span>
          today
        </div>
        <div class="text-[#64748B] text-base">
          Try it first, pay as you go if you like it. No credit card required.
        </div>
      </div>
      <div class="flex">
        <button
          class="bg-[#0083FC] hover:bg-[#0083CC] h-[48px] rounded-lg text-white text-base font-medium px-10 mr-5"
        >
          <span>Start free trial</span>
        </button>
        <button class="bg-transparent border-[3px] border-blue-300 h-[48px] rounded-lg px-10 text-[#64748B] font-medium flex items-center justify-center">
            Contact us
          </button>
      </div>
    </div>
    <div class="px-20 pt-20 pb-10 flex justify-between items-center">
      <div>
        <h2 class="font-bold text-2xl leading-6 text-gray-800 dark:text-white cursor-pointer select-none">
            <span>Routes</span>
            <span class="text-sky-700">now</span>
          </h2>
      </div>
      <div class="flex">
        <div class="text-sm text-[#202124] mr-5 cursor-pointer hover:text-sky-500">About us</div>
        <div class="text-sm text-[#202124] mr-5 cursor-pointer hover:text-sky-500">Pricing</div>
        <div class="text-sm text-[#202124] mr-5 cursor-pointer hover:text-sky-500">F.A.Q</div>
        <div class="text-sm text-[#202124] mr-5 cursor-pointer hover:text-sky-500">Terms of Service</div>
        <div class="text-sm text-[#202124] mr-5 cursor-pointer hover:text-sky-500">Privacy Policy</div>
        <div class="text-sm text-[#202124] mr-5 cursor-pointer hover:text-sky-500">Blog</div>
        <div class="text-sm text-[#202124] cursor-pointer hover:text-sky-500">Contact</div>
      </div>
    </div>
    <div class="h-[1px] bg-gray-200"></div>
    <div class="px-20 pt-10 pb-14 flex justify-between items-center">
      <div>
        Copyright 2021 - All Rights Reserved.
      </div>
      <div class="flex">
        <img src="@/assets/images/Facebook.svg" alt="social" class="mr-10" />
        <img src="@/assets/images/Instagram.svg" alt="social" class="mr-10" />
        <img src="@/assets/images/Youtube.svg" alt="social" class="mr-10" />
        <img src="@/assets/images/Linkedin.svg" alt="social" class="" />
      </div>
    </div>
  </div>
</template>

<style></style>
