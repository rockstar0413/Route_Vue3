
<script setup lang="ts">
  import { computed, ref } from 'vue'
  import { useAddressStore } from '@/stores/address'
  import { useRoute } from 'vue-router'

  const isVisible = ref('password')
  const verification = ref('')
  const password = ref('')
  const confirm = ref('')

  const route = useRoute()
  const type = computed(()=>{
    let type = isVisible.value?'text':'password';
    return type;
  })

  const id = computed(()=>{
    let id = route.params.id;
    return id;
  })

  const showPassword = () =>{
    isVisible.value = 'text';
  }
  const hidePassword = () =>{
    isVisible.value = 'password';
  }
  const resetNewPassword = async () =>{
    if(password.value !==confirm.value) {
      alert("check your password")
      return;
    }
    if(verification.value!==""&&password.value!==""&&confirm.value!==""){
      const { resetPassword } = useAddressStore();
      await resetPassword(id.value.toString(), verification.value, password.value, confirm.value)
    }else{
      alert('Please fill out all fields.')
    }
  }
</script>
<template>
  <div class="flex justify-center items-center h-[calc(100vh)] pt-[72px]">
    <div class="!bg-white text-left p-7 rounded-2xl w-1/3">
      <div class="flex items-center justify-center space-x-3 mb-5">
        <h2
          class="font-bold text-2xl leading-6 text-gray-800 dark:text-white cursor-pointer select-none"
        >
          <span>Routes</span>
          <span class="text-sky-700">now</span>
        </h2>
      </div>
      <div class="font-bold text-xl text-center mb-4">Reset password</div>
      <div class="mb-4 ">
        <div class="mb-1">Verification code</div>
        <div class="relative">
          <input type="text" id="email"
            class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus-visible:outline-blue-300 block w-full p-2 h-[48px] "
            placeholder="Verification code" :value="verification" @change="verification = ($event.target as any).value"/>
        </div>
      </div>
      <div class="mb-2">
        <div class="mb-1">New password</div>
        <div class="relative">
          <input :type="type" id="password"
            class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus-visible:outline-blue-300 block w-full p-2 h-[48px] "
            placeholder="New password" :value="password" @change="password = ($event.target as any).value"/>
            <font-awesome-icon icon="fa-solid fa-eye" class="text-gray-400 absolute top-[17px] right-4 cursor-pointer hover:text-blue-500" @mousedown="showPassword" @mouseup="hidePassword"   />  
        </div>
      </div>
      <div class="mb-2">
        <div class="mb-1">Confirm password</div>
        <div class="relative">
          <input :type="type" id="confirm"
            class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus-visible:outline-blue-300 block w-full p-2 h-[48px] "
            placeholder="Confirm password" :value="confirm" @change="confirm = ($event.target as any).value"/>
            <font-awesome-icon icon="fa-solid fa-eye" class="text-gray-400 absolute top-[17px] right-4 cursor-pointer hover:text-blue-500" @mousedown="showPassword" @mouseup="hidePassword"   />  
        </div>
      </div>

      <div class="mt-8">
        <button class="bg-[#0083FC] hover:bg-[#0083CC] h-[40px] rounded-lg text-white text-base font-medium w-full mr-5" @click="resetNewPassword()">Reset password</button>
      </div>
      <div class="flex justify-center mt-5">
        <div class="">
          Already have an account?   <span class="text-blue-500 hover:text-blue-700 font-medium cursor-pointer"><RouterLink to="/auth/signin">Log in</RouterLink></span>
        </div>
      </div>
    </div>
  </div>
</template>

<style></style>
