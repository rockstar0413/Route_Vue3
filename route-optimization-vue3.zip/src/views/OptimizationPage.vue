<script setup lang="ts">
import GoogleMap from '@/components/GoogleMap.vue';
import { useRoute } from 'vue-router'
import { useAddressStore } from '@/stores/address'
import { onMounted, ref } from 'vue'

const route = useRoute()
const { setCenter, setBoundCenter } = useAddressStore();
const getCurrentLocation = () => {
  navigator.geolocation.getCurrentPosition(
    position => {
      setCenter(position.coords.latitude, position.coords.longitude)
      setBoundCenter(position.coords.latitude, position.coords.longitude)
    },
  )
}
onMounted(()=>{
  if(route.name==='provider'||route.name==='option'){
    getCurrentLocation()
  }
})
</script>

<template>
  <div class="lg:flex  pt-[72px]">
    <div class="w-full lg:w-1/2">
      <RouterView />
    </div>
    <div class="w-full lg:w-1/2">
      <div :class="[route.name==='preferences'?'h-[calc(100vh-40px)]':'lg:h-[calc(100vh-72px)]', route.name==='preferences'?'h-[calc(100vh-40px)]':'lg:h-[calc(100vh-72px)]']">
        <GoogleMap />
      </div>
      <div class="h-[40px] bg-white w-full flex items-center text-[#64748B]" v-if="route.name==='preferences'">
        <img src="@/assets/images/mile.svg" alt="mile">
        <div class="ml-2 mr-5">12.7 miles</div>
        <img src="@/assets/images/time.svg" alt="time">
        <div class="ml-2 mr-5">3.7 hours</div>
        <img src="@/assets/images/stop.svg" alt="stop">
        <div class="ml-2 mr-5">103 stops</div>
        <img src="@/assets/images/route.svg" alt="route">
        <div class="ml-2 mr-5">3 routes</div>
      </div>
    </div>
  </div>
</template>

<style scoped>
.scrollbar::-webkit-scrollbar {
  width: 6px;
  height: 20px;
}

.scrollbar::-webkit-scrollbar-track {
  border-radius: 100vh;
  background: white;
}

.scrollbar::-webkit-scrollbar-thumb {
  background: rgba(100, 116, 139, 0.8);
  border-radius: 100vh;
}

.scrollbar::-webkit-scrollbar-thumb:hover {
  background: rgba(100, 116, 139, 1);
}
</style>
