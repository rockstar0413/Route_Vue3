<script setup lang="ts">
import { ref, onMounted, watch } from 'vue';
import VueGoogleAutocomplete from "vue-google-autocomplete"
import { storeToRefs } from 'pinia'
import { useAddressStore } from '@/stores/address'
import DropAddress from '@/components/DropAddress.vue';
import DropAddressFull from '@/components/DropAddressFull.vue';
import router from '@/router';
import type { IRoute } from '@/shared/interfaces';
import MazPhoneNumberInput from 'maz-ui/components/MazPhoneNumberInput'
import type { CountryCode } from 'libphonenumber-js';
import DropZone from '@/components/DropZone.vue'
import { useRoute } from 'vue-router'
const { getCheckedAddresses, getFilteredAddresses, getDeliveryType, getToken, getPoint } = storeToRefs(useAddressStore())
const { 
  clearAddresses, 
  setCenter, 
  setBoundCenter, 
  fetchPickUpAddress, 
  updatePickUpAddress, 
  updateSingleRoute, 
  changeCheckState, 
  deleteSingleRoute, 
  deleteMultipleRoute, 
  setSearchAddress,
  setBeforeRoute,
  clearOptimizeRoutes,
  setPlan0
} = useAddressStore()

const route = useRoute()
const getCurrentLocation = () => {
  navigator.geolocation.getCurrentPosition(
    position => {
      setCenter(position.coords.latitude, position.coords.longitude)
      setBoundCenter(position.coords.latitude, position.coords.longitude)
    },
  )
}
const backPage = async () => {
  await clearAddresses()
  await getCurrentLocation()
  router.push({ name: "option" });
}
const nextPage = () => {
  if (getFilteredAddresses.value.length === 0) {
    alert("Please add addresses!")
  } else
    router.push({ name: "preferences" });
}
const add_point = ref(null)
const add_address = ref(null)
const update_address = ref(null)
const isEditable = ref(false)
const isDrop = ref(false)
const isAll = ref(false)
const pick_latitude = ref('')
const pick_longitude = ref('')
const pick_selected_address = ref('')
const drop_latitude = ref('')
const drop_longitude = ref('')
const drop_selected_address = ref('')
const apt = ref('')
const isAllChecked = ref(false)
const isViewAllChecked = ref(false)
const isConfirmDelete = ref(false)
const isConfirmMultiDelete = ref(false)
const isUploadDone = ref(false)
const search_address = ref('')
const results = ref('')
const edit_address = ref('')
const edit_latitude = ref('')
const edit_longitude = ref('')
const edit_receiver = ref('')
const edit_description = ref('')
const edit_apt = ref('')
const phoneNumber = ref('')
const selected_address_id = ref('')
const defaultPhoneNumber = ref('')
const edit_country_code = ref("US" as CountryCode)
onMounted(() => {
  clearOptimizeRoutes()
  setBeforeRoute((route.name as any).toString())
  setPlan0()
  pick_selected_address.value = getPoint.value.optimize_point_address;
  pick_latitude.value = getPoint.value.optimize_point_latitude;
  pick_longitude.value = getPoint.value.optimize_point_longitude;
  (add_point.value as any).update(getPoint.value.optimize_point_address)
})
const setPlace = (address: any, data: any) => {
  drop_latitude.value = data.geometry.location.lat();
  drop_longitude.value = data.geometry.location.lng();
  drop_selected_address.value = data.formatted_address;
}
const setEditPlace = (address: any, data: any) => {
  edit_latitude.value = data.geometry.location.lat().toString();
  edit_longitude.value = data.geometry.location.lng().toString();
  edit_address.value = data.formatted_address;
}
const addPoint = (address: any, data: any) => {
  pick_latitude.value = data.geometry.location.lat();
  pick_longitude.value = data.geometry.location.lng();
  pick_selected_address.value = data.formatted_address;
  if (getToken.value === "") {
    alert("You lost token. Please go back to previous page")
    return
  }
  if (getPoint.value.optimize_point_address === "") {
    fetchPickUpAddress(pick_selected_address.value, pick_latitude.value, pick_longitude.value);
  } else {
    updatePickUpAddress(pick_selected_address.value, pick_latitude.value, pick_longitude.value);
  }
}
const saveAddress = () => {
  const { fetchDropOffAddress } = useAddressStore();
  if (pick_latitude.value !== "" && pick_longitude.value !== "" && pick_selected_address.value !== "") {
    if (drop_latitude.value !== "" && drop_longitude.value !== "" && drop_selected_address.value !== "") {
      if (getToken.value === "") {
        alert("You lost token. Please go back to previous page")
        return
      }
      fetchDropOffAddress(drop_selected_address.value, drop_latitude.value, drop_longitude.value, apt.value);
    }
    else alert("Please enter a location!")
  } else {
    alert("Please pick up address!")
  }
  clearDropAddress();
}
const updateRouteDetail = () => {
  try {
    if (edit_address.value !== "") {
      updateSingleRoute(edit_address.value, edit_receiver.value, (results as any)?.countryCallingCode ? (results as any)?.countryCallingCode : "", (results as any)?.nationalNumber ? (results as any)?.nationalNumber : "", edit_description.value, edit_apt.value, selected_address_id.value, edit_latitude.value, edit_longitude.value, (results as any)?.countryCode ? (results as any)?.countryCode : "");
      hideEditPanel();
    } else { alert("Please select address") }
  } catch (e) {
  }
}
const clearDropAddress = () => {
  drop_latitude.value = "";
  drop_longitude.value = "";
  drop_selected_address.value = "";
  apt.value = "";
  (add_address.value as any).clear();
}
const changeEditable = (id: string) => {
  isEditable.value = true;
  selected_address_id.value = id;
  let temp: IRoute = (getFilteredAddresses.value.filter((item: IRoute) => item.optimize_route_id.toString() === selected_address_id.value.toString()))[0];
  getFilteredAddresses.value.map((item: IRoute) => {
    return item;
  })
  edit_address.value = temp.address;
  edit_apt.value = temp.apartment_no;
  edit_description.value = temp.description;
  edit_latitude.value = temp.latitude.toString();
  edit_longitude.value = temp.longitude.toString();
  edit_receiver.value = temp.contact_person;
  defaultPhoneNumber.value = temp.phone || "";
  edit_country_code.value = (temp.country_code || "US") as CountryCode;
  (update_address.value as any).update(temp.address)
}
const chooseDeleteItem = (id: string) => {
  showConfirmDelete();
  selected_address_id.value = id;
}
const hideEditPanel = () => {
  isEditable.value = false;
}
const showDropZone = () => {
  if (getPoint.value.optimize_point_address !== "") {
    isDrop.value = true;
  } else {
    alert("Please pick up address!")
  }
}
const hideDropZone = () => {
  isDrop.value = false;
}
const hideUploadDone = () => {
  isUploadDone.value = false;
}
const showUploadDone = () => {
  isUploadDone.value = true;
}
const doneUpload = () => {
  showUploadDone()
  hideDropZone()
}
const showConfirmDelete = () => {
  isConfirmDelete.value = true;
  hideEditPanel();
}
const hideConfirmDelete = () => {
  isConfirmDelete.value = false;
}
const showConfirmMultiDelete = () => {
  isConfirmMultiDelete.value = true;
  hideEditPanel();
}
const hideConfirmMultiDelete = () => {
  isConfirmMultiDelete.value = false;
}
const showAllAddress = () => {
  isAll.value = true;
}
const hideAllAddress = () => {
  isAll.value = false;
}
const changeIsAllChecked = () => {
  isAllChecked.value = !isAllChecked.value;
  changeCheckState(isAllChecked.value);
}
const changeIsViewAllChecked = () => {
  isViewAllChecked.value = !isViewAllChecked.value;
  changeCheckState(isViewAllChecked.value);
}
const deleteItem = () => {
  console.log(selected_address_id.value);
  deleteSingleRoute(selected_address_id.value);
  hideConfirmDelete();
}
const changeChecked = (address: IRoute) => {
  if (!address.checked) {
    isAllChecked.value = false;
    isViewAllChecked.value = false
  }
  if (getFilteredAddresses.value.length === getCheckedAddresses.value.length) {
    isAllChecked.value = true;
    isViewAllChecked.value = true;
  }
}
const deleteMultiAddress = () => {
  let temp: Array<number> = [];
  getCheckedAddresses.value.map((address: IRoute) => {
    temp.push(address.optimize_route_id)
    return address
  })
  deleteMultipleRoute(temp);
  hideConfirmMultiDelete()
}
const changeSearchAddress = () => {
  isAllChecked.value = false;
  changeCheckState(isAllChecked.value);
  setSearchAddress(search_address.value)
}
watch(search_address, (value) => {
  changeSearchAddress()
})

</script>

<template>
  <div class="w-full">
    <div
    class="w-full bg-[rgba(0,0,0,0.5)] fixed flex justify-center items-center h-[calc(100vh+72px)] z-40 p-10 pt-28 -top-[72px]"
        v-if="isUploadDone">
        <div class="py-5 px-5 flex justify-center bg-white rounded-xl w-[400px]">
          <div class="w-full">
            <div class=" flex justify-end w-full">
              <img src="@/assets/images/CloseDialog.svg" alt="GreenCheck" class="cursor-pointer" @click="hideUploadDone">
            </div>
            <div class="flex justify-center w-full mt-2 mb-3">
              <img src="@/assets/images/GreenCheck.svg" alt="CloseDialog">
            </div>
            <div class="text-xl font-bold text-center mb-2">Upload complete!</div>
            <div class="text-base font-normal text-[#9E9FA6] text-center mb-2">This file is uploaded successfully!</div>
            <div class="flex justify-center mt-5">
              <button
                class="border border-sky-500 hover:border-sky-700 rounded-xl text-sky-500 hover:text-sky-700 font-medium w-[180px] h-[56px]"
                @click="hideUploadDone">Close</button>
            </div>
          </div>
        </div>
      </div>
    <div class="w-full relative" v-show = "!isDrop">
      <div
        class="w-full bg-[rgba(0,0,0,0.5)] fixed flex justify-center items-center h-[calc(100vh+72px)] z-20 p-10 pb-0 pt-28 -top-[72px]"
        v-if="isAll">
        <div class="py-10 pt-0 bg-white w-full h-full rounded-lg bg-white">
          <div class="flex justify-between items-center px-7 py-3 bg-[#F5F6F8] rounded-t-lg">
            <div class="text-[#202027] font-bold text-xl">{{getDeliveryType===1?"All drop-off address":"All pick up address"}}</div>
            <div class="hover:text-black cursor-pointer" @click="hideAllAddress()">
              <img src="@/assets/images/close.svg" alt="Close" />
            </div>
          </div>
          <div class="flex justify-between items-center px-7 bg-white pt-2">
            <div class="text-[#64748B] font-normal text-lg">{{getDeliveryType===1?"Drop-off address count:":"Pick up address count:"}} <span class="font-bold text-black">{{getFilteredAddresses.length}}</span></div>
            <div class="flex items-center cursor-pointer" v-if="getCheckedAddresses.length>0"
              @click="showConfirmMultiDelete">
              <img src="@/assets/images/dustbin.svg" alt="Close" />
              <span class="text-[#EB5757] ml-3">Delete selected</span>
            </div>
          </div>
          <div class="flex py-2 px-7 bg-white">
            <div
              class="w-full bg-gray-200 rounded flex items-center p-2 px-4 h-[40px] text-[#64748B] text-[12px] font-[500]">
              <div class="basis-[8%] flex items-center">
                <input type="checkbox" class="w-[20px] h-[20px] rounded border border-gray-100 bg-gray-300"
                  v-model="isViewAllChecked" @click="changeIsViewAllChecked" />
              </div>
              <div class="basis-[5%]">
                STOP
              </div>
              <div class="basis-[35%]">
                ADDRESS
              </div>
              <div class="basis-[10%]">
                APT. #
              </div>
              <div class="basis-[15%]">
                RECEIVER NAME
              </div>
              <div class="basis-[15%]">
                PHONE NUMBER
              </div>
              <div class="basis-[20%]">
                DESCRIPTION
              </div>
            </div>
          </div>
          <div
            class="flex py-2 px-7 rounded-lg border border-transparent hover:bg-sky-100 hover:border hover:border-sky-300"
            v-for="(address, index) in getFilteredAddresses">
            <drop-address-full :address="address" :index="index" @changeEditable="changeEditable"
              @deleteItem="chooseDeleteItem" @changeChecked="changeChecked" />
          </div>
        </div>
      </div>
      <div
        class="w-full bg-[rgba(0,0,0,0.5)] fixed flex justify-center items-center h-[calc(100vh+72px)] z-40 p-10 pt-28 -top-[72px]"
        v-if="isConfirmDelete">
        <div class="p-5 flex justify-center bg-white rounded-xl w-[300px]">
          <div>
            <div class="text-xl font-medium text-center">Are you sure you want to <br /> delete this order?</div>
            <div class="flex justify-center mt-4">
              <button
                class="border border-sky-500 hover:border-sky-700 rounded-xl text-sky-500 hover:text-sky-700 font-medium px-5 mr-5 h-[40px]"
                @click="hideConfirmDelete">Cancel</button>
              <button class="bg-[#EB5757] hover:bg-[#E05050] rounded-xl text-white font-medium px-5 h-[40px]"
                @click="deleteItem">Delete</button>
            </div>
          </div>
        </div>
      </div>
      <div
        class="w-full bg-[rgba(0,0,0,0.5)] fixed flex justify-center items-center h-[calc(100vh+72px)] z-40 p-10 pt-28 -top-[72px]"
        v-if="isConfirmMultiDelete">
        <div class="p-5 flex justify-center bg-white rounded-xl w-[300px]">
          <div>
            <div class="text-xl font-medium text-center">Are you sure you want to <br /> delete
              {{getCheckedAddresses.length}} order?</div>
            <div class="flex justify-center mt-4">
              <button
                class="border border-sky-500 hover:border-sky-700 rounded-xl text-sky-500 hover:text-sky-700 font-medium px-5 mr-5 h-[40px]"
                @click="hideConfirmMultiDelete">Cancel</button>
              <button class="bg-[#EB5757] hover:bg-[#E05050] rounded-xl text-white font-medium px-5 h-[40px]"
                @click="deleteMultiAddress">Delete</button>
            </div>
          </div>
        </div>
      </div>
      <div class="absolute border-l-2 bg-white px-5 pt-3 right-0 lg:right-[-400px] z-40 h-[calc(100vh-72px)]"
        v-show="isEditable">
        <div class="text-md font-medium pb-3">Drop-off address edit</div>
        <div class="pb-4">
          <div class="pb-1">Address</div>
          <VueGoogleAutocomplete id="autocomplete-4" ref="update_address"
            class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus-visible:outline-blue-300 block w-full p-2 h-[48px]"
            placeholder="Address" v-on:placechanged="setEditPlace">
          </VueGoogleAutocomplete>
        </div>
        <div class="pb-4">
          <div class="pb-1">Apt. #</div>
          <input type="text" id="first_name"
            class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus-visible:outline-blue-300 block w-full p-2"
            placeholder="Apt. #" v-model="edit_apt" required />
        </div>
        <div class="pb-4">
          <div class="pb-1">Receiver name</div>
          <div>
            <input type="text" id="first_name"
              class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus-visible:outline-blue-300 block w-full p-2"
              placeholder="Receiver name" v-model="edit_receiver" required />
          </div>
        </div>
        <div class="pb-4">
          <div class="pb-1">Phone number</div>
          <MazPhoneNumberInput v-model="phoneNumber" :default-phone-number="defaultPhoneNumber"
            :default-country-code="edit_country_code" show-code-on-list color="info" :preferred-countries="[]"
            :ignored-countries="[]" @update="results = $event" />
        </div>
        <div class="pb-4">
          <div class="pb-1">Description</div>
          <textarea id="first_name"
            class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus-visible:outline-blue-300 block w-full p-2 h-20"
            placeholder="Description" v-model="edit_description"></textarea>
        </div>
        <div class="flex  h-[40px]">
          <button
            class="border border-sky-500 hover:border-sky-700 rounded-xl text-sky-500 hover:text-sky-700 font-medium px-5 mr-5"
            @click="hideEditPanel">Cancel</button>
          <button class="bg-sky-500 hover:bg-sky-700 rounded-xl text-white font-medium px-5" @click="updateRouteDetail">
            Save details</button>
        </div>
      </div>
      <div class="font-bold text-lg text-black px-7 py-3">
        Manage Stops
      </div>
      <div class="bg-white pt-3  h-[calc(100vh-72px-52px)] ">
        <div class="text-md font-medium px-7 flex justify-between">
          <div>{{getDeliveryType===1?"Pick up address":"Drop-off address"}}</div>
        </div>
        <div class="flex py-2 px-7">
          <div class="w-full">
            <div class="relative">
              <VueGoogleAutocomplete id="autocomplete-2" ref="add_point"
                class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus-visible:outline-blue-300 block w-full p-2 pl-10 h-[48px]"
                placeholder="Enter a location" v-on:placechanged="addPoint">
              </VueGoogleAutocomplete>
              <span
                class="rounded-full bg-sky-600 text-white text-xs font-bold w-[24px] h-[24px] flex justify-center items-center mr-1 absolute top-[12px] left-[10px]">
                <font-awesome-icon icon="fa-solid fa-house" />
              </span>
            </div>
          </div>
          <div class="w-full flex items-center pl-3 cursor-pointer select-none text-gray-500 hover:text-gray-700"
            @click="showDropZone()">
            <img src="@/assets/images/uploadPlus.png" alt="uploadPlus" />
            <span class="pl-2">Upload a list of address</span>
          </div>
        </div>
        <div class="text-md font-medium pt-4 px-7 w-full lg:flex justify-between">
          <div class="flex items-center">
            {{getDeliveryType===1?"Drop-off address":"Pick up address"}}
            <span class="text-gray-400">(235)</span>
          </div>
          <div class="flex items-center">
            <div class="mr-2 cursor-pointer" v-if="getCheckedAddresses.length>0" @click="showConfirmMultiDelete">
              <div class="flex items-center">
                <img src="@/assets/images/dustbin.svg" alt="Close" class="h-[15px] w-[15px]" />
                <span class="text-[#EB5757] hover:text-[#EF5F5F] text-xs ml-1">Delete selected</span>
              </div>
            </div>
            <div class="relative">
              <input type="text" id="first_name"
                class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus-visible:outline-blue-300 block w-full p-2 pl-10"
                placeholder="Search Address" required v-model="search_address" @change="changeSearchAddress()" />
              <span
                class="rounded-full text-white text-xs font-bold w-[24px] h-[24px] flex justify-center items-center mr-1 absolute top-[7px] left-[10px]">
                <img src="@/assets/images/search.svg" alt="search" />
              </span>
            </div>
          </div>
        </div>
        <div class="flex py-2 px-7">
          <div
            class="w-full bg-gray-200 rounded flex items-center p-2 px-4 h-[40px] text-[#64748B] text-[12px] font-[500]">
            <div class="basis-[8%] flex items-center">
              <input type="checkbox" class="w-[20px] h-[20px] rounded border border-gray-100 bg-gray-300"
                v-model="isAllChecked" @click="changeIsAllChecked" />
            </div>
            <div class="basis-[10%]">
              STOP
            </div>
            <div class="basis-[52%]">
              ADDRESS
            </div>
            <div class="basis-[30%]">
              APT. #
            </div>
          </div>
        </div>
        <div class="flex px-7">
          <div class="w-full rounded flex h-[40px]">
            <div class="basis-6/12 px-2">
              <VueGoogleAutocomplete id="autocomplete-3" ref="add_address"
                class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus-visible:outline-blue-300 block w-full p-2  h-[40px]"
                placeholder="Enter a location" v-on:placechanged="setPlace">
              </VueGoogleAutocomplete>
            </div>
            <div class="basis-4/12 flex justify-center px-2">
              <input type="text" id="first_name"
                class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus-visible:outline-blue-300 block w-full p-2"
                placeholder="Apt. #" required v-model="apt" />
            </div>
            <div class="basis-2/12 flex justify-center px-2">
              <button class="bg-green-500 hover:bg-green-700 rounded-xl text-white font-medium w-full"
                @click="saveAddress()">Save</button>
            </div>
          </div>
        </div>
        <div
          :class="['overflow-auto scrollbar h-[calc(100vh-72px-52px-325px)] px-7', getFilteredAddresses.length===0?'flex items-center justify-center':'']">
          <div class="flex py-2 rounded-lg border border-transparent hover:bg-sky-100 hover:border hover:border-sky-300"
            v-for="(address, index) in getFilteredAddresses">
            <drop-address :address="address" :index="index" @changeEditable="changeEditable"
              @deleteItem="chooseDeleteItem" @changeChecked="changeChecked" />
          </div>
          <div class="text-center" v-if="getFilteredAddresses.length===0">
            <div class="flex justify-center"><img src="@/assets/images/doublePoints.svg" alt="doublePoints" /></div>
            <div class="text-lg text-[#64748B] mt-3">Lorem Ipsum is simply dummy text of the printing<br />
              and typesetting industry.</div>
          </div>
        </div>
        <div class="flex px-7 pb-3 pt-3">
          <div class="w-full rounded flex justify-between px-4 h-[40px] ">
            <div class="flex items-center text-[#64748B] hover:text-gray-700 cursor-pointer select-none"
              @click="showAllAddress()">
              View all address
            </div>
            <div class="flex">
              <button
                class="border border-sky-500 hover:border-sky-700 rounded-xl text-sky-500 hover:text-sky-700 font-medium px-5 mr-5"
                @click="backPage()">Back</button>
              <button class="bg-sky-500 hover:bg-sky-700 rounded-xl text-white font-medium px-5" @click="nextPage()">Setup route
                preferences</button>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="w-full relative" v-show ="isDrop">
      <div class="font-bold text-lg text-black px-7 py-3">
        Upload a list of address
      </div>
      <div class="bg-white py-3 px-7 h-[calc(100vh-72px-52px)] relative">
        <drop-zone @doneUpload="doneUpload()" />
        <div class="flex justify-end ">
          <button
            class="border border-sky-500 hover:border-sky-700 rounded-lg text-sky-500 hover:text-sky-700 font-medium mr-5 px-5 h-10 bottom-5 absolute"
            @click="hideDropZone()">Cancel</button>
        </div>
      </div>

    </div>
  </div>
</template>

<style scoped>
.scrollbar::-webkit-scrollbar {
  width: 6px;
  height: 20px;
}

.scrollbar::-webkit-scrollbar-track {
  border-radius: 100vh;
  background: white;
}

.scrollbar::-webkit-scrollbar-thumb {
  background: rgba(100, 116, 139, 0.8);
  border-radius: 100vh;
}

.scrollbar::-webkit-scrollbar-thumb:hover {
  background: rgba(100, 116, 139, 1);
}
</style>
