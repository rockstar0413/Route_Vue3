<script setup lang="ts">
import { onMounted, ref } from 'vue';
import VueGoogleAutocomplete from "vue-google-autocomplete"
import { storeToRefs } from 'pinia'
import { useAddressStore } from '@/stores/address'
import OptimizationAlgorithm from '@/components/OptimizationAlgorithm.vue'
import router from '@/router';
import RoundTrip from '@/assets/images/RoundTrip.svg'
import NearestNeighbor from '@/assets/images/NearestNeighbor.svg'
import CustomizedTrip from '@/assets/images/CustomizedTrip.svg'
import { useRoute } from 'vue-router'

const { 
  setAlgorithm, 
  setBeforeRoute, 
  setNumberOfDrivers,
  setMinDrivers,
  setMaxDrivers,
  setRadius, 
  setLoadUploadTime,
  updateOptimizePoint, 
  returnStore, 
  divideAndOptimize 
} = useAddressStore();
const route = useRoute()
const { 
  getAlgorithm, 
  getAccessToken,
  getNumberOfDrivers,
  getMinDrivers,
  getMaxDrivers,
  getRadius,
  getLoadUploadTime
} = storeToRefs(useAddressStore())
// const driver_count = ref("2")
// const min_count = ref("2")
// const max_count = ref("4")
const algorithm_id = ref("1")
// const load_upload_time = ref("30")
const isCheck = ref(false)
// const effective_radius = ref("5")
const new_store_address = ref("")
const new_store_latitude = ref("")
const new_store_longitude = ref("")
const isConfirmCredit = ref(false)
const isOptimizeDone = ref(false)
const isConfirm = ref(true)
const isdAddCredit = ref(false)
const isCardPay = ref(false)
const success = ref(false)
const apt = ref("")
const message = ref("Lorem Ipsum is simply dummy text of the printing")
const backPage = () => {
  router.push({ name: "addresses" });
}
const nextPage = () => {
  router.push({ name: "routes" });
}
onMounted(() => {
  setBeforeRoute((route.name as any).toString())
  setRadius(5)
});
const addStore = (address: any, data: any) => {
  new_store_latitude.value = data.geometry.location.lat();
  new_store_longitude.value = data.geometry.location.lng();
  new_store_address.value = data.formatted_address;
}
const changeChecked = () => {
  isCheck.value = !isCheck.value;
}
const sendStore = async () => {
  await returnStore(apt.value);
}
const optimizeRoute = async () => {
  if (getAccessToken.value !== "") {
    await updateOptimizePoint();
    const response = await divideAndOptimize()
    message.value = response?.message
    if (response?.status === 1) {
      success.value = true;
      showOptimizeDone()
    } else {
      success.value = false;
      showOptimizeDone()
    }
  } else router.push({ name: 'signin' })
}
const showConfirmCredit = () => {
  isConfirmCredit.value = true;
}
const hideConfirmCredit = () => {
  isConfirmCredit.value = false;
}
const showConfirm = () => {
  isConfirm.value = true;
}
const hideConfirm = () => {
  isConfirm.value = false;
}
const showAddCredit = () => {
  isdAddCredit.value = true;
}
const hideAddCredit = () => {
  isdAddCredit.value = false;
}
const showCardPay = () => {
  isCardPay.value = true;
}
const hideCardPay = () => {
  isCardPay.value = false;
}
const showOptimizeDone = () => {
  isOptimizeDone.value = true;
}
const hideOptimizeDone = () => {
  isOptimizeDone.value = false;
  if (success.value) nextPage()
}
const confirmCredit = () => {
  hideConfirmCredit()
  optimizeRoute()
}
const addCredit = () => {
  hideConfirm()
  showAddCredit()
}
const addCreditBack = () => {
  showConfirm()
  hideAddCredit()
}
const cardPay = () => {
  hideAddCredit()
  showCardPay()
}
const cardPayBack = () => {
  showConfirm()
  hideCardPay()
}
const payNow = () => {
  hideCardPay()
  showConfirm()
}
</script>

<template>
  <div class="">
    <div
      class="w-full bg-[rgba(0,0,0,0.5)] fixed flex justify-center items-center h-[calc(100vh+72px)] z-40 p-10 pt-28 -top-[72px]"
      v-if="isOptimizeDone">
      <div class="py-5 px-5 flex justify-center bg-white rounded-xl w-[480px]">
        <div class="w-full">
          <div class=" flex justify-end w-full">
            <img src="@/assets/images/CloseDialog.svg" alt="CloseDialog" class="cursor-pointer"
              @click="hideOptimizeDone">
          </div>
          <div class="flex justify-center w-full mt-2 mb-3" v-show="success">
            <img src="@/assets/images/GreenCheck.svg" alt="GreenCheck">
          </div>
          <div class="flex justify-center w-full mt-2 mb-3" v-show="!success">
            <div class="w-[98px] h-[98px] rounded-full bg-red-500 flex justify-center items-center">
              <font-awesome-icon icon="fa-solid fa-xmark" class="text-white text-5xl" />
            </div>
          </div>
          <div class="text-xl font-bold text-center mb-2">{{ success ? 'Successful!' : 'Failed' }}</div>
          <div class="text-base font-normal text-[#9E9FA6] text-center mb-2">{{ message }}</div>
          <div class="flex justify-center mt-5">
            <button
              class="border border-sky-500 hover:border-sky-700 rounded-xl text-sky-500 hover:text-sky-700 font-medium w-full h-[56px]"
              @click="hideOptimizeDone">Close</button>
          </div>
        </div>
      </div>
    </div>
    <div
      class="w-full bg-[rgba(0,0,0,0.5)] fixed flex justify-center items-center h-[calc(100vh+72px)] z-40 p-10 pt-28 -top-[72px]"
      v-if="isConfirmCredit">
      <div class="py-10 px-10 flex justify-center bg-white rounded-xl w-[480px]" v-if="isConfirm">
        <div class="w-full">
          <div class=" flex justify-end w-full">
            <img src="@/assets/images/CloseDialog.svg" alt="GreenCheck" class="cursor-pointer"
              @click="hideConfirmCredit">
          </div>
          <div class="text-xl font-bold text-center mb-2">Confirm optimize route</div>
          <div class="text-base font-normal text-[#9E9FA6] text-center mb-2">Lorem Ipsum is simply dummy text of the
            printing</div>
          <div class="w-full flex justify-between mb-2 mt-7">
            <div class="text-[#1C1E31] text-lg">Amount</div>
            <div class="text-[#202027] flex items-center">
              <span class="mr-2">My Balance:</span>
              <span class="font-bold">300</span>
            </div>
          </div>
          <div class="w-full border rounded-lg border-[#CCD2E2] py-4 mb-5 flex justify-center items-center">
            <div>
              <span class="text-[#1C1E31] mr-2 font-bold">210</span>
              <span class="text-[#202027]">credit</span>
            </div>
          </div>
          <div class="flex justify-center mt-2 mb-5">
            <button class="bg-[#0083FC] hover:bg-[#1093FC] rounded-xl text-white font-medium px-5 w-full py-4"
              @click="confirmCredit">Confirm</button>
          </div>
          <div class="flex justify-between">
            <div class="text-[#EB5757]">
              <div>Sorry! You have no balance.</div>
              <div>Please increase your balance.</div>
            </div>
            <div>
              <button
                class="border border-[#27AE60] hover:border-[#37BE70] rounded-xl text-[#27AE60] hover:text-[#37BE70] font-medium px-4 h-[50px]"
                @click="addCredit">Add Credit</button>
            </div>
          </div>
        </div>
      </div>
      <div class="py-10 px-10 flex justify-center bg-white rounded-xl " v-if="isdAddCredit">
        <div>
          <div class=" flex justify-start items-center w-full cursor-pointer hover:text-sky-700" @click="addCreditBack">
            <font-awesome-icon icon="fa-solid fa-arrow-left" class="text-[#666666]" />
            <span class="ml-2 text-[#666666]">Back</span>
          </div>
          <div class="text-xl font-bold text-center mb-2">Confirm optimize route</div>
          <div class="text-base font-normal text-[#9E9FA6] text-center mb-2">Lorem Ipsum is simply dummy text of the
            printing</div>
          <div class="flex justify-between items-center mt-10 grid grid-cols-3 gap-10">
            <div class="col-span-3 lg:col-span-1 border border-gray-300 rounded-2xl py-10">
              <div class="text-2xl font-bold mb-2 px-10">
                Essentials
              </div>
              <div class="text-xs text-[#64748B] mb-4 px-10">
                Everything you need to plan and dispatch optimized routes
              </div>
              <div class="flex items-center px-10">
                <div class="text-4xl font-bold text-[#202124] mr-3">$29</div>
                <div class="text-xs text-[#64748B]">/dirver/month</div>
              </div>
              <div class="px-10">
                <button
                  class="bg-[#0083FC] hover:bg-[#0083CC] h-[48px] w-full rounded-lg text-white text-base font-medium px-10 mr-5 my-7"
                  @click="cardPay">
                  Try free for 7 days
                </button>
              </div>
              <div class="h-[1px] bg-gray-300 mb-5"></div>
              <div class="text-[#202124] text-lg px-10">
                <div class="font-medium">KEY FEATURES</div>
                <div>
                  <font-awesome-icon icon="fa-solid fa-check" class="text-green-500 ml-2 mt-4" />
                  <span class="ml-4">Plan 100 stops at once</span>
                </div>
                <div>
                  <font-awesome-icon icon="fa-solid fa-check" class="text-green-500 ml-2 mt-4" />
                  <span class="ml-4">Dispatch routes to driver app</span>
                </div>
                <div>
                  <font-awesome-icon icon="fa-solid fa-check" class="text-green-500 ml-2 mt-4" />
                  <span class="ml-4">Plan optimized routes in minutes</span>
                </div>
                <div>
                  <font-awesome-icon icon="fa-solid fa-check" class="text-green-500 ml-2 mt-4" />
                  <span class="ml-4">Web Integration</span>
                </div>
              </div>
            </div>
            <div class="col-span-3 lg:col-span-1 border border-gray-300 rounded-2xl py-10">
              <div class="flex items-center justify-between px-10">
                <div class="text-2xl font-bold mb-2">
                  Professional
                </div>
                <div class="bg-sky-100 text-sky-500 p-1 px-3 rounded-lg">Popular</div>
              </div>
              <div class="text-xs text-[#64748B] mb-4 px-10">
                Everything you need to plan and dispatch optimized routes
              </div>
              <div class="flex items-center px-10">
                <div class="text-4xl font-bold text-[#202124] mr-3">$49</div>
                <div class="text-xs text-[#64748B]">/dirver/month</div>
              </div>
              <div class="px-10">
                <button
                  class="bg-[#0083FC] hover:bg-[#0083CC] h-[48px] w-full rounded-lg text-white text-base font-medium px-10 mr-5 my-7"
                  @click="cardPay">
                  Try free for 7 days
                </button>
              </div>
              <div class="h-[1px] bg-gray-300 mb-5"></div>
              <div class="text-[#202124] text-lg px-10">
                <div class="font-medium">KEY FEATURES</div>
                <div>
                  <font-awesome-icon icon="fa-solid fa-check" class="text-green-500 ml-2 mt-4" />
                  <span class="ml-4">Plan 100 stops at once</span>
                </div>
                <div>
                  <font-awesome-icon icon="fa-solid fa-check" class="text-green-500 ml-2 mt-4" />
                  <span class="ml-4">Dispatch routes to driver app</span>
                </div>
                <div>
                  <font-awesome-icon icon="fa-solid fa-check" class="text-green-500 ml-2 mt-4" />
                  <span class="ml-4">Plan optimized routes in minutes</span>
                </div>
                <div>
                  <font-awesome-icon icon="fa-solid fa-check" class="text-green-500 ml-2 mt-4" />
                  <span class="ml-4">Web Integration</span>
                </div>
              </div>
            </div>
            <div class="col-span-3 lg:col-span-1 border border-gray-300 rounded-2xl py-10">
              <div class="flex items-center justify-between px-10">
                <div class="text-2xl font-bold mb-2">
                  Premium
                </div>
              </div>
              <div class="text-xs text-[#64748B] mb-4 px-10">
                Scale your delivery operations with driver management tools
              </div>
              <div class="flex items-center px-10">
                <div class="text-4xl font-bold text-[#202124] mr-3">$99</div>
                <div class="text-xs text-[#64748B]">/dirver/month</div>
              </div>
              <div class="px-10">
                <button
                  class="bg-transparent border-[3px] border-sky-500 h-[48px] text-sky-500 rounded-lg w-full px-10 mr-5 my-7 font-medium flex items-center justify-center"
                  @click="cardPay">
                  Contact sales
                </button>
              </div>
              <div class="h-[1px] bg-gray-300 mb-5"></div>
              <div class="text-[#202124] text-lg px-10">
                <div class="font-medium">KEY FEATURES</div>
                <div>
                  <font-awesome-icon icon="fa-solid fa-check" class="text-green-500 ml-2 mt-4" />
                  <span class="ml-4">Everything in Recipient</span>
                </div>
                <div>
                  <font-awesome-icon icon="fa-solid fa-check" class="text-green-500 ml-2 mt-4" />
                  <span class="ml-4">Export data to other services</span>
                </div>
                <div class="h-[78px]">

                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="py-10 flex justify-center bg-white rounded-xl w-[480px]" v-if="isCardPay">
        <div class="w-full">
          <div class=" flex justify-between w-full px-10">
            <div class=" flex justify-start items-center w-full cursor-pointer hover:text-sky-700" @click="cardPayBack">
              <font-awesome-icon icon="fa-solid fa-arrow-left" class="text-[#666666]" />
              <span class="ml-2 text-[#666666]">Back</span>
            </div>
            <img src="@/assets/images/CloseDialog.svg" alt="GreenCheck" class="cursor-pointer"
              @click="hideConfirmCredit">
          </div>
          <div class="text-xl font-bold text-center mb-2">Confirm optimize route</div>
          <div class="text-base font-normal text-[#9E9FA6] text-center mb-2">Lorem Ipsum is simply dummy text of the
            printing</div>
          <div class="w-full relative">
            <div class="w-full h-[1px] bg-[#CCD2E2] absolute top-[54px]"></div>

            <div class="px-10 w-full">
              <ul class="nav nav-tabs flex flex-col md:flex-row flex-wrap list-none border-b-0 pl-0" id="tabs-tab"
                role="tablist">
                <li class="nav-item" role="presentation">
                  <a href="#tabs-home" class="
                    nav-link
                    block
                    font-medium
                    text-base
                    leading-tight
                    border-x-0 border-t-0 border-b-2 border-transparent
                    px-6
                    py-3
                    my-2
                    hover:border-transparent hover:bg-gray-100
                    focus:border-transparent
                    active
                  " id="tabs-home-tab" data-bs-toggle="pill" data-bs-target="#tabs-home" role="tab"
                    aria-controls="tabs-home" aria-selected="true">Credit card</a>
                </li>
                <li class="nav-item" role="presentation">
                  <a href="#tabs-profile" class="
                    nav-link
                    block
                    font-medium
                    text-base
                    leading-tight
                    border-x-0 border-t-0 border-b-2 border-transparent
                    px-6
                    py-3
                    my-2
                    hover:border-transparent hover:bg-gray-100
                    focus:border-transparent
                  " id="tabs-profile-tab" data-bs-toggle="pill" data-bs-target="#tabs-profile" role="tab"
                    aria-controls="tabs-profile" aria-selected="false">Paypal</a>
                </li>
                <li class="nav-item" role="presentation">
                  <a href="#tabs-messages" class="
                    nav-link
                    block
                    font-medium
                    text-base
                    leading-tight
                    border-x-0 border-t-0 border-b-2 border-transparent
                    px-6
                    py-3
                    my-2
                    hover:border-transparent hover:bg-gray-100
                    focus:border-transparent
                  " id="tabs-messages-tab" data-bs-toggle="pill" data-bs-target="#tabs-messages" role="tab"
                    aria-controls="tabs-messages" aria-selected="false">Apple pay</a>
                </li>
              </ul>
            </div>
          </div>
          <div class="tab-content px-10" id="tabs-tabContent">
            <div class="tab-pane fade show active" id="tabs-home" role="tabpanel" aria-labelledby="tabs-home-tab">
              <div class="text-[#1C1E31] mb-2 mt-5">Card Number</div>
              <input type="text" id="credit_number"
                class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus-visible:outline-blue-300 block w-full p-2 h-[48px]"
                placeholder="Enter credit card number" />
              <div class="grid grid-cols-2 gap-4 mt-5">
                <div class="col-span-1">
                  <div class="text-[#1C1E31] mb-2">Expiration date</div>
                  <input type="text" id="credit_number"
                    class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus-visible:outline-blue-300 block w-full p-2 h-[48px]"
                    placeholder="MM/YY" />
                </div>
                <div class="col-span-1">
                  <div class="text-[#1C1E31] mb-2">Security code</div>
                  <input type="text" id="cvc"
                    class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus-visible:outline-blue-300 block w-full p-2 h-[48px]"
                    placeholder="CVC" />
                </div>
              </div>
            </div>
            <div class="tab-pane fade" id="tabs-profile" role="tabpanel" aria-labelledby="tabs-profile-tab">
              <div class="text-[#1C1E31] mb-2 mt-5">Card Number</div>
              <input type="text" id="credit_number"
                class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus-visible:outline-blue-300 block w-full p-2 h-[48px]"
                placeholder="Enter credit card number" />
              <div class="grid grid-cols-2 gap-4 mt-5">
                <div class="col-span-1">
                  <div class="text-[#1C1E31] mb-2">Expiration date</div>
                  <input type="text" id="credit_number"
                    class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus-visible:outline-blue-300 block w-full p-2 h-[48px]"
                    placeholder="MM/YY" />
                </div>
                <div class="col-span-1">
                  <div class="text-[#1C1E31] mb-2">Security code</div>
                  <input type="text" id="cvc"
                    class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus-visible:outline-blue-300 block w-full p-2 h-[48px]"
                    placeholder="CVC" />
                </div>
              </div>
            </div>
            <div class="tab-pane fade" id="tabs-messages" role="tabpanel" aria-labelledby="tabs-profile-tab">
              <div class="text-[#1C1E31] mb-2 mt-5">Card Number</div>
              <input type="text" id="credit_number"
                class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus-visible:outline-blue-300 block w-full p-2 h-[48px]"
                placeholder="Enter credit card number" />
              <div class="grid grid-cols-2 gap-4 mt-5">
                <div class="col-span-1">
                  <div class="text-[#1C1E31] mb-2">Expiration date</div>
                  <input type="text" id="credit_number"
                    class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus-visible:outline-blue-300 block w-full p-2 h-[48px]"
                    placeholder="MM/YY" />
                </div>
                <div class="col-span-1">
                  <div class="text-[#1C1E31] mb-2">Security code</div>
                  <input type="text" id="cvc"
                    class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus-visible:outline-blue-300 block w-full p-2 h-[48px]"
                    placeholder="CVC" />
                </div>
              </div>
            </div>
          </div>
          <div class="flex justify-center mt-5 mb-5 px-10">
            <button class="bg-[#0083FC] hover:bg-[#1093FC] rounded-xl text-white font-medium px-5 w-full py-4"
              @click="payNow">Pay now</button>
          </div>
          <div class="flex justify-around px-10">
            <img src="@/assets/images/Card1.svg" alt="Card1" class="cursor-pointer">
            <img src="@/assets/images/Card2.svg" alt="Card2" class="cursor-pointer">
            <img src="@/assets/images/Card3.svg" alt="Card3" class="cursor-pointer">
            <img src="@/assets/images/Card4.svg" alt="Card4" class="cursor-pointer">
          </div>
        </div>
      </div>
    </div>
    <div class="w-full">
      <div class="font-bold text-lg text-black px-7 py-3">
        Route Preferences
      </div>
      <div class="bg-white pt-3 h-full relative pb-10 h-full">
        <div class="grid grid-cols-2 gap-6  px-7">
          <div class="col-span-2 lg:col-span-1">
            <div>Number of drivers</div>
            <input type="number" placeholder="Number of dirvers" min="1"
              class="bg-gray-50 border border-gray-300 text-gray-900 text-sm text-[#1C1E31] rounded-lg focus-visible:outline-blue-300 block w-full p-2 h-[40px]  mt-1"
              :value="getNumberOfDrivers" @input="(e)=>setNumberOfDrivers(Number((e.target as any).value))" />
          </div>
          <div class="col-span-2 lg:col-span-1">
            <div class="whitespace-nowrap">Min - Max number of stops count for a drivers</div>
            <div class="grid grid-cols-2 gap-4 mt-1">
              <div class="col-span-1">
                <input type="number" placeholder="Min" min="0"
                  class="bg-gray-50 border border-gray-300 text-gray-900 text-sm text-[#1C1E31] rounded-lg focus-visible:outline-blue-300 block w-full p-2 h-[40px]"
                  :value="getMinDrivers" @input="(e)=>setMinDrivers(Number((e.target as any).value))"/>
              </div>
              <div class="col-span-1">
                <input type="number" placeholder="Max" min="0"
                  class="bg-gray-50 border border-gray-300 text-gray-900 text-sm text-[#1C1E31] rounded-lg focus-visible:outline-blue-300 block w-full p-2 h-[40px]"
                  :value="getMaxDrivers" @input="(e)=>setMaxDrivers(Number((e.target as any).value))" />
              </div>
            </div>
          </div>
          <div class="col-span-2 lg:col-span-1">
            <div>Effective Radius</div>
            <div class="relative mt-1">
              <input type="number" placeholder="Effective Radius" min="0"
                class="bg-gray-50 border border-gray-300 text-gray-900 text-sm text-[#1C1E31] rounded-lg focus-visible:outline-blue-300 block w-full p-2 h-[40px]"
                :value="getRadius" @input="(e)=>setRadius(Number((e.target as any).value))"/>
              <div class="text-[#64748B] text-base absolute right-9 top-[7px]">mil</div>
            </div>
          </div>
          <div class="col-span-2 lg:col-span-1">
            <div>Load/Upload time</div>
            <div class="relative mt-1">
              <input type="number" placeholder="Load/Upload time" min="0"
                class="bg-gray-50 border border-gray-300 text-gray-900 text-sm text-[#1C1E31] rounded-lg focus-visible:outline-blue-300 block w-full p-2 h-[40px]"
                :value="getLoadUploadTime" @input="(e)=>setLoadUploadTime(Number((e.target as any).value))" />
              <div class="text-[#64748B] text-base absolute right-9 top-[7px]">min</div>
            </div>
          </div>
        </div>
        <div class="px-7">
          <div class="border border-[#CCD2E2] border-dashed p-3 mt-5">
            <div class=" flex items-center">
              <input type="checkbox" class="w-[20px] h-[20px] rounded border border-gray-100 bg-gray-300"
                check="isCheck" @change="changeChecked()" />
              <div class="ml-3">If task is set to failed, create a return to specified location in the same route</div>
            </div>
            <div class="grid grid-cols-12 gap-4 mt-3" v-if="isCheck">
              <div class="col-span-6">
                <VueGoogleAutocomplete id="autocomplete-3"
                  class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus-visible:outline-blue-300 block w-full p-2  h-[40px]"
                  placeholder="Enter a location" v-on:placechanged="addStore">
                </VueGoogleAutocomplete>
              </div>
              <div class="col-span-3">
                <input type="text" placeholder="Apt. #" min="0"
                  class="bg-gray-50 border border-gray-300 text-gray-900 text-sm text-[#1C1E31] rounded-lg focus-visible:outline-blue-300 block w-full p-2 h-[40px]"
                  v-model="apt" />
              </div>
              <div class="col-span-3">
                <button class="bg-sky-500 hover:bg-sky-700 rounded-lg text-white font-medium px-5 h-[40px]"
                  @click="sendStore">Submit</button>
              </div>
            </div>
          </div>
        </div>
        <div class="px-7 mt-4">
          <div class="text-[#202027] text-lg font-bold mb-3">Optimization Algorythm</div>
          <div class="grid grid-cols-3 gap-4">
            <OptimizationAlgorithm :icon="RoundTrip" title="Round Trip"
              content="Lorem Ipsum is simply dummy text of the printing" active="1" :current="getAlgorithm === 1"
              @click="setAlgorithm(1)" />
            <OptimizationAlgorithm :icon="NearestNeighbor" title="Nearest Neighbor"
              content="Lorem Ipsum is simply dummy text of the printing" active="1" :current="getAlgorithm === 2"
              @click="setAlgorithm(2)" />
            <OptimizationAlgorithm :icon="CustomizedTrip" title="Customized Trip"
              content="Lorem Ipsum is simply dummy text of the printing" active="0" :current="getAlgorithm === 3" />
          </div>
        </div>
        <div class="bottom-5 w-full flex items-center">
          <div class="grid grid-cols-2 gap-3 px-7  w-full">
            <div class="col-span-2 lg:col-span-1 flex items-center justify-center lg:justify-start ">
              <span>Available credit: </span>
              <span class="px-2 font-bold">200/1000</span>
              <span class="text-[#FF7E00] text-xs">Upgrade</span>
            </div>
            <div class="col-span-2 lg:col-span-1 w-full">
              <div class="flex items-center justify-center lg:justify-end">
                <div>
                  <button
                    class="border border-sky-500 hover:border-sky-700 rounded-lg text-sky-500 hover:text-sky-700 font-medium px-5 mr-5 h-[40px]"
                    @click="backPage()">Back</button>
                  <button class="bg-sky-500 hover:bg-sky-700 rounded-lg text-white font-medium px-5 h-[40px]"
                    @click="showConfirmCredit">Optimize
                    route</button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
.scrollbar::-webkit-scrollbar {
  width: 6px;
  height: 20px;
}

.scrollbar::-webkit-scrollbar-track {
  border-radius: 100vh;
  background: white;
}

.scrollbar::-webkit-scrollbar-thumb {
  background: rgba(100, 116, 139, 0.8);
  border-radius: 100vh;
}

.scrollbar::-webkit-scrollbar-thumb:hover {
  background: rgba(100, 116, 139, 1);
}
</style>
