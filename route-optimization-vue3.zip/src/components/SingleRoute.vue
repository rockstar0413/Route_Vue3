<script setup lang="ts">
import { ref, onMounted, onBeforeUnmount } from 'vue'
import type { IRoute } from '@/shared/interfaces';
import { useAddressStore } from '@/stores/address';

const { route, index, total, id } = defineProps<{ route: any, index: number, total: number, id:string }>()
const emit = defineEmits(['changeMenuDialog', 'changeChecked', 'deleteItem', 'editPopup', 'moveToPopup', 'changeStartPoint', 'changeFinishPoint'])
const isVisible = ref(false);
const isMenu = ref(false)
const $contextmenu = ref(null)

const { 
  deleteLocalStop
} = useAddressStore()
const overHandler = () => {
  isVisible.value = true;
};
const leaveHandler = () => {
  isVisible.value = false;
};
const changeMenu = () => {
  isMenu.value = true
}
const hideAllFields=()=>{
  isMenu.value = false
  emit('deleteItem', route.optimize_route_id)
}
onMounted(() => {
  document.addEventListener('click', hideMenu)
})
onBeforeUnmount(() => {
  document.removeEventListener('click', hideMenu)
})
const hideMenu = (e: any) => {
  if (!($contextmenu.value as any).contains(e.target)) {
    isMenu.value = false;
  }
}
const changeStartPoint=(e: any)=>{
  isMenu.value = false
  emit('changeStartPoint', route.optimize_route_id, index.toString());
}
const changeFinishPoint=(e: any)=>{
  isMenu.value = false
  emit('changeFinishPoint', route.optimize_route_id, index.toString());
}
const editPopup=(e: any)=>{
  isMenu.value = false
  emit('editPopup', route.optimize_route_id, route.address, index, total);
}
const moveToPopup=(e: any)=>{
  isMenu.value = false
  emit('moveToPopup', route.optimize_route_id, index.toString());
}
</script>

<template>
  <div class="w-full rounded flex p-2 px-4 h-[40px]" @mouseenter="overHandler" @mouseleave="leaveHandler">
    <div class="basis-[8%] flex items-center cursor-grab">
      <img src="@/assets/images/dots.svg" alt="dots" />
    </div>
    <div class="basis-[8%] flex items-center">
      <input type="checkbox" class="w-[20px] h-[20px] !rounded border border-gray-100 bg-gray-300"  v-model="route.checked" @change="$emit('changeChecked', route)"
      />
    </div>
    <div class="basis-[10%] flex items-center">
      <span v-if="index===0"
        class="rounded-full bg-green-500 text-white text-xs font-bold w-[24px] h-[24px] flex justify-center items-center mr-1">
        <img src="@/assets/images/Flag.svg" alt="Flag">
      </span>
      <span v-if="index!==0 && index===total-1"
        class="rounded-full bg-red-500 text-white text-xs font-bold w-[24px] h-[24px] flex justify-center items-center mr-1">
        <img src="@/assets/images/Flag.svg" alt="Flag">
      </span>
      <span v-if="index!==0 && index!==total-1"
        class="rounded-full bg-blue-500 text-white text-xs font-bold w-[24px] h-[24px] flex justify-center items-center mr-1">
        {{ index}}
      </span>
    </div>
    <div class="basis-[52%] truncate ">
      {{ route.address }}
    </div>
    <div class="basis-[22%] flex justify-between items-center">
      <div class="text-ellipsis">{{ route.apartment }}</div>
      <div class="relative h-[30px] flex items-center cursor-pointer" ref="$contextmenu" @click="()=>changeMenu()">
        <img src="@/assets/images/ThreeDots.svg" alt="ThreeDots" class="cursor-pointer">
        <div class="absolute top-[30px] -left-[200px] z-10">
          <div class=" bg-white w-full drop-shadow-lg rounded" v-if="isMenu">
            <div class="px-3 py-2 hover:bg-sky-100 w-full cursor-pointer flex items-center" @click="editPopup">
              <img src="@/assets/images/Edit.svg" alt="ThreeDots" class="mr-2" />
              <span>Edit</span>
            </div>
            <div class="px-3 py-2 hover:bg-sky-100 w-full cursor-pointer flex items-center" @click="hideAllFields">
              <img src="@/assets/images/Delete.svg" alt="ThreeDots" class="mr-2" />
              <span>Delete</span>
            </div>
            <div class="px-3 py-2 hover:bg-sky-100 w-full cursor-pointer flex items-center" @click="moveToPopup">
              <img src="@/assets/images/UpDown.svg" alt="ThreeDots" class="mr-2" />
              <span>Move to</span>
            </div>
            <div class="px-3 py-2 hover:bg-sky-100 w-full cursor-pointer flex items-center" @click="changeStartPoint">
              <span
                class="rounded-full bg-green-500 text-white text-xs font-bold w-[20px] h-[20px] flex justify-center items-center mr-1">
                <img src="@/assets/images/Flag.svg" alt="Flag">
              </span>
              <span class="whitespace-nowrap">Start optimization point</span>
            </div>
            <div class="px-3 py-2 hover:bg-sky-100 w-full cursor-pointer flex items-center" @click="changeFinishPoint">
              <span
                class="rounded-full bg-red-500 text-white text-xs font-bold w-[20px] h-[20px] flex justify-center items-center mr-1">
                <img src="@/assets/images/Flag.svg" alt="Flag">
              </span>
              <span class="whitespace-nowrap">Finish optimization point</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
.scrollbar::-webkit-scrollbar {
  width: 6px;
  height: 20px;
}

.scrollbar::-webkit-scrollbar-track {
  border-radius: 100vh;
  background: white;
}

.scrollbar::-webkit-scrollbar-thumb {
  background: rgba(100, 116, 139, 0.8);
  border-radius: 100vh;
  /* border: 1px solid rgba(100, 116, 139, 0.8); */
}

.scrollbar::-webkit-scrollbar-thumb:hover {
  background: rgba(100, 116, 139, 1);
}
</style>
