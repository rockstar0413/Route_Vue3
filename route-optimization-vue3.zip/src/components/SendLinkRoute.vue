<script setup lang="ts">
   import {useRoute} from 'vue-router'
   import router from '@/router'
   const route = useRoute();
   const goRoute = () =>{
    router.push({path:'plan/'+num.toString()})
   }
   const sendLink = () =>{
   }
  const { num, stop, time, mile, assign } = defineProps<{ num:number, stop:number, time:string, mile:string, assign:boolean }>()
</script>

<template>
  <div class="flex items-center w-full mb-4">
    <div class="px-3">
      <input type="checkbox" class="w-[20px] h-[20px] rounded border border-gray-100 bg-gray-300" check="isCheck"/>
    </div>
    <div class="border border-[#CCD2E2] rounded-xl w-full h-[80px] flex items-center justify-between px-5">
      <div class="flex items-center cursor-pointer" @click="goRoute()">
        <div class="mr-4" v-if="assign">
          <img src="@/assets/images/bluePoint.svg" alt="Dots" v-if="num%3===1" />
          <img src="@/assets/images/redPoint.svg" alt="Dots" v-if="num%3===2" />
          <img src="@/assets/images/greenPoint.svg" alt="Dots" v-if="num%3===0" />
        </div>
        <div class="text-sm text-[#64748B]">
          <div class="text-base text-[#202027] font-bold">Plan {{num}}</div>
          <div class="flex">
            <span>{{stop}} Stops </span>
            <img src="@/assets/images/dot.svg" alt="dot" class="px-2">
            <span>{{Math.floor(Number(time)/60)}}h {{Number(time)%60}}m </span>
            <img src="@/assets/images/dot.svg" alt="dot" class="px-2">
            <span>{{mile}} mil </span>
          </div>
        </div>
      </div>
      <div class="flex items-center">
        <button class="bg-sky-500 hover:bg-sky-700 rounded-lg text-white font-medium px-5 h-[40px] flex items-center" @click="sendLink()">
          <img src="@/assets/images/Send.svg" alt="Edit" class="mr-2">
          <span class="hidden lg:block">Send link</span>
        </button>
      </div>
    </div>
  </div>
</template>

<style scoped>
</style>
