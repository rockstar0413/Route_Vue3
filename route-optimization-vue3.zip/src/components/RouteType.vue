<script setup lang="ts">
   import {useRoute} from 'vue-router'
   import router from '@/router'
   import { useAddressStore } from '@/stores/address'
   import {ref} from 'vue'
   import Config from '@/shared/config'
   const route = useRoute();
   const editRoute = () =>{
    router.push({path:'routes/'+num.toString()})
   }
  const { num, stop, time, mile, assign } = defineProps<{ num:number, stop:number, time:string, mile:string, assign:boolean }>()
  const {changeRouteVisible, getRouteEye} = useAddressStore()
  const changeVisible = (num:number) =>{
    changeRouteVisible(num)
  }
</script>

<template>
  <div class="flex items-center w-full mb-4">
    <img src="@/assets/images/dots.svg" alt="Dots" class="mr-5">
    <div class="border border-[#CCD2E2] rounded-xl w-full h-[80px] flex items-center justify-between px-5">
      <div class="flex items-center">
        <div class="mr-4 flex justify-center relative" v-if="assign">
          <font-awesome-icon icon="fa-solid fa-location-pin" :class="['text-[24px]', 'text-['+Config.colors[num%16]+']']"  :style="{color:Config.colors[num%16]}" />
          <div class="bg-white rounded-full w-[9px] h-[9px] absolute top-[5px]"></div>
        </div>
        <div class="mr-4" v-if="!assign">
          <img src="@/assets/images/grayPoint.svg" alt="Dots" />
        </div>
        <div class="text-sm text-[#64748B]">
          <div class="text-base text-[#202027] font-bold">Plan {{num}}</div>
          <div class="flex">
            <span>{{stop}} Stops </span>
            <img src="@/assets/images/dot.svg" alt="dot" class="px-2">
            <span>{{Math.floor(Number(time)/60)}}h {{Number(time)%60}}m </span>
            <img src="@/assets/images/dot.svg" alt="dot" class="px-2">
            <span>{{mile}} mil </span>
          </div>
        </div>
      </div>
      <div class="flex items-center">
        <button class="flex items-center rounded-md p-1 px-3 border border-[#CCD2E2]" @click="editRoute">
          <img src="@/assets/images/Edit.svg" alt="Edit" class="mr-2">
          <span class="hidden lg:block">Edit</span>
        </button>
        <img src="@/assets/images/eye.svg" alt="eye" class="ml-4 cursor-pointer" v-if="getRouteEye(num.toString())" @click="changeVisible(num)">
        <font-awesome-icon icon="fa-solid fa-eye-slash font-normal" class="ml-[17px] cursor-pointer" v-if="!getRouteEye(num.toString())" @click="changeVisible(num)" />
      </div>
    </div>
  </div>
</template>

<style scoped>
</style>
