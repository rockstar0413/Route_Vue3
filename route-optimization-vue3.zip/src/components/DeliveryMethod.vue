<script setup lang="ts">
  const { icon, title, content, current } = defineProps<{ icon:string, title:string, content:string, current:Boolean}>()
</script>

<template>
  <div :class="['h-[80px] w-full rounded-xl bg-white hover:bg-[#EBF5FF] drop-shadow-lg flex items-center mb-5 cursor-pointer select-none', current?'border border-[#0083FC] bg-[#EBF5FF]':'']">
    <div class="flex items-center px-5">
      <div class="mr-3">
        <img :src="icon" alt="Discovery" />
      </div>
      <div>
          <div class="text-base text-[#202027] font-bold">{{title}}</div>
          <div class="text-[#64748B] text-sm">{{content}}</div>
      </div>
    </div>
  </div>
</template>

<style scoped>
</style>
