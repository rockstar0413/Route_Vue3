<script setup lang="ts">
  const { icon, title, content, current, active } = defineProps<{ icon:string, title:string, content:string, current:Boolean, active:string}>()
</script>

<template>
  <div :class="['col-span-3 lg:col-span-1 rounded-xl bg-white drop-shadow-sm flex justify-center mb-5 cursor-pointer select-none p-3', active==='1'?'hover:bg-[#EBF5FF]':'', current&&active==='1'?'border border-[#0083FC] bg-[#EBF5FF]':'border border-[#CCD2E2]']">
    <div class="px-0">
      <div :class="['flex justify-center mb-3', active==='1'?'':'opacity-20']">
        <img :src="icon" alt="algorithm" />
      </div>
      <div>
          <div :class="['text-base font-bold', active==='1'?'text-[#202027]':'text-[#20202750]']">{{title}}</div>
          <div :class="['text-[#64748B] text-sm', active==='1'?'text-[#64748B]':'text-[#64748B50]']">{{content}}</div>
      </div>
    </div>
  </div>
</template>

<style scoped>
</style>
