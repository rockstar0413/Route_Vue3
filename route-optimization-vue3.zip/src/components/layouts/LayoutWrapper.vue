<script setup lang="ts">
  import {computed} from 'vue'
  import { useRoute } from 'vue-router'
  import DefaultLayout from './DefaultLayout.vue';
  const route = useRoute()
  const defaulLayout = 'DefaultLayout'
  const layout = computed(()=>{
    const layout = route.meta.layout || defaulLayout
    return DefaultLayout;
  })
</script>

<template>
  <component :is="layout">
    <slot />
  </component>
</template>

<style scoped>
</style>
