<script setup lang="ts">
import { computed, ref, onMounted, onBeforeUnmount } from 'vue'
import { RouterLink, useRoute } from 'vue-router'
import { storeToRefs } from 'pinia'
import { useAddressStore } from '@/stores/address'
import router from '@/router'

const { getAccessToken, getUser } = storeToRefs(useAddressStore())
const route = useRoute()
const isMenu = ref(false)
const $profileMenu = ref(null)
onMounted(()=>{
  document.addEventListener('click', hideMenu)
})
onBeforeUnmount(()=>{
  document.removeEventListener('click', hideMenu)
})
const link = computed(() => {
  return route.path;
})
const changeMenu = () => {
  isMenu.value = !isMenu.value;
}
const hideMenu = (e:any) =>{
  if(!($profileMenu.value as any).contains(e.target)){
    isMenu.value = false;
  }
}
const logout = async () => {
  const { logOutFromSystem } = useAddressStore()
  await logOutFromSystem()
  router.push({ name: 'landing' })
}

const goProfile = async () => {
  changeMenu()
  router.push({ name: 'profile' })
}
</script>

<template>
  <div class="3xl:container 3xl:mx-auto w-full fixed z-20" @click="()=>{}">
    <div class="bg-white dark:bg-gray-800 rounded shadow-lg py-3 px-7">
      <nav class="flex justify-between">

        <div class="flex items-center space-x-3">
          <RouterLink to="/">
            <h2 class="font-bold text-2xl leading-6 text-gray-800 dark:text-white cursor-pointer select-none">
              <span>Routes</span>
              <span class="text-sky-700">now</span>
            </h2>
          </RouterLink>
        </div>
        <div class="flex items-center" v-if="link.split('/')[1]==='optimize'">
          <ul class="hidden xl:flex flex-auto space-x-2 select-none">
            <RouterLink to="/optimization/provider">
              <li class="text-black cursor-pointer font-normal text-sm flex items-center">
                <span
                  class="rounded-full bg-sky-600 text-white text-xs font-bold w-[20px] h-[20px] flex justify-center items-center mr-1">
                  1
                </span>
                <span>Delivery method</span>
              </li>
            </RouterLink>
            <li class="text-black font-normal text-sm flex items-center">
              <span class="border-t-2 w-[15px]"></span>
            </li>
            <RouterLink to="/optimization/provider">
              <li class="text-black cursor-pointer font-normal text-sm flex items-center">
                <span
                  class="rounded-full bg-gray-300 text-white text-xs font-bold w-[20px] h-[20px] flex justify-center items-center mr-1">
                  2
                </span>
                <span>Manage Stop</span>
              </li>
            </RouterLink>
            <li class="text-black font-normal text-sm flex items-center">
              <span class="border-t-2 w-[15px]"></span>
            </li>
            <li class="text-black cursor-pointer font-normal text-sm flex items-center">
              <span
                class="rounded-full bg-gray-300 text-white text-xs font-bold w-[20px] h-[20px] flex justify-center items-center mr-1">
                3
              </span>
              <span>Route Preferences</span>
            </li>
            <li class="text-black font-normal text-sm flex items-center">
              <span class="border-t-2 w-[15px]"></span>
            </li>
            <li class="text-black cursor-pointer font-normal text-sm flex items-center">
              <span
                class="rounded-full bg-gray-300 text-white text-xs font-bold w-[20px] h-[20px] flex justify-center items-center mr-1">
                4
              </span>
              <span>Manage Routes</span>
            </li>
            <li class="text-black font-normal text-sm flex items-center">
              <span class="border-t-2 w-[15px]"></span>
            </li>
            <li class="text-black cursor-pointer font-normal text-sm flex items-center">
              <span
                class="rounded-full bg-gray-300 text-white text-xs font-bold w-[20px] h-[20px] flex justify-center items-center mr-1">
                5
              </span>
              <span>Optimize Route Plan</span>
            </li>
          </ul>
        </div>
        <div class="flex items-center" v-if="link.split('/')[1]!=='optimize'">
          <ul class="hidden lg:flex flex-auto space-x-10 select-none text-lg">
            <RouterLink to="/optimization/provider">
              <li class="text-black hover:text-blue-500 cursor-pointer font-medium text-base flex items-center">
                <span>Optimize</span>
              </li>
            </RouterLink>
            <RouterLink to="/#features">
              <li class="text-black hover:text-blue-500 cursor-pointer font-medium text-base flex items-center">
                <span>Features</span>
              </li>
            </RouterLink>
            <RouterLink to="/#pricing">
              <li class="text-black hover:text-blue-500 cursor-pointer font-medium text-base flex items-center">
                <span>Pricing</span>
              </li>
            </RouterLink>
            <li class="text-black hover:text-blue-500 cursor-pointer font-medium text-base flex items-center">
              <span>Contact us</span>
            </li>
          </ul>
        </div>
        <div class="flex space-x-3 justify-center items-center cursor-pointer pl-2 h-[48px] profile-menu" ref="$profileMenu">
          <div v-if="getAccessToken!==''" class="relative">
            <div class="flex items-center" @click="()=>changeMenu()">
              <span class="w-[48px]">
                <img src="@/assets/images/avatar.png" alt="avatar" />
              </span>
              <span class="text-sm whitespace-nowrap select-none ml-2">{{getUser.customer_name}}</span>
              <font-awesome-icon icon="fa-solid fa-angle-down" class="ml-1" />
            </div>
            <div class="absolute bg-white top-[60px] w-full drop-shadow-lg" v-if="isMenu">
              <div class="px-3 py-2 hover:bg-sky-100" @click="()=>goProfile()">Profile</div>
              <div class="h-[1px] bg-gray-200"></div>
              <div class="px-3 py-2 hover:bg-sky-100" @click="logout">logout</div>
            </div>
          </div>
          <div v-if="getAccessToken===''">
            <RouterLink to="/auth/signin">
              <button
                class="bg-[#0083FC] hover:bg-[#0083CC] h-[40px] rounded-lg text-white text-base font-medium w-[100px] mr-5">Login</button>
            </RouterLink>
            <RouterLink to="/auth/signup">
              <button
                class="bg-[#202124] hover:bg-[#101114] h-[40px] rounded-lg text-white text-base font-medium w-[100px]">Try
                it free</button>
            </RouterLink>
          </div>
        </div>
      </nav>
    </div>
  </div>
</template>
