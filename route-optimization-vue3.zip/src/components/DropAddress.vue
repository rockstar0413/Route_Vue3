<script setup lang="ts">
import { ref } from 'vue'
import type { IRoute } from '@/shared/interfaces';
const { address, index } = defineProps<{ address: IRoute, index: number }>()

const isVisible = ref(false);
const overHandler = () => {
  isVisible.value = true;
};
const leaveHandler = () => {
  isVisible.value = false;
};
</script>

<template>
  <div class="w-full rounded flex p-2 px-4 h-[40px]" @mouseenter="overHandler" @mouseleave="leaveHandler">
    <div class="basis-[8%] flex items-center">
      <input type="checkbox" class="w-[20px] h-[20px] !rounded border border-gray-100 bg-gray-300" v-model="address.checked" @change="$emit('changeChecked', address)" />
    </div>
    <div class="basis-[10%] flex items-center">
      <span
        class="rounded-full bg-blue-500 text-white text-xs font-bold w-[24px] h-[24px] flex justify-center items-center mr-1">
        {{ index + 1 }}
      </span>
    </div>
    <div class="basis-[52%] truncate ">
      {{ address.address }}
    </div>
    <div class="basis-[30%] flex justify-between">
      <div class="text-ellipsis">{{ address.apartment_no }}</div>
      <div class="flex items-center" v-if="isVisible.valueOf()">
        <div class="mr-3 " @click="$emit('changeEditable', address.optimize_route_id)">
          <img src="@/assets/images/Edit.svg" class="transform hover:scale-125" alt="edit" /></div>
        <div @click="$emit('deleteItem', address.optimize_route_id)"><img src="@/assets/images/Delete.svg" class="transform hover:scale-125"
            alt="delete" /></div>
      </div>
    </div>
  </div>
</template>

<style scoped>
.scrollbar::-webkit-scrollbar {
  width: 6px;
  height: 20px;
}

.scrollbar::-webkit-scrollbar-track {
  border-radius: 100vh;
  background: white;
}

.scrollbar::-webkit-scrollbar-thumb {
  background: rgba(100, 116, 139, 0.8);
  border-radius: 100vh;
  /* border: 1px solid rgba(100, 116, 139, 0.8); */
}

.scrollbar::-webkit-scrollbar-thumb:hover {
  background: rgba(100, 116, 139, 1);
}
</style>
