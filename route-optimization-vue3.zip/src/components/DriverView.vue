<script setup lang="ts">
import { ref } from 'vue'
const { route, index, total } = defineProps<{ route: any, index: number, total: number }>()
const isDetail = ref(false)
const toggleDetail = () =>{
  isDetail.value = !isDetail.value
}
</script>

<template>
  <div class="w-full rounded p-2 px-4">
    <div class="w-full flex justify-between">
      <div class="flex items-center">
      <span
        class="rounded-full bg-blue-500 text-white text-xs font-bold w-[24px] h-[24px] flex justify-center items-center mr-1">{{
            index + 1
        }}</span>
      <span class="ml-3">{{ route.address }}</span>
    </div>
    <div class="flex items-center">
      <button class="flex items-center rounded-md p-1 px-3 border border-[#CCD2E2]">
        <img src="@/assets/images/ColoredPin.svg" alt="Edit" class="mr-2">
        <span class="hidden lg:block whitespace-nowrap">Get direction</span>
      </button>
      <font-awesome-icon icon="fa-solid fa-angle-down cursor-pointer" class="ml-3" v-show="!isDetail" @click="toggleDetail()"/>
      <font-awesome-icon icon="fa-solid fa-angle-up cursor-pointer" class="ml-3" v-show="isDetail" @click="toggleDetail()"/>
    </div>
    </div>
    <div class="ml-[40px]" v-show="isDetail">
      <div class="flex gap-4 mb-3">
        <div>
          <div class="text-xs text-[#1C1E31]">Apt.#</div>
          <div class="text-xs text-[#999999]">5432</div>
        </div>
        <div>
          <div class="text-xs text-[#1C1E31]">Receiver name</div>
          <div class="text-xs text-[#999999]">Isa Abilov</div>
        </div>
        <div>
          <div class="text-xs text-[#1C1E31]">Phone number</div>
          <div class="text-xs text-[#999999]">+1 (629) 555-0129</div>
        </div>
      </div>
      <div class="text-xs text-[#999999]">
        Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur.
      </div>
    </div>
  </div>
</template>

<style scoped>
.scrollbar::-webkit-scrollbar {
  width: 6px;
  height: 20px;
}

.scrollbar::-webkit-scrollbar-track {
  border-radius: 100vh;
  background: white;
}

.scrollbar::-webkit-scrollbar-thumb {
  background: rgba(100, 116, 139, 0.8);
  border-radius: 100vh;
  /* border: 1px solid rgba(100, 116, 139, 0.8); */
}

.scrollbar::-webkit-scrollbar-thumb:hover {
  background: rgba(100, 116, 139, 1);
}
</style>
