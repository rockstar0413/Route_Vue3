<script setup lang="ts">
import { useAddressStore } from '@/stores/address'
import { GoogleMap, CustomMarker, MarkerCluster, Circle, Polyline } from 'vue3-google-map'
import { computed, ref } from 'vue'
import { storeToRefs } from 'pinia'
import { useRoute } from 'vue-router'
import Config from '@/shared/config'

const route = useRoute()
const { getRadius, getRouteEye } = storeToRefs(useAddressStore())
const mapRef = ref(null)
const center = computed(() => {
  return useAddressStore().getCenter;
})
const boundCenter = computed(() => {
  return useAddressStore().getBoundCenter;
})
const markers = computed(() => {
  return useAddressStore().getAddresses;
})
const start_marker = computed(() => {
  return useAddressStore().getStartMaker;
})
const pointAddress = computed(() => {
  return useAddressStore().getPoint
})
const routes = computed(() => {
  return useAddressStore().getOptimizedRoutes
})
const detailRoutes = computed(() => {
  return useAddressStore().getDetailRoutes
})
const pathOption = (route: any, index: number) => {
  let tempPath = [{
    lat: start_marker.value.position.lat,
    lng: start_marker.value.position.lng
  }];
  // for (let i = 0; i < route.route.length; i++) {
  //   tempPath.push({
  //     lat: Number(route.route[i].latitude),
  //     lng: Number(route.route[i].longitude)
  //   })
  // }
  for (let i = 0; i < route.ways.length; i++) {
    tempPath.push({
      lat: Number(route.ways[i].latitude),
      lng: Number(route.ways[i].longitude)
    })
  }
  // route.route.map((item:any, wayIndex:number)=>{
  //   route.ways[wayIndex].map((way:any)=>{
  //     tempPath.push({
  //       lat: way.latitude,
  //       lng: way.longitude
  //     })
  //   })
  //   // tempPath.push({
  //   //   lat: Number((item as any)?.latitude),
  //   //   lng: Number((item as any)?.longitude)
  //   // })
  //   return item;
  // })
  return {
    path: tempPath,
    geodesic: true,
    strokeColor: Config.colors[(Number(route.plan_no))%16],
    strokeOpacity: 1.0,
    strokeWeight: 2,
  }
}
const optionRadius = computed(() => {
  let temp = route.name === 'preferences' ? Number(getRadius.value) : 0
  let radius = temp * 1609.344;
  return {
    center: { lat: start_marker.value.position.lat, lng: start_marker.value.position.lng },
    radius: radius,
    strokeColor: Number(getRadius.value) <= 5 ? '#0000FF' : Number(getRadius.value) <= 10 ? '#00FF00' : '#FF0000',
    strokeOpacity: 0.8,
    strokeWeight: 1,
    fillColor: Number(getRadius.value) <= 5 ? '#0000FF' : Number(getRadius.value) <= 10 ? '#00FF00' : '#FF0000',
    fillOpacity: 0.2
  }
})

</script>
<template>
  <GoogleMap ref="mapRef" api-key="AIzaSyAVPGGaXi05g8vQPJg6SODJh9YqAk0yRUk" class="w-full !h-[400px] sm:!h-full"
    :center="center" :zoom="10">
    <!-- <MarkerCluster> -->
    <CustomMarker :options="{
      position: start_marker.position,
      anchorPoint: 'BOTTOM_CENTER',
    }" v-if="pointAddress.optimize_point_address !== ''">
      <div style="text-align: center;">
        <img src="@/assets/images/start_pin.svg" width="30" height="30" class="text-red-500" />
      </div>
    </CustomMarker>
    <CustomMarker v-for="(m, i) in markers" :key="'marker' + i.toString()+ m.eye.toString()"
      :options="{ position: m.position, anchorPoint: 'BOTTOM_CENTER' }">
      <div class="flex justify-center items-center" v-if="m.eye">
        <!-- <img src="@/assets/images/num_pin.svg" width="30" height="30" /> -->
        <font-awesome-icon icon="fa-solid fa-location-pin" :class="['text-[36px]', 'text-['+Config.colors[(Number(m.plan_no))%16]+']']" :style="{color:Config.colors[(Number(m.plan_no))%16]}" />
        <div
          :class="['absolute text-base font-medium top-[3px] w-[20px] h-[20px] flex justify-center items-center rounded-full bg-white font-medium', 'text-['+Config.colors[(Number(m.plan_no))%16]+']']" :style="{color:Config.colors[(Number(m.plan_no))%16]}">
          {{ i + 1 }}
        </div>
      </div>
    </CustomMarker>
    <!-- </MarkerCluster> -->
    <Circle :options="optionRadius" />
    <div v-for="(route, index) in detailRoutes">
      <Polyline :options="pathOption(route, index)" v-if="getRouteEye((index+1).toString())" />
    </div>
  </GoogleMap>
</template>

<style>

</style>
