<script setup lang="ts">
import { ref } from 'vue';
const { order } = defineProps<{ order: any }>()
const isDetail = ref(false)
const toggleDetail = () => {
  isDetail.value = !isDetail.value
}
</script>

<template>
  <div class="w-full">
    <div class="flex w-full bg-white hover:bg-sky-50">
      <div class="w-full flex items-center   h-[40px] text-[#64748B] text-[12px] font-[500]">
        <div class="basis-[5%] whitespace-nowrap">
          {{ order.ID }}
        </div>
        <div class="basis-[35%] whitespace-nowrap">
          {{ order.name }}
        </div>
        <div class="basis-[20%] whitespace-nowrap">
          {{ order.numberRoute }}
        </div>
        <div class="basis-[15%] whitespace-nowrap">
          {{ order.date }}
        </div>
        <div class="basis-[25%] flex justify-between">
          <div>
            <div class="rounded-3xl bg-[#B9F6CA] text-[#00C853] px-3 whitespace-nowrap text-center"
              v-if="order.status === 'Completed'">{{ order.status }}</div>
            <div class="rounded-3xl bg-[#FBE9E7] text-[#D84315] px-3  whitespace-nowrap text-center"
              v-if="order.status === 'Unused'">{{ order.status }}</div>
            <div
              class="rounded-3xl bg-[#E3F2FD] text-[#2196F3] px-3 whitespace-nowrap whitespace-nowrap text-center"
              v-if="order.status === 'In-process'">{{ order.status }}</div>
          </div>
          <div class="cursor-pointer">
            <font-awesome-icon icon="fa-solid fa-angle-down cursor-pointer" class="ml-3" v-show="!isDetail"
              @click="toggleDetail()" />
            <font-awesome-icon icon="fa-solid fa-angle-up cursor-pointer" class="ml-3" v-show="isDetail"
              @click="toggleDetail()" />
          </div>
        </div>
      </div>
    </div>

    <div class="h-[1px] w-full bg-[#ECECEC]"></div>
    <div class="flex bg-gray-100 w-full" v-show="isDetail">
      <div
        class="w-full bg-gray-100 flex items-center text-[#64748B] text-[12px] font-[500]">
        <div class="basis-[5%] whitespace-nowrap">

        </div>
        <div class="basis-[95%] whitespace-nowrap">
          <div
            class="w-full bg-gray-100 flex items-center h-[40px]  text-[#64748B] text-[12px] font-[500]">
            <div class="basis-[35%] whitespace-nowrap">
              Name
            </div>
            <div class="basis-[20%] whitespace-nowrap">
              Number of stops
            </div>
            <div class="basis-[20%] whitespace-nowrap">
              Total miliage
            </div>
            <div class="basis-[25%] flex justify-between">
              Time
            </div>
          </div>
          <div class="h-[1px] w-full bg-[#ECECEC]"></div>
          <div  v-for="(driver, index) in order.drivers">
            <div
              class="w-full bg-gray-100 flex items-center h-[40px] text-[#64748B] text-[12px] font-[500]">
              <div class="basis-[35%] whitespace-nowrap">
                {{driver.name}}
              </div>
              <div class="basis-[20%] whitespace-nowrap">
                {{driver.numberStop}}
              </div>
              <div class="basis-[20%] whitespace-nowrap">
                {{driver.miliage}}
              </div>
              <div class="basis-[25%] flex justify-between">
                {{driver.time}}
              </div>
            </div>
            <div class="h-[1px] w-full bg-[#ECECEC]"></div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
.scrollbar::-webkit-scrollbar {
  width: 6px;
  height: 20px;
}

.scrollbar::-webkit-scrollbar-track {
  border-radius: 100vh;
  background: white;
}

.scrollbar::-webkit-scrollbar-thumb {
  background: rgba(100, 116, 139, 0.8);
  border-radius: 100vh;
  /* border: 1px solid rgba(100, 116, 139, 0.8); */
}

.scrollbar::-webkit-scrollbar-thumb:hover {
  background: rgba(100, 116, 139, 1);
}
</style>
