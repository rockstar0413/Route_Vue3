<script setup lang="ts">
  import {computed} from 'vue'
  const { icon, content, current } = defineProps<{ icon:string, content:string, current:Boolean }>()
</script>

<template>
  <div :class="['h-[80px] w-full rounded-xl bg-white hover:bg-[#EBF5FF] drop-shadow-lg flex items-center justify-center px-5 cursor-pointer select-none', current?'border border-[#0083FC] bg-[#EBF5FF]':'']">
    <div class="text-center" v-if="icon===''?false:true">
        <img :src="icon" alt="Discovery" />
        <div class="text-[#64748B] text-sm mt-1">{{content}}</div>
    </div>
    <div class="text-[#64748B] text-base" v-if="icon===''?true:false">
      {{content}}
    </div>
  </div>
</template>

<style scoped>
</style>
