<script setup lang="ts">
import { useDropzone } from "vue3-dropzone";
import { useAddressStore } from '@/stores/address'
const emit = defineEmits(['doneUpload'])

const { sendAddressFile, getToken } = useAddressStore()
    const onDrop = async (acceptFiles: any, rejectReasons: any)=> {
      const file= acceptFiles[0];
      let fileData = new FormData();
      fileData.append('optimization_token', getToken.toString())
      fileData.append('route_file', file)
      await sendAddressFile(fileData)
      emit('doneUpload');
    }
    const { getRootProps, getInputProps, open, ...rest } = useDropzone({ 
      onDrop, 
      multiple: false, 
      accept:  ['.csv','.xls', '.xlsx', '.xml'],
      noClick:true
    });
</script>
<template>
  <div>
    <div v-bind="getRootProps()" >
      <input v-bind="getInputProps()" />
      <!-- <p v-if="isDragActive">Drop the files here ...</p>
      <p v-else>Drag 'n' drop some files here, or click to select files</p> -->
      <div
        class="bg-[#F5F6F8] border-[#64748B] border-2 border-dashed block w-full h-48 flex justify-center items-center">
        <div class="text-center">
          <div class="flex justify-center"><img src="@/assets/images/Upload.svg" alt="uploadPlus" width="30px"
              height="30px" /></div>
          <div class="text-xl font-bold text-[#1C1E31]">Drag and drop file here</div>
          <div class="text-sm font-bold text-[#1C1E31] text-center mt-2">or <span
              class="text-sky-500 cursor-pointer" @click="open">select from
              your computer</span></div>
          <div class="text-sm font-bold text-[#64748B] text-center mt-5">Download a <span
              class="text-sky-500 underline cursor-pointer z-20"><a href="/assets/files/sample.xlsx" >sample</a></span> or read the <span
              class="text-sky-500 underline cursor-pointer">guide</span></div>
          <div class="text-sm font-bold text-[#64748B] text-center mt-3=2">.csv, .xls, .xlsx, .xml spreadsheets
            accepted</div>
        </div>
      </div>
    </div>
  </div>
</template>