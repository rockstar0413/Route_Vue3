export interface IPoint {
    status: number
    message: string
    optimize_point_id: number
    optimize_point_address: string
    optimize_point_latitude: string
    optimize_point_longitude: string
    apartment_no:string
    driver_count:string
    min_count:string
    max_count:string
    algorithm_id:string
    effective_radius:string
    load_upload_time:string
    created_at:string
    customer_id:string
    optimization_id:string
}

export interface IRoute {
    address: string
    latitude: number
    longitude: number
    message: string
    optimize_route_id: number
    status: number
    apartment_no:string
    checked:boolean
    description:string
    contact_person:string
    phone_prefix:string
    phone:string
    country_code:string
    is_enabled:string
    plan_no:string
    start_point:boolean
    end_point:boolean
    order:string
    eye:boolean
    position: {
        lat: number | string
        lng: number | string
    }
}
export interface IOptimizeRoutes {
    charged_routes_count:number
    credit_charged:number
    driver_size:number
    message:string
    status:number
    total_count:number
    uncharged_routes_count:number
    data:Array<any>
}

export interface Position {
    optimize_route_id:number
    address:string
    position: {
        lat: number | string
        lng: number | string
    }
}

export interface Center {
    lat: number
    lng: number
}